# Qexa Email Assistant

## Overview

Qexa Email Assistant is a comprehensive AI-powered email management system built with a modern full-stack architecture. The application monitors multiple email accounts, intelligently categorizes incoming emails using AI, and takes automated actions including creating draft responses and calendar events.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **Styling**: Tailwind CSS with shadcn/ui component library
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query for server state management
- **UI Components**: Radix UI primitives with custom styling

### Backend Architecture
- **Runtime**: Node.js with Express.js server
- **Language**: TypeScript for type safety
- **Database ORM**: Drizzle ORM with PostgreSQL
- **Authentication**: OAuth2 for email provider integration
- **API Design**: RESTful endpoints with JSON responses

### Database Schema
- **Email Accounts**: Store multiple email provider credentials
- **Classification Rules**: User-defined rules for email categorization
- **Emails**: Processed email data with metadata
- **Drafts**: AI-generated draft responses
- **Calendar Events**: Created events from email content
- **AI Providers**: Configuration for multiple AI services
- **System Settings**: Application configuration

## Key Components

### Multi-Account Email Management
- Support for Gmail, Outlook, and IMAP providers
- OAuth2 authentication with secure token storage
- Concurrent monitoring of multiple mailboxes
- Rate limiting and API quota management

### AI-Powered Classification
- Integration with multiple AI providers (OpenAI GPT-4o, Anthropic Claude, Google Gemini)
- Intelligent email categorization based on content, sender, and patterns
- Custom classification rules with keyword matching
- Priority assignment (high, medium, low)

### Automated Actions
- **Draft Generation**: AI creates contextually appropriate responses
- **Calendar Integration**: Automatic event creation from meeting requests
- **Folder Organization**: Smart email sorting and tagging
- **Custom Actions**: User-configurable automated responses

### Analytics and Monitoring
- Real-time processing statistics
- Classification accuracy tracking
- Email volume and priority distribution
- Provider performance metrics

## Data Flow

1. **Email Ingestion**: System monitors configured email accounts
2. **Classification**: AI analyzes email content and applies rules
3. **Action Execution**: Automated actions based on classification
4. **Storage**: Processed data stored in PostgreSQL database
5. **User Interface**: Real-time updates via React Query

## External Dependencies

### AI Services
- **OpenAI**: GPT-4o model for email analysis and draft generation
- **Anthropic**: Claude Sonnet 4 for content understanding
- **Google Gemini**: 2.5 Flash/Pro models for classification

### Email Providers
- **Gmail**: OAuth2 integration with Google APIs
- **Outlook**: Microsoft Graph API integration
- **IMAP**: Generic IMAP protocol support

### Database
- **Neon Database**: Serverless PostgreSQL instance
- **Connection Pooling**: Managed through @neondatabase/serverless

### Calendar Integration
- **Google Calendar**: API integration for event creation
- **Service Account**: Authentication for automated actions

## Deployment Strategy

### Development Environment
- **Local Development**: Vite dev server with HMR
- **Database**: Environment-based DATABASE_URL configuration
- **AI Services**: API keys managed through environment variables

### Production Build
- **Frontend**: Static assets built with Vite
- **Backend**: ESBuild compilation to single JavaScript bundle
- **Database Migrations**: Drizzle migrations for schema updates
- **Environment Variables**: Secure credential management

### Key Configuration Files
- `drizzle.config.ts`: Database connection and migration settings
- `vite.config.ts`: Frontend build configuration with path aliases
- `components.json`: shadcn/ui component configuration
- `tailwind.config.ts`: Styling system configuration

The application follows a modular architecture with clear separation between frontend UI, backend API, database layer, and external service integrations. The system is designed for scalability and maintainability with TypeScript providing type safety across the entire stack.

## Recent Changes

### Mobile Responsiveness Update (January 2025)
- **Full Mobile Optimization**: Made email accounts page fully responsive for iPhone and Android devices
- **Responsive Header**: Implemented collapsible header layout with mobile-friendly button sizing
- **Mobile Grid System**: Optimized card layouts with responsive breakpoints (1 column on mobile, 2 on tablet, 3 on desktop)
- **Mobile Navigation**: Added hamburger menu with slide-out sidebar for mobile devices
- **Touch-Friendly UI**: Improved button sizes, spacing, and interaction areas for mobile touch
- **Form Optimization**: Made dialogs and forms mobile-responsive with full-width buttons
- **Content Spacing**: Adjusted padding and margins for optimal mobile viewing
- **Confirmed Compatibility**: Successfully tested on iPhone 16 with proper display

### Rebranding and User Documentation (January 2025)
- **Application Rename**: Rebranded to "Qexa Email Assistant" throughout the system
- **Logo Integration**: Added Qexa logo to footer branding on all pages
- **Comprehensive User Guide**: Created complete documentation covering all features with step-by-step instructions
- **Interactive Demos**: Built visual demonstrations showing email classification, AI drafting, and calendar integration workflows
- **Quick Start Guide**: Added guided setup component in Settings page for new users
- **Dashboard Welcome Flow**: Enhanced dashboard with contextual help for users with no accounts/rules configured
- **Navigation Enhancement**: Added User Guide to main navigation menu for easy access

### Competitive Feature Enhancement (January 2025)
- **Smart Search**: Advanced AI-powered email search with natural language queries, sentiment analysis, and data extraction
- **AI Email Composer**: Full-featured email composition with AI assistance, tone analysis, templates, and scheduling
- **Productivity Insights**: Comprehensive analytics dashboard tracking time saved, AI performance, and productivity metrics
- **Enhanced Navigation**: Added Smart Search, AI Composer, and Productivity Insights to main navigation
- **API Enhancement**: Extended backend with new endpoints for smart search, email generation, tone analysis, and productivity analytics
- **Competitive Positioning**: Enhanced features to compete with top email assistants like Superhuman, SaneBox, and Boomerang

### Personalized AI Onboarding Experience (January 2025)
- **Complete Database Schema**: Added user profiles, onboarding steps, and insights tables for personalized setup tracking
- **AI-Powered Recommendations**: Integrated OpenAI GPT-4o for intelligent role-based setup suggestions and email pattern analysis
- **Multi-Step Interface**: Built comprehensive onboarding flow with profile creation, setup guidance, AI tips, and completion tracking
- **Smart Rule Generation**: AI analyzes user role, email volume, and priorities to suggest optimal classification rules
- **Progress Tracking**: Real-time onboarding progress with step completion and personalized next recommendations
- **Mobile-First Design**: Fully responsive interface optimized for iPhone 16 and all mobile devices with touch-friendly controls
- **Backend API**: Complete REST endpoints for profile management, progress tracking, email analysis, and smart suggestions

### Executive Email Management Features (January 2025)
- **Smart Email Prioritization**: AI-powered urgency detection with executive-level email triage system
- **VIP Contact Management**: Comprehensive VIP contact database with priority levels and relationship tracking
- **Enhanced Draft Assistant**: Context-aware AI email composition with tone analysis and relationship mapping
- **Inbox Triage Dashboard**: Real-time categorization of urgent, high-priority, medium, and low-priority emails
- **Intelligent Response Suggestions**: AI generates contextually appropriate responses based on sender history
- **Priority Analytics**: Advanced metrics showing email distribution, response times, and VIP interaction patterns
- **Executive Workflow**: Streamlined interface designed for busy executives with quick action buttons and smart insights
- **Mobile-Optimized**: Full functionality available on iPhone 16 and Android devices with touch-friendly controls

### User Experience Improvements
- Welcome cards on dashboard for new users lacking email accounts or classification rules
- Visual progress indicators and confidence scores in AI workflows
- Step-by-step setup guidance with clear action items
- Interactive feature demonstrations with auto-play functionality
- Comprehensive troubleshooting section with common issues and solutions

### Header and Branding Updates (January 2025)
- **Global Header Implementation**: Added fixed header with Qexa logo visible on all pages
- **Mobile-Responsive Logo**: Logo properly positioned away from hamburger menu button on mobile devices
- **Clean Branding**: Removed text labels, keeping only the Qexa logo for clean visual presentation
- **Scrolling Fix**: Resolved page scrolling issues across all pages for better user experience
- **Cross-Device Compatibility**: Header displays correctly on iPhone 16, Android, and desktop devices

### Unified AI Email Assistant (January 2025)
- **Consolidated Interface**: Combined AI Composer, Draft Assistant, AI Response Drafting, and Draft Review into single unified page
- **Mode-Based Navigation**: Three primary modes - Compose New Email, Reply to Email, and Review Drafts
- **Streamlined User Experience**: Eliminated navigation complexity by consolidating related AI email features
- **Global AI Preferences**: Centralized tone, length, and signature settings that apply across all AI email functions
- **Enhanced Draft Management**: Integrated draft preview, improvement suggestions, and alternative versions in one interface
- **Mobile-Optimized Layout**: Responsive design with sidebar for mode selection and main content area for active tasks
- **Clean Navigation**: Removed redundant individual AI email pages (Email Composer, Draft Assistant, AI Response Drafting) from sidebar
- **Simplified Routing**: Consolidated multiple AI email routes into single `/ai-email-assistant` endpoint for better UX

### Documentation Features
- **USER_GUIDE.md**: Standalone markdown guide for offline reference
- **Interactive User Guide Page**: In-app comprehensive guide with rich UI components  
- **Quick Start Component**: Condensed setup guide with status indicators
- **Feature Demos**: Visual walkthroughs of core system capabilities

The system now provides extensive onboarding and educational resources to help users maximize the email management platform's potential.