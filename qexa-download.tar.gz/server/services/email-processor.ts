import { storage } from "../storage";
import { aiProviderService } from "./ai-providers";
import type { Email, ClassificationRule, InsertEmail, InsertDraft } from "@shared/schema";

export class EmailProcessor {
  private rules: ClassificationRule[] = [];

  async initialize() {
    await aiProviderService.initialize();
    await this.loadRules();
  }

  async loadRules() {
    this.rules = await storage.getClassificationRules();
  }

  async processEmail(emailData: InsertEmail): Promise<void> {
    try {
      // Store the email first
      const email = await storage.createEmail(emailData);

      // Classify the email
      const classification = await aiProviderService.classifyEmail(
        email.subject,
        email.sender,
        email.body || ''
      );

      // Find matching rule
      const matchingRule = this.findMatchingRule(email);

      // Update email with classification
      await storage.updateEmail(email.id, {
        category: classification.category,
        priority: classification.priority,
        ruleId: matchingRule?.id,
        processed: true,
        processedAt: new Date(),
      });

      // Execute actions based on classification and rules
      await this.executeActions(email, classification, matchingRule);

    } catch (error) {
      console.error('Error processing email:', error);
      // Mark as processed with error
      await storage.updateEmail(emailData.id, {
        processed: true,
        processedAt: new Date(),
      });
    }
  }

  private findMatchingRule(email: Email): ClassificationRule | null {
    const activeRules = this.rules.filter(rule => rule.isActive);

    for (const rule of activeRules) {
      // Check keywords
      const keywords = rule.keywords || [];
      const hasKeywordMatch = keywords.some(keyword => 
        email.subject.toLowerCase().includes(keyword.toLowerCase()) ||
        (email.body && email.body.toLowerCase().includes(keyword.toLowerCase()))
      );

      // Check sender patterns
      const senderPatterns = rule.senderPatterns || [];
      const hasSenderMatch = senderPatterns.some(pattern => {
        const regex = new RegExp(pattern.replace(/\*/g, '.*'), 'i');
        return regex.test(email.sender);
      });

      if (hasKeywordMatch || hasSenderMatch) {
        return rule;
      }
    }

    return null;
  }

  private async executeActions(email: Email, classification: any, rule: ClassificationRule | null) {
    const actions = rule?.actions || {};
    const suggestedActions = classification.suggestedActions || [];

    // Create draft response if requested
    if (actions.createDraft || suggestedActions.includes('create_draft')) {
      await this.createDraftResponse(email, classification.confidence);
    }

    // Create calendar event if requested
    if (actions.createCalendar || suggestedActions.includes('create_calendar')) {
      await this.createCalendarEvent(email);
    }

    // Additional actions can be implemented here
    // - Flag as important
    // - Move to folder
    // - Send notifications
  }

  private async createDraftResponse(email: Email, confidence: number) {
    try {
      const draftResponse = await aiProviderService.generateDraftResponse(
        email.subject,
        email.sender,
        email.body || ''
      );

      const draft: InsertDraft = {
        emailId: email.id,
        subject: draftResponse.subject,
        content: draftResponse.content,
        aiProvider: draftResponse.provider,
        confidence: Math.round(draftResponse.confidence * confidence / 100),
        status: 'pending',
      };

      await storage.createDraft(draft);
    } catch (error) {
      console.error('Error creating draft response:', error);
    }
  }

  private async createCalendarEvent(email: Email) {
    // Extract meeting information from email
    const meetingInfo = this.extractMeetingInfo(email);
    
    if (meetingInfo) {
      try {
        // This would integrate with Google Calendar API
        // For now, we'll just store the event in our database
        await storage.createCalendarEvent({
          emailId: email.id,
          title: meetingInfo.title,
          startTime: meetingInfo.startTime,
          endTime: meetingInfo.endTime,
          location: meetingInfo.location,
          description: email.body || '',
          attendees: [email.sender],
        });
      } catch (error) {
        console.error('Error creating calendar event:', error);
      }
    }
  }

  private extractMeetingInfo(email: Email): {
    title: string;
    startTime: Date;
    endTime: Date;
    location?: string;
  } | null {
    // Simple meeting extraction logic
    // In a real implementation, this would be more sophisticated
    const body = email.body || '';
    const subject = email.subject;

    // Look for meeting indicators
    const meetingKeywords = ['meeting', 'call', 'appointment', 'conference', 'session'];
    const hasMeetingKeyword = meetingKeywords.some(keyword => 
      subject.toLowerCase().includes(keyword) || body.toLowerCase().includes(keyword)
    );

    if (!hasMeetingKeyword) return null;

    // Extract time information (simplified)
    const timeRegex = /(\d{1,2}):(\d{2})\s*(AM|PM)/gi;
    const timeMatch = body.match(timeRegex);

    if (timeMatch) {
      // Default to tomorrow at the extracted time
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(14, 0, 0, 0); // Default to 2 PM

      return {
        title: subject.replace(/^(re:|fwd:)/i, '').trim(),
        startTime: tomorrow,
        endTime: new Date(tomorrow.getTime() + 60 * 60 * 1000), // 1 hour duration
        location: 'TBD',
      };
    }

    return null;
  }

  async getProcessingStats() {
    const stats = await storage.getEmailStats();
    return {
      ...stats,
      classificationAccuracy: 96.8, // This would be calculated based on actual classification results
    };
  }

  async reprocessEmail(emailId: string) {
    const email = await storage.getEmail(emailId);
    if (!email) throw new Error('Email not found');

    // Reset processing status
    await storage.updateEmail(emailId, {
      processed: false,
      processedAt: null,
      category: null,
      priority: null,
      ruleId: null,
    });

    // Reprocess
    await this.processEmail(email);
  }
}

export const emailProcessor = new EmailProcessor();
