import { google } from 'googleapis';
import { OAuth2Client } from 'google-auth-library';

export class GmailAuthService {
  private oauth2Client: OAuth2Client;

  constructor() {
    // These would come from your Google Cloud Console project
    this.oauth2Client = new OAuth2Client(
      process.env.GOOGLE_CLIENT_ID,
      process.env.GOOGLE_CLIENT_SECRET,
      process.env.GOOGLE_REDIRECT_URI || `${process.env.REPLIT_DEV_DOMAIN}/auth/google/callback`
    );
  }

  /**
   * Generate the OAuth2 authorization URL
   */
  getAuthUrl(): string {
    const scopes = [
      'https://www.googleapis.com/auth/gmail.readonly',
      'https://www.googleapis.com/auth/gmail.modify',
      'https://www.googleapis.com/auth/gmail.compose',
      'https://www.googleapis.com/auth/calendar.events'
    ];

    return this.oauth2Client.generateAuthUrl({
      access_type: 'offline',
      scope: scopes,
      prompt: 'consent'
    });
  }

  /**
   * Exchange authorization code for tokens
   */
  async getTokens(code: string) {
    const { tokens } = await this.oauth2Client.getTokens(code);
    return tokens;
  }

  /**
   * Refresh access token using refresh token
   */
  async refreshAccessToken(refreshToken: string) {
    this.oauth2Client.setCredentials({
      refresh_token: refreshToken
    });
    
    const { credentials } = await this.oauth2Client.refreshAccessToken();
    return credentials;
  }

  /**
   * Get Gmail service instance with authenticated client
   */
  getGmailService(accessToken: string) {
    this.oauth2Client.setCredentials({
      access_token: accessToken
    });

    return google.gmail({ version: 'v1', auth: this.oauth2Client });
  }

  /**
   * Get Calendar service instance with authenticated client
   */
  getCalendarService(accessToken: string) {
    this.oauth2Client.setCredentials({
      access_token: accessToken
    });

    return google.calendar({ version: 'v3', auth: this.oauth2Client });
  }

  /**
   * Verify token and get user info
   */
  async getUserInfo(accessToken: string) {
    this.oauth2Client.setCredentials({
      access_token: accessToken
    });

    const oauth2 = google.oauth2({ version: 'v2', auth: this.oauth2Client });
    const { data } = await oauth2.userinfo.get();
    
    return {
      email: data.email,
      name: data.name,
      picture: data.picture
    };
  }
}

export const gmailAuthService = new GmailAuthService();