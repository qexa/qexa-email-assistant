import OpenAI from "openai";
import Anthropic from '@anthropic-ai/sdk';
import { GoogleGenAI } from "@google/genai";
import { storage } from "../storage";
import type { AiProvider } from "@shared/schema";

/*
Follow these instructions when using this blueprint:
1. The newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
2. The newest Anthropic model is "claude-sonnet-4-20250514", not "claude-3-5-sonnet-20241022"
3. Use "gemini-2.5-flash" or "gemini-2.5-pro" models for Gemini
*/

const DEFAULT_OPENAI_MODEL = "gpt-4o";
const DEFAULT_ANTHROPIC_MODEL = "claude-sonnet-4-20250514";
const DEFAULT_GEMINI_MODEL = "gemini-2.5-flash";

export interface EmailAnalysis {
  category: string;
  priority: 'high' | 'medium' | 'low';
  confidence: number;
  suggestedActions: string[];
}

export interface DraftResponse {
  subject: string;
  content: string;
  confidence: number;
  provider: string;
}

export class AIProviderService {
  private openai: OpenAI | null = null;
  private anthropic: Anthropic | null = null;
  private gemini: GoogleGenAI | null = null;

  async initialize() {
    const providers = await storage.getAiProviders();
    
    for (const provider of providers) {
      if (!provider.isActive || !provider.apiKey) continue;

      switch (provider.name) {
        case 'openai':
          this.openai = new OpenAI({ apiKey: provider.apiKey });
          break;
        case 'claude':
          this.anthropic = new Anthropic({ apiKey: provider.apiKey });
          break;
        case 'gemini':
          this.gemini = new GoogleGenAI({ apiKey: provider.apiKey });
          break;
      }
    }
  }

  async classifyEmail(subject: string, sender: string, body: string): Promise<EmailAnalysis> {
    const providers = await storage.getAiProviders();
    const activeProviders = providers.filter(p => p.isActive).sort((a, b) => a.priority - b.priority);

    for (const provider of activeProviders) {
      try {
        const result = await this.classifyWithProvider(provider.name, subject, sender, body);
        await this.updateProviderUsage(provider.id, true);
        return result;
      } catch (error) {
        console.error(`Classification failed with ${provider.name}:`, error);
        await this.updateProviderUsage(provider.id, false);
      }
    }

    // Fallback classification
    return {
      category: 'unclassified',
      priority: 'low',
      confidence: 0,
      suggestedActions: [],
    };
  }

  private async classifyWithProvider(providerName: string, subject: string, sender: string, body: string): Promise<EmailAnalysis> {
    const prompt = `
Analyze this email and provide classification in JSON format:
- Subject: ${subject}
- Sender: ${sender}
- Body: ${body.substring(0, 500)}...

Return JSON with:
{
  "category": "order_confirmation|meeting_request|newsletter|support|urgent|general",
  "priority": "high|medium|low",
  "confidence": 0-100,
  "suggestedActions": ["flag", "create_draft", "create_calendar", "move_folder"]
}

High priority: orders, legal, urgent, meetings with executives
Medium priority: team meetings, project updates, support tickets
Low priority: newsletters, promotions, general updates
`;

    switch (providerName) {
      case 'openai':
        return await this.classifyWithOpenAI(prompt);
      case 'claude':
        return await this.classifyWithClaude(prompt);
      case 'gemini':
        return await this.classifyWithGemini(prompt);
      default:
        throw new Error(`Unknown provider: ${providerName}`);
    }
  }

  private async classifyWithOpenAI(prompt: string): Promise<EmailAnalysis> {
    if (!this.openai) throw new Error('OpenAI not initialized');

    const response = await this.openai.chat.completions.create({
      model: DEFAULT_OPENAI_MODEL,
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    return {
      category: result.category || 'unclassified',
      priority: result.priority || 'low',
      confidence: result.confidence || 0,
      suggestedActions: result.suggestedActions || [],
    };
  }

  private async classifyWithClaude(prompt: string): Promise<EmailAnalysis> {
    if (!this.anthropic) throw new Error('Claude not initialized');

    const response = await this.anthropic.messages.create({
      model: DEFAULT_ANTHROPIC_MODEL,
      max_tokens: 1024,
      messages: [{ role: 'user', content: prompt }],
    });

    const result = JSON.parse(response.content[0].text || '{}');
    return {
      category: result.category || 'unclassified',
      priority: result.priority || 'low',
      confidence: result.confidence || 0,
      suggestedActions: result.suggestedActions || [],
    };
  }

  private async classifyWithGemini(prompt: string): Promise<EmailAnalysis> {
    if (!this.gemini) throw new Error('Gemini not initialized');

    const response = await this.gemini.models.generateContent({
      model: DEFAULT_GEMINI_MODEL,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const result = JSON.parse(response.text || '{}');
    return {
      category: result.category || 'unclassified',
      priority: result.priority || 'low',
      confidence: result.confidence || 0,
      suggestedActions: result.suggestedActions || [],
    };
  }

  async generateDraftResponse(subject: string, sender: string, body: string): Promise<DraftResponse> {
    const providers = await storage.getAiProviders();
    const activeProviders = providers.filter(p => p.isActive).sort((a, b) => a.priority - b.priority);

    for (const provider of activeProviders) {
      try {
        const result = await this.generateDraftWithProvider(provider.name, subject, sender, body);
        await this.updateProviderUsage(provider.id, true);
        return { ...result, provider: provider.name };
      } catch (error) {
        console.error(`Draft generation failed with ${provider.name}:`, error);
        await this.updateProviderUsage(provider.id, false);
      }
    }

    throw new Error('All AI providers failed to generate draft');
  }

  private async generateDraftWithProvider(providerName: string, subject: string, sender: string, body: string): Promise<Omit<DraftResponse, 'provider'>> {
    const prompt = `
Generate a professional email response to:
- Subject: ${subject}
- From: ${sender}
- Content: ${body.substring(0, 1000)}...

Create a professional, concise response that:
1. Acknowledges the email
2. Provides relevant information or next steps
3. Maintains professional tone
4. Is appropriate for the context

Return JSON with:
{
  "subject": "Re: [original subject]",
  "content": "Professional email response content",
  "confidence": 0-100
}
`;

    switch (providerName) {
      case 'openai':
        return await this.generateDraftWithOpenAI(prompt);
      case 'claude':
        return await this.generateDraftWithClaude(prompt);
      case 'gemini':
        return await this.generateDraftWithGemini(prompt);
      default:
        throw new Error(`Unknown provider: ${providerName}`);
    }
  }

  private async generateDraftWithOpenAI(prompt: string): Promise<Omit<DraftResponse, 'provider'>> {
    if (!this.openai) throw new Error('OpenAI not initialized');

    const response = await this.openai.chat.completions.create({
      model: DEFAULT_OPENAI_MODEL,
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    return {
      subject: result.subject || 'Re: Your email',
      content: result.content || 'Thank you for your email. I will review and respond shortly.',
      confidence: result.confidence || 0,
    };
  }

  private async generateDraftWithClaude(prompt: string): Promise<Omit<DraftResponse, 'provider'>> {
    if (!this.anthropic) throw new Error('Claude not initialized');

    const response = await this.anthropic.messages.create({
      model: DEFAULT_ANTHROPIC_MODEL,
      max_tokens: 1024,
      messages: [{ role: 'user', content: prompt }],
    });

    const result = JSON.parse(response.content[0].text || '{}');
    return {
      subject: result.subject || 'Re: Your email',
      content: result.content || 'Thank you for your email. I will review and respond shortly.',
      confidence: result.confidence || 0,
    };
  }

  private async generateDraftWithGemini(prompt: string): Promise<Omit<DraftResponse, 'provider'>> {
    if (!this.gemini) throw new Error('Gemini not initialized');

    const response = await this.gemini.models.generateContent({
      model: DEFAULT_GEMINI_MODEL,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const result = JSON.parse(response.text || '{}');
    return {
      subject: result.subject || 'Re: Your email',
      content: result.content || 'Thank you for your email. I will review and respond shortly.',
      confidence: result.confidence || 0,
    };
  }

  private async updateProviderUsage(providerId: number, success: boolean) {
    const provider = await storage.getAiProvider(providerId);
    if (!provider) return;

    const currentUsage = provider.usageToday || 0;
    const currentSuccessRate = provider.successRate || 100;

    // Update usage count
    const newUsage = currentUsage + 1;

    // Update success rate (simple moving average)
    const newSuccessRate = success 
      ? Math.min(100, currentSuccessRate + (100 - currentSuccessRate) * 0.1)
      : Math.max(0, currentSuccessRate - currentSuccessRate * 0.1);

    await storage.updateAiProvider(providerId, {
      usageToday: newUsage,
      successRate: Math.round(newSuccessRate),
      lastUsedAt: new Date(),
    });
  }

  async getProviderStats() {
    const providers = await storage.getAiProviders();
    return providers.map(provider => ({
      id: provider.id,
      name: provider.name,
      isActive: provider.isActive,
      priority: provider.priority,
      usageToday: provider.usageToday || 0,
      successRate: provider.successRate || 100,
      lastUsedAt: provider.lastUsedAt,
    }));
  }
}

export const aiProviderService = new AIProviderService();
