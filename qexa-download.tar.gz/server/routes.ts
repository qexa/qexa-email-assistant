import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { emailProcessor } from "./services/email-processor";
import { aiProviderService } from "./services/ai-providers";
import { calendarIntegration } from "./services/calendar-integration";
import { aiOnboardingService } from "./services/ai-onboarding";
import { smartPrioritizationService } from "./services/smart-prioritization";
import { enhancedDraftAssistantService } from "./services/enhanced-draft-assistant";
import { generateEmailResponse, improveExistingDraft, generateBulkResponses } from "./services/ai-response-drafting";
import {
  insertEmailAccountSchema,
  insertClassificationRuleSchema,
  insertEmailSchema,
  insertDraftSchema,
  insertCalendarEventSchema,
  insertAiProviderSchema,
  insertUserProfileSchema,
  insertOnboardingStepSchema,
  insertVipContactSchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize services
  await emailProcessor.initialize();
  await calendarIntegration.initialize();

  // Dashboard and Statistics
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const stats = await emailProcessor.getProcessingStats();
      const draftsCount = (await storage.getPendingDrafts()).length;
      
      res.json({
        totalEmails: stats.totalEmails,
        processedToday: stats.processedToday,
        draftsCreated: draftsCount,
        accuracy: `${stats.classificationAccuracy}%`,
        priorityBreakdown: {
          high: stats.highPriority,
          medium: stats.mediumPriority,
          low: stats.lowPriority,
        },
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to get dashboard stats" });
    }
  });

  app.get("/api/dashboard/recent-activity", async (req, res) => {
    try {
      const recentEmails = await storage.getRecentEmails(10);
      const pendingDrafts = await storage.getPendingDrafts();
      const recentEvents = await calendarIntegration.getRecentEvents(5);

      res.json({
        recentEmails,
        pendingDrafts,
        recentEvents,
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to get recent activity" });
    }
  });

  // Email Accounts
  app.get("/api/email-accounts", async (req, res) => {
    try {
      const accounts = await storage.getEmailAccounts();
      res.json(accounts);
    } catch (error) {
      res.status(500).json({ error: "Failed to get email accounts" });
    }
  });

  app.post("/api/email-accounts", async (req, res) => {
    try {
      const accountData = req.body;
      
      // Handle Gmail App Password setup automatically
      if (accountData.provider === 'gmail') {
        accountData.imapConfig = {
          host: 'imap.gmail.com',
          port: 993,
          secure: true,
          auth: {
            user: accountData.email,
            pass: accountData.password
          }
        };
      } else if (accountData.provider === 'outlook') {
        accountData.imapConfig = {
          host: 'outlook.office365.com',
          port: 993,
          secure: true,
          auth: {
            user: accountData.email,
            pass: accountData.password
          }
        };
      }
      
      // Remove password from the stored data (it's now in imapConfig)
      const { password, ...cleanAccountData } = accountData;
      
      const parsed = insertEmailAccountSchema.parse(cleanAccountData);
      const account = await storage.createEmailAccount(parsed);
      res.status(201).json(account);
    } catch (error) {
      console.error('Email account creation error:', error);
      res.status(400).json({ error: "Invalid email account data" });
    }
  });

  app.put("/api/email-accounts/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const parsed = insertEmailAccountSchema.partial().parse(req.body);
      const account = await storage.updateEmailAccount(id, parsed);
      res.json(account);
    } catch (error) {
      res.status(400).json({ error: "Failed to update email account" });
    }
  });

  app.delete("/api/email-accounts/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteEmailAccount(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete email account" });
    }
  });

  // Classification Rules
  app.get("/api/classification-rules", async (req, res) => {
    try {
      const rules = await storage.getClassificationRules();
      res.json(rules);
    } catch (error) {
      res.status(500).json({ error: "Failed to get classification rules" });
    }
  });

  app.post("/api/classification-rules", async (req, res) => {
    try {
      const parsed = insertClassificationRuleSchema.parse(req.body);
      const rule = await storage.createClassificationRule(parsed);
      await emailProcessor.loadRules(); // Reload rules
      res.status(201).json(rule);
    } catch (error) {
      res.status(400).json({ error: "Invalid classification rule data" });
    }
  });

  app.put("/api/classification-rules/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const parsed = insertClassificationRuleSchema.partial().parse(req.body);
      const rule = await storage.updateClassificationRule(id, parsed);
      await emailProcessor.loadRules(); // Reload rules
      res.json(rule);
    } catch (error) {
      res.status(400).json({ error: "Failed to update classification rule" });
    }
  });

  app.delete("/api/classification-rules/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteClassificationRule(id);
      await emailProcessor.loadRules(); // Reload rules
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete classification rule" });
    }
  });

  // Emails
  app.get("/api/emails", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const offset = parseInt(req.query.offset as string) || 0;
      const emails = await storage.getEmails(limit, offset);
      res.json(emails);
    } catch (error) {
      res.status(500).json({ error: "Failed to get emails" });
    }
  });

  app.post("/api/emails", async (req, res) => {
    try {
      const parsed = insertEmailSchema.parse(req.body);
      await emailProcessor.processEmail(parsed);
      res.status(201).json({ message: "Email processed successfully" });
    } catch (error) {
      res.status(400).json({ error: "Invalid email data" });
    }
  });

  app.post("/api/emails/:id/reprocess", async (req, res) => {
    try {
      const id = req.params.id;
      await emailProcessor.reprocessEmail(id);
      res.json({ message: "Email reprocessed successfully" });
    } catch (error) {
      res.status(500).json({ error: "Failed to reprocess email" });
    }
  });

  // Drafts
  app.get("/api/drafts", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 50;
      const offset = parseInt(req.query.offset as string) || 0;
      const drafts = await storage.getDrafts(limit, offset);
      res.json(drafts);
    } catch (error) {
      res.status(500).json({ error: "Failed to get drafts" });
    }
  });

  app.get("/api/drafts/pending", async (req, res) => {
    try {
      const pendingDrafts = await storage.getPendingDrafts();
      res.json(pendingDrafts);
    } catch (error) {
      res.status(500).json({ error: "Failed to get pending drafts" });
    }
  });

  app.put("/api/drafts/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status, content } = req.body;
      
      const updates: any = {};
      if (status) updates.status = status;
      if (content) updates.content = content;
      if (status !== 'pending') updates.reviewedAt = new Date();

      const draft = await storage.updateDraft(id, updates);
      res.json(draft);
    } catch (error) {
      res.status(400).json({ error: "Failed to update draft" });
    }
  });

  app.delete("/api/drafts/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteDraft(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete draft" });
    }
  });

  // AI-Powered Email Response Drafting
  app.post("/api/drafts/generate-response", async (req, res) => {
    try {
      const { emailContext, userInstructions } = req.body;
      
      if (!emailContext?.originalEmail) {
        return res.status(400).json({ error: "Email context is required" });
      }

      const draftResponse = await generateEmailResponse(emailContext, userInstructions);
      
      // Save the draft to database
      const draftData = {
        emailId: emailContext.originalEmail.id || `temp-${Date.now()}`,
        subject: draftResponse.subject,
        content: draftResponse.content,
        aiProvider: 'openai',
        status: 'pending',
        confidence: draftResponse.confidence,
        tone: draftResponse.tone,
        responseType: draftResponse.responseType,
        contextUsed: draftResponse.contextUsed,
        alternatives: draftResponse.alternatives
      };
      
      const savedDraft = await storage.createDraft(draftData);
      
      res.json({
        ...draftResponse,
        id: savedDraft.id,
        createdAt: savedDraft.createdAt
      });
    } catch (error) {
      console.error('Draft generation error:', error);
      res.status(500).json({ error: "Failed to generate email response" });
    }
  });

  app.post("/api/drafts/:id/improve", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { improvements, emailContext } = req.body;
      
      const drafts = await storage.getDrafts(1, 0);
      const existingDraft = drafts.find((d: any) => d.id === id);
      if (!existingDraft) {
        return res.status(404).json({ error: "Draft not found" });
      }
      
      const improved = await improveExistingDraft(
        existingDraft.content,
        improvements,
        emailContext
      );
      
      const updatedDraft = await storage.updateDraft(id, {
        content: improved.improvedContent,
        confidence: improved.confidence,
        status: 'pending'
      });
      
      res.json({
        draft: updatedDraft,
        changes: improved.changes,
        confidence: improved.confidence
      });
    } catch (error) {
      console.error('Draft improvement error:', error);
      res.status(500).json({ error: "Failed to improve draft" });
    }
  });

  app.post("/api/drafts/generate-bulk", async (req, res) => {
    try {
      const { emails, template } = req.body;
      
      if (!emails || !Array.isArray(emails)) {
        return res.status(400).json({ error: "Emails array is required" });
      }
      
      const results = await generateBulkResponses(emails, template);
      
      // Save all drafts to database
      const savedDrafts = [];
      for (const result of results) {
        try {
          const draftData = {
            emailId: result.emailId,
            subject: result.draft.subject,
            content: result.draft.content,
            aiProvider: 'openai',
            status: 'pending',
            confidence: result.draft.confidence,
            tone: result.draft.tone,
            responseType: result.draft.responseType,
            contextUsed: result.draft.contextUsed,
            alternatives: result.draft.alternatives
          };
          
          const savedDraft = await storage.createDraft(draftData);
          savedDrafts.push({
            ...result,
            id: savedDraft.id,
            createdAt: savedDraft.createdAt
          });
        } catch (error) {
          console.error(`Failed to save draft for email ${result.emailId}:`, error);
        }
      }
      
      res.json({
        processed: emails.length,
        successful: savedDrafts.length,
        drafts: savedDrafts
      });
    } catch (error) {
      console.error('Bulk draft generation error:', error);
      res.status(500).json({ error: "Failed to generate bulk responses" });
    }
  });

  app.get("/api/drafts/:id/alternatives", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const drafts = await storage.getDrafts(1, 0);
      const draft = drafts.find((d: any) => d.id === id);
      
      if (!draft) {
        return res.status(404).json({ error: "Draft not found" });
      }
      
      res.json({
        alternatives: draft.alternatives || [],
        mainDraft: {
          content: draft.content,
          tone: draft.tone,
          confidence: draft.confidence
        }
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to get draft alternatives" });
    }
  });

  // Calendar Events
  app.get("/api/calendar-events", async (req, res) => {
    try {
      const events = await calendarIntegration.getUpcomingEvents();
      res.json(events);
    } catch (error) {
      res.status(500).json({ error: "Failed to get calendar events" });
    }
  });

  app.post("/api/calendar-events", async (req, res) => {
    try {
      const parsed = insertCalendarEventSchema.parse(req.body);
      const event = await calendarIntegration.createEvent(parsed);
      res.status(201).json(event);
    } catch (error) {
      res.status(400).json({ error: "Invalid calendar event data" });
    }
  });

  app.put("/api/calendar-events/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const parsed = insertCalendarEventSchema.partial().parse(req.body);
      const event = await calendarIntegration.updateEvent(id, parsed);
      res.json(event);
    } catch (error) {
      res.status(400).json({ error: "Failed to update calendar event" });
    }
  });

  app.delete("/api/calendar-events/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await calendarIntegration.deleteEvent(id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete calendar event" });
    }
  });

  app.get("/api/calendar-events/recent", async (req, res) => {
    try {
      const events = await calendarIntegration.getRecentEvents();
      res.json(events);
    } catch (error) {
      res.status(500).json({ error: "Failed to get recent calendar events" });
    }
  });

  // Smart Search API
  app.post("/api/emails/smart-search", async (req, res) => {
    try {
      const { query, includeContext, analyzeSentiment } = req.body;
      
      // Mock smart search results for now - in production this would use AI to understand natural language queries
      const mockResults = [
        {
          id: 1,
          subject: "Project deadline discussion",
          sender: "john@company.com",
          body: "Hi team, I wanted to follow up on our project timeline discussion. The deadline seems tight, but I think we can make it work if we focus on the core features first.",
          receivedAt: "2025-01-15T10:30:00Z",
          priority: "high",
          sentiment: analyzeSentiment ? "neutral" : undefined,
          aiSummary: includeContext ? "John discusses project timeline concerns and suggests focusing on core features to meet deadline." : undefined,
          extractedData: includeContext ? { project: "Website Redesign", deadline: "Jan 30" } : undefined
        },
        {
          id: 2,
          subject: "Meeting confirmation for tomorrow",
          sender: "sarah@client.com",
          body: "Thank you for scheduling the call tomorrow at 2 PM. I'll be prepared to discuss the quarterly review and next steps for our partnership.",
          receivedAt: "2025-01-14T15:45:00Z",
          priority: "medium",
          sentiment: analyzeSentiment ? "positive" : undefined,
          aiSummary: includeContext ? "Sarah confirms tomorrow's 2 PM meeting about quarterly review and partnership next steps." : undefined,
          extractedData: includeContext ? { meeting_time: "2 PM", topic: "Quarterly Review" } : undefined
        }
      ];
      
      res.json(mockResults);
    } catch (error) {
      res.status(500).json({ error: "Smart search failed" });
    }
  });

  // Email Generation API
  app.post("/api/emails/generate", async (req, res) => {
    try {
      const { prompt, tone, length, context } = req.body;
      
      // Mock AI email generation - in production this would use OpenAI/Claude/Gemini
      const generatedEmail = {
        subject: `Re: ${prompt.substring(0, 30)}...`,
        body: `Dear Colleague,\n\nI hope this email finds you well. Based on your request about "${prompt}", I wanted to provide you with a ${tone} response that addresses your needs.\n\n[Generated content would be ${length} length and tailored to ${tone} tone]\n\nPlease let me know if you need any clarification or have additional questions.\n\nBest regards,\n[Your Name]`
      };
      
      res.json(generatedEmail);
    } catch (error) {
      res.status(500).json({ error: "Email generation failed" });
    }
  });

  // Tone Analysis API
  app.post("/api/emails/analyze-tone", async (req, res) => {
    try {
      const { content } = req.body;
      
      // Mock tone analysis - in production this would use sentiment analysis AI
      const suggestions = [
        {
          type: "Tone",
          message: "The email has a professional tone with neutral sentiment"
        },
        {
          type: "Clarity",
          message: "Consider adding a clear call-to-action for better response rates"
        }
      ];
      
      res.json({ suggestions });
    } catch (error) {
      res.status(500).json({ error: "Tone analysis failed" });
    }
  });

  // Send Email API
  app.post("/api/emails/send", async (req, res) => {
    try {
      const { to, cc, bcc, subject, body, scheduled, scheduleFor } = req.body;
      
      // Mock email sending - in production this would integrate with email providers
      const emailId = Date.now();
      
      res.json({ 
        success: true, 
        emailId,
        scheduled,
        message: scheduled ? "Email scheduled successfully" : "Email sent successfully" 
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to send email" });
    }
  });

  // Productivity Analytics APIs
  app.get("/api/analytics/productivity-insights", async (req, res) => {
    try {
      const insights = {
        emailsProcessedAutomatically: 847,
        draftResponseRate: 78,
        averageProcessingTime: 2.4,
        automationAccuracy: 94
      };
      res.json(insights);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch productivity insights" });
    }
  });

  app.get("/api/analytics/time-metrics", async (req, res) => {
    try {
      const metrics = {
        timeSavedWeekly: 13.5,
        responseTimeImprovement: 53,
        peakHours: ['9:00-10:00', '14:00-15:00', '16:00-17:00'],
        timeDistribution: {
          reading: 35,
          writing: 25,
          organizing: 20,
          automated: 20
        }
      };
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch time metrics" });
    }
  });

  app.get("/api/analytics/ai-metrics", async (req, res) => {
    try {
      const metrics = {
        overallAccuracy: 93,
        providerPerformance: [
          { name: 'OpenAI GPT-4', accuracy: 94, usage: 45 },
          { name: 'Anthropic Claude', accuracy: 91, usage: 35 },
          { name: 'Google Gemini', accuracy: 88, usage: 20 }
        ],
        classificationAccuracy: [
          { category: 'High Priority', accuracy: 96, count: 156 },
          { category: 'Meeting Requests', accuracy: 92, count: 89 },
          { category: 'Customer Support', accuracy: 88, count: 234 },
          { category: 'Newsletters', accuracy: 98, count: 345 }
        ]
      };
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch AI metrics" });
    }
  });

  app.get("/api/calendar/settings", async (req, res) => {
    try {
      const settings = await calendarIntegration.getCalendarSettings();
      res.json(settings);
    } catch (error) {
      res.status(500).json({ error: "Failed to get calendar settings" });
    }
  });

  app.put("/api/calendar/settings", async (req, res) => {
    try {
      await calendarIntegration.updateCalendarSettings(req.body);
      res.json({ message: "Calendar settings updated successfully" });
    } catch (error) {
      res.status(400).json({ error: "Failed to update calendar settings" });
    }
  });

  // AI Providers
  app.get("/api/ai-providers", async (req, res) => {
    try {
      const providers = await aiProviderService.getProviderStats();
      res.json(providers);
    } catch (error) {
      res.status(500).json({ error: "Failed to get AI providers" });
    }
  });

  app.put("/api/ai-providers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const parsed = insertAiProviderSchema.partial().parse(req.body);
      const provider = await storage.updateAiProvider(id, parsed);
      res.json(provider);
    } catch (error) {
      res.status(400).json({ error: "Failed to update AI provider" });
    }
  });

  // System Settings
  app.get("/api/settings", async (req, res) => {
    try {
      const settings = await storage.getSystemSettings();
      res.json(settings);
    } catch (error) {
      res.status(500).json({ error: "Failed to get system settings" });
    }
  });

  app.put("/api/settings/:key", async (req, res) => {
    try {
      const key = req.params.key;
      const { value } = req.body;
      const setting = await storage.updateSystemSetting(key, value);
      res.json(setting);
    } catch (error) {
      res.status(400).json({ error: "Failed to update system setting" });
    }
  });

  // Gmail OAuth2 Authentication Routes
  app.get("/auth/google", async (req, res) => {
    try {
      const { gmailAuthService } = await import("./services/gmail-auth");
      const authUrl = gmailAuthService.getAuthUrl();
      res.redirect(authUrl);
    } catch (error) {
      res.status(500).json({ error: "Failed to initialize OAuth" });
    }
  });

  app.get("/auth/google/callback", async (req, res) => {
    try {
      const { code } = req.query;
      if (!code) {
        return res.status(400).json({ error: "Missing authorization code" });
      }

      const { gmailAuthService } = await import("./services/gmail-auth");
      const tokens = await gmailAuthService.getTokens(code as string);
      const userInfo = await gmailAuthService.getUserInfo(tokens.access_token!);

      // Store the tokens and user info
      const accountData = {
        email: userInfo.email!,
        provider: 'gmail' as const,
        displayName: userInfo.name || userInfo.email!,
        isActive: true,
        oauthCredentials: {
          accessToken: tokens.access_token!,
          refreshToken: tokens.refresh_token!,
          expiresAt: new Date(Date.now() + (tokens.expiry_date || 3600000)).toISOString()
        }
      };

      const account = await storage.createEmailAccount(accountData);
      
      // Redirect back to the app with success
      res.redirect('/?oauth=success');
    } catch (error) {
      console.error("OAuth callback error:", error);
      res.redirect('/?oauth=error');
    }
  });

  // AI Onboarding Routes
  app.get("/api/onboarding/profile", async (req, res) => {
    try {
      const profile = await storage.getUserProfile();
      res.json(profile);
    } catch (error) {
      res.status(500).json({ error: "Failed to get user profile" });
    }
  });

  app.post("/api/onboarding/profile", async (req, res) => {
    try {
      const parsed = insertUserProfileSchema.parse(req.body);
      const profile = await aiOnboardingService.createPersonalizedOnboarding(parsed);
      res.status(201).json(profile);
    } catch (error) {
      console.error("Failed to create user profile:", error);
      res.status(400).json({ error: "Invalid profile data" });
    }
  });

  app.get("/api/onboarding/progress/:userId", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const progress = await aiOnboardingService.getOnboardingProgress(userId);
      res.json(progress);
    } catch (error) {
      res.status(500).json({ error: "Failed to get onboarding progress" });
    }
  });

  app.post("/api/onboarding/complete-step", async (req, res) => {
    try {
      const { userId, stepType, userChoices } = req.body;
      const step = await aiOnboardingService.completeOnboardingStep(userId, stepType, userChoices);
      res.json(step);
    } catch (error) {
      res.status(400).json({ error: "Failed to complete onboarding step" });
    }
  });

  app.post("/api/onboarding/analyze-emails", async (req, res) => {
    try {
      const { emailSamples } = req.body;
      const insights = await aiOnboardingService.analyzeEmailPatterns(emailSamples);
      res.json(insights);
    } catch (error) {
      res.status(400).json({ error: "Failed to analyze email patterns" });
    }
  });

  app.post("/api/onboarding/smart-rules", async (req, res) => {
    try {
      const { userId } = req.body;
      const profile = await storage.getUserProfile();
      const insights = await storage.getOnboardingInsights(userId);
      
      if (!profile) {
        return res.status(404).json({ error: "User profile not found" });
      }

      const suggestions = await aiOnboardingService.generateSmartRuleSuggestions(profile, insights);
      res.json(suggestions);
    } catch (error) {
      res.status(400).json({ error: "Failed to generate smart rule suggestions" });
    }
  });

  // Smart Prioritization Routes
  app.post("/api/prioritization/analyze", async (req, res) => {
    try {
      const { emailId } = req.body;
      const email = await storage.getEmail(emailId);
      if (!email) {
        return res.status(404).json({ error: "Email not found" });
      }
      
      const analysis = await smartPrioritizationService.analyzeEmailUrgency(email);
      res.json(analysis);
    } catch (error) {
      res.status(400).json({ error: "Failed to analyze email priority" });
    }
  });

  app.get("/api/prioritization/vip-contacts", async (req, res) => {
    try {
      const vipContacts = await storage.getVipContacts();
      res.json(vipContacts);
    } catch (error) {
      res.status(500).json({ error: "Failed to get VIP contacts" });
    }
  });

  app.post("/api/prioritization/vip-contacts", async (req, res) => {
    try {
      const parsed = insertVipContactSchema.parse(req.body);
      const vipContact = await storage.createVipContact(parsed);
      res.status(201).json(vipContact);
    } catch (error) {
      res.status(400).json({ error: "Failed to create VIP contact" });
    }
  });

  app.get("/api/prioritization/inbox-triage", async (req, res) => {
    try {
      const { timeframe = 'today' } = req.query;
      const triage = await smartPrioritizationService.performInboxTriage(timeframe as string);
      res.json(triage);
    } catch (error) {
      res.status(500).json({ error: "Failed to perform inbox triage" });
    }
  });

  // Enhanced Draft Assistance Routes
  app.post("/api/drafts/generate-enhanced", async (req, res) => {
    try {
      const { emailId, tone = 'professional', priority = 'medium' } = req.body;
      const email = await storage.getEmail(emailId);
      if (!email) {
        return res.status(404).json({ error: "Email not found" });
      }
      
      const draft = await enhancedDraftAssistantService.generateContextAwareResponse(email, tone, priority);
      res.json(draft);
    } catch (error) {
      res.status(400).json({ error: "Failed to generate enhanced draft" });
    }
  });

  app.post("/api/drafts/analyze-tone", async (req, res) => {
    try {
      const { content } = req.body;
      if (!content) {
        return res.status(400).json({ error: "Content is required" });
      }

      // Simple tone analysis implementation
      const words = content.toLowerCase();
      
      let tone = 'neutral';
      let formality = 'neutral';
      let confidence = 75;
      const suggestions: string[] = [];

      // Analyze formality
      if (words.includes('dear') || words.includes('sincerely') || words.includes('regards')) {
        formality = 'formal';
        tone = 'professional';
      } else if (words.includes('hey') || words.includes('thanks!') || words.includes('cheers')) {
        formality = 'casual';
        tone = 'friendly';
      }

      // Analyze sentiment
      let sentiment = 'neutral';
      if (words.includes('thank') || words.includes('appreciate') || words.includes('excited')) {
        sentiment = 'positive';
      } else if (words.includes('concern') || words.includes('issue') || words.includes('problem')) {
        sentiment = 'negative';
        suggestions.push('Consider softening the language');
      }

      // Check for urgency
      if (words.includes('urgent') || words.includes('asap') || words.includes('immediately')) {
        suggestions.push('High urgency detected - ensure recipient can respond quickly');
      }

      // Check length and clarity
      if (content.length > 500) {
        suggestions.push('Consider making the message more concise');
      }

      const analysis = {
        tone,
        confidence,
        sentiment,
        formality,
        suggestions
      };

      res.json(analysis);
    } catch (error) {
      console.error('Tone analysis error:', error);
      res.status(400).json({ error: "Failed to analyze tone" });
    }
  });

  app.post("/api/drafts/suggest-improvements", async (req, res) => {
    try {
      const { draftContent, originalEmailId } = req.body;
      const suggestions = await enhancedDraftAssistantService.suggestImprovements(draftContent, originalEmailId);
      res.json(suggestions);
    } catch (error) {
      res.status(400).json({ error: "Failed to suggest improvements" });
    }
  });

  app.get("/api/drafts/relationship-context/:sender", async (req, res) => {
    try {
      const { sender } = req.params;
      const context = await enhancedDraftAssistantService.buildRelationshipContext(sender);
      res.json(context);
    } catch (error) {
      res.status(500).json({ error: "Failed to get relationship context" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
