import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Dashboard from "@/pages/dashboard";
import EmailAccounts from "@/pages/email-accounts";
import ClassificationRules from "@/pages/classification-rules";
import DraftReview from "@/pages/draft-review";
import CalendarIntegration from "@/pages/calendar-integration";
import Analytics from "@/pages/analytics";
import Settings from "@/pages/settings";
import UserGuide from "@/pages/user-guide";
import SmartSearch from "@/pages/smart-search";
import ProductivityInsights from "@/pages/productivity-insights";
import AIOnboarding from "@/pages/ai-onboarding";
import SmartPrioritization from "@/pages/smart-prioritization";
import UnifiedAIEmailAssistant from "@/pages/unified-ai-email-assistant";
import NotFound from "@/pages/not-found";
import Sidebar from "@/components/sidebar";
import Footer from "@/components/footer";
import Header from "@/components/header";

function Router() {
  return (
    <div className="flex h-screen max-h-screen">
      <Sidebar />
      <div className="flex-1 flex flex-col lg:ml-0 min-h-0">
        <Header />
        <div className="flex-1 overflow-y-auto pt-16 lg:pt-16">
          <Switch>
            <Route path="/" component={Dashboard} />
            <Route path="/email-accounts" component={EmailAccounts} />
            <Route path="/classification-rules" component={ClassificationRules} />
            <Route path="/draft-review" component={DraftReview} />
            <Route path="/calendar-integration" component={CalendarIntegration} />
            <Route path="/analytics" component={Analytics} />
            <Route path="/settings" component={Settings} />
            <Route path="/user-guide" component={UserGuide} />
            <Route path="/smart-search" component={SmartSearch} />
            <Route path="/productivity-insights" component={ProductivityInsights} />
            <Route path="/ai-onboarding" component={AIOnboarding} />
            <Route path="/smart-prioritization" component={SmartPrioritization} />
            <Route path="/ai-email-assistant" component={UnifiedAIEmailAssistant} />
            <Route component={NotFound} />
          </Switch>
        </div>
        <Footer />
      </div>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
