import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { 
  Play, 
  Pause, 
  RotateCcw, 
  Mail, 
  Brain, 
  Calendar, 
  CheckCircle,
  Clock,
  AlertTriangle,
  Sparkles
} from "lucide-react";

export default function InteractiveDemo() {
  const [currentStep, setCurrentStep] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeDemo, setActiveDemo] = useState("classification");

  const demos = {
    classification: {
      title: "Email Classification Demo",
      description: "See how AI automatically categorizes incoming emails",
      steps: [
        {
          title: "Email Received",
          description: "New email arrives in your inbox",
          content: {
            from: "john@techcorp.com",
            subject: "URGENT: Server downtime scheduled for tonight",
            preview: "Hi team, we need to schedule emergency maintenance..."
          },
          status: "received"
        },
        {
          title: "AI Analysis",
          description: "AI analyzes content, sender, and keywords",
          analysis: {
            keywords: ["urgent", "server", "downtime", "maintenance"],
            senderPattern: "@techcorp.com",
            priority: "high",
            confidence: 95
          },
          status: "analyzing"
        },
        {
          title: "Rule Applied",
          description: "Matching classification rule found",
          rule: {
            name: "IT Infrastructure Alerts",
            priority: "High",
            actions: ["Flag", "Create Draft", "Notify"]
          },
          status: "classified"
        },
        {
          title: "Actions Executed",
          description: "Automated actions performed",
          actions: [
            { type: "flag", status: "completed", description: "Email flagged as high priority" },
            { type: "draft", status: "completed", description: "Draft response created" },
            { type: "notify", status: "completed", description: "Team notification sent" }
          ],
          status: "completed"
        }
      ]
    },
    drafting: {
      title: "AI Draft Generation Demo",
      description: "Watch AI create intelligent email responses",
      steps: [
        {
          title: "Email Analysis",
          description: "AI reads and understands the incoming email",
          email: {
            from: "sarah@client.com",
            subject: "Question about project timeline",
            body: "Hi, I wanted to check on the status of our project. When can we expect the first deliverable?"
          },
          status: "reading"
        },
        {
          title: "Context Building",
          description: "AI gathers relevant context and tone",
          context: {
            sender: "Existing client",
            tone: "Professional, friendly",
            intent: "Status inquiry",
            urgency: "Medium"
          },
          status: "analyzing"
        },
        {
          title: "Draft Creation",
          description: "AI generates appropriate response",
          draft: {
            subject: "Re: Question about project timeline",
            body: "Hi Sarah,\n\nThank you for checking in on the project status. I'm happy to provide an update.\n\nWe're currently on track with the timeline we discussed. The first deliverable is scheduled for completion by [DATE], and I'll send it over for your review once ready.\n\nIf you have any specific concerns or need to adjust the timeline, please let me know.\n\nBest regards"
          },
          confidence: 87,
          status: "drafted"
        },
        {
          title: "Review Ready",
          description: "Draft queued for human review",
          actions: ["Approve", "Edit", "Reject"],
          status: "review"
        }
      ]
    },
    calendar: {
      title: "Calendar Integration Demo",
      description: "See how meeting requests become calendar events",
      steps: [
        {
          title: "Meeting Email",
          description: "Email with meeting details received",
          email: {
            from: "manager@company.com",
            subject: "Weekly team sync - Thursday 2PM",
            body: "Hi everyone, let's schedule our weekly team sync for this Thursday at 2PM in Conference Room A. The meeting should take about 1 hour."
          },
          status: "received"
        },
        {
          title: "Date/Time Extraction",
          description: "AI identifies meeting details",
          extracted: {
            date: "This Thursday",
            time: "2:00 PM",
            duration: "1 hour",
            location: "Conference Room A",
            attendees: ["team members"]
          },
          confidence: 92,
          status: "parsing"
        },
        {
          title: "Calendar Event",
          description: "Event created in your calendar",
          event: {
            title: "Weekly team sync",
            date: "Thursday, Jan 25, 2025",
            time: "2:00 PM - 3:00 PM",
            location: "Conference Room A",
            organizer: "manager@company.com"
          },
          status: "created"
        },
        {
          title: "Invites Sent",
          description: "Calendar invitations sent to attendees",
          invites: [
            { email: "team@company.com", status: "sent" },
            { email: "you@company.com", status: "accepted" }
          ],
          status: "completed"
        }
      ]
    }
  };

  const currentDemo = demos[activeDemo as keyof typeof demos];
  const progress = ((currentStep + 1) / currentDemo.steps.length) * 100;

  const nextStep = () => {
    if (currentStep < currentDemo.steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      setCurrentStep(0);
    }
  };

  const startDemo = () => {
    setIsPlaying(true);
    const interval = setInterval(() => {
      setCurrentStep(prev => {
        if (prev < currentDemo.steps.length - 1) {
          return prev + 1;
        } else {
          setIsPlaying(false);
          clearInterval(interval);
          return 0;
        }
      });
    }, 2000);
  };

  const resetDemo = () => {
    setCurrentStep(0);
    setIsPlaying(false);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "received": return <Mail className="w-4 h-4 text-blue-500" />;
      case "analyzing": return <Brain className="w-4 h-4 text-yellow-500 animate-pulse" />;
      case "classified": return <CheckCircle className="w-4 h-4 text-green-500" />;
      case "completed": return <CheckCircle className="w-4 h-4 text-green-500" />;
      case "reading": return <Mail className="w-4 h-4 text-blue-500" />;
      case "drafted": return <Sparkles className="w-4 h-4 text-purple-500" />;
      case "review": return <Clock className="w-4 h-4 text-orange-500" />;
      case "parsing": return <Brain className="w-4 h-4 text-yellow-500 animate-pulse" />;
      case "created": return <Calendar className="w-4 h-4 text-green-500" />;
      default: return <Clock className="w-4 h-4 text-gray-400" />;
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-purple-600" />
              Interactive Feature Demos
            </CardTitle>
            <p className="text-sm text-gray-600">See how your email system works in action</p>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={isPlaying ? () => setIsPlaying(false) : startDemo}
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              {isPlaying ? "Pause" : "Auto Play"}
            </Button>
            <Button variant="outline" size="sm" onClick={resetDemo}>
              <RotateCcw className="w-4 h-4" />
              Reset
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs value={activeDemo} onValueChange={setActiveDemo} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="classification">Email Classification</TabsTrigger>
            <TabsTrigger value="drafting">AI Drafting</TabsTrigger>
            <TabsTrigger value="calendar">Calendar Integration</TabsTrigger>
          </TabsList>
          
          <TabsContent value={activeDemo} className="mt-6">
            <div className="space-y-6">
              {/* Progress */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Demo Progress</span>
                  <span className="text-sm text-gray-500">
                    Step {currentStep + 1} of {currentDemo.steps.length}
                  </span>
                </div>
                <Progress value={progress} className="w-full" />
              </div>

              {/* Current Step */}
              <div className="border rounded-lg p-6 bg-gradient-to-r from-blue-50 to-indigo-50">
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0">
                    {getStatusIcon(currentDemo.steps[currentStep]?.status)}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900 mb-2">
                      {currentDemo.steps[currentStep]?.title}
                    </h3>
                    <p className="text-gray-600 mb-4">
                      {currentDemo.steps[currentStep]?.description}
                    </p>
                    
                    {/* Step-specific content */}
                    {currentDemo.steps[currentStep]?.content && (
                      <div className="bg-white rounded border p-4">
                        <div className="text-sm">
                          <div className="font-medium">From: {currentDemo.steps[currentStep].content.from}</div>
                          <div className="font-medium">Subject: {currentDemo.steps[currentStep].content.subject}</div>
                          <div className="text-gray-600 mt-2">{currentDemo.steps[currentStep].content.preview}</div>
                        </div>
                      </div>
                    )}

                    {currentDemo.steps[currentStep]?.analysis && (
                      <div className="bg-white rounded border p-4">
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="font-medium">Keywords:</span>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {currentDemo.steps[currentStep].analysis.keywords.map((keyword: string, i: number) => (
                                <Badge key={i} variant="secondary" className="text-xs">{keyword}</Badge>
                              ))}
                            </div>
                          </div>
                          <div>
                            <span className="font-medium">Priority:</span>
                            <Badge variant="destructive" className="ml-2 text-xs">
                              {currentDemo.steps[currentStep].analysis.priority}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    )}

                    {currentDemo.steps[currentStep]?.actions && (
                      <div className="bg-white rounded border p-4">
                        <div className="space-y-2">
                          {currentDemo.steps[currentStep].actions.map((action: any, i: number) => (
                            <div key={i} className="flex items-center gap-2 text-sm">
                              <CheckCircle className="w-4 h-4 text-green-500" />
                              <span>{action.description}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {currentDemo.steps[currentStep]?.draft && (
                      <div className="bg-white rounded border p-4">
                        <div className="text-sm">
                          <div className="font-medium mb-2">Generated Draft:</div>
                          <div className="bg-gray-50 p-3 rounded">
                            <div className="font-medium">Subject: {currentDemo.steps[currentStep].draft.subject}</div>
                            <div className="mt-2 whitespace-pre-line">{currentDemo.steps[currentStep].draft.body}</div>
                          </div>
                          <div className="mt-2 flex items-center gap-2">
                            <span className="text-gray-600">Confidence:</span>
                            <Badge variant="default">{currentDemo.steps[currentStep].confidence}%</Badge>
                          </div>
                        </div>
                      </div>
                    )}

                    {currentDemo.steps[currentStep]?.event && (
                      <div className="bg-white rounded border p-4">
                        <div className="text-sm">
                          <div className="font-medium mb-2">Calendar Event Created:</div>
                          <div className="space-y-1">
                            <div><span className="font-medium">Title:</span> {currentDemo.steps[currentStep].event.title}</div>
                            <div><span className="font-medium">Date:</span> {currentDemo.steps[currentStep].event.date}</div>
                            <div><span className="font-medium">Time:</span> {currentDemo.steps[currentStep].event.time}</div>
                            <div><span className="font-medium">Location:</span> {currentDemo.steps[currentStep].event.location}</div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Manual Navigation */}
              <div className="flex items-center justify-between">
                <Button
                  variant="outline"
                  onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
                  disabled={currentStep === 0}
                >
                  Previous Step
                </Button>
                <div className="flex items-center gap-2">
                  {currentDemo.steps.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentStep(index)}
                      className={`w-3 h-3 rounded-full transition-colors ${
                        index === currentStep ? 'bg-blue-500' : 
                        index < currentStep ? 'bg-green-500' : 'bg-gray-300'
                      }`}
                    />
                  ))}
                </div>
                <Button
                  variant="outline"
                  onClick={nextStep}
                >
                  Next Step
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}