import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Check, Edit, X, Bot } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

export default function DraftReviewPanel() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: drafts, isLoading } = useQuery({
    queryKey: ["/api/drafts/pending"],
  });

  const updateDraftMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: any }) => {
      return apiRequest("PUT", `/api/drafts/${id}`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/drafts/pending"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/recent-activity"] });
      toast({ title: "Draft updated successfully" });
    },
    onError: () => {
      toast({ title: "Failed to update draft", variant: "destructive" });
    },
  });

  const handleDraftAction = (id: number, action: string) => {
    updateDraftMutation.mutate({
      id,
      updates: { status: action },
    });
  };

  const getProviderBadge = (provider: string) => {
    const colors = {
      openai: 'bg-green-100 text-green-800',
      claude: 'bg-purple-100 text-purple-800',
      gemini: 'bg-blue-100 text-blue-800',
    };
    return colors[provider as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>AI Draft Review</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(2)].map((_, i) => (
              <div key={i} className="p-4 border rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <Skeleton className="w-4 h-4" />
                  <Skeleton className="h-4 w-32" />
                  <Skeleton className="h-5 w-16" />
                </div>
                <Skeleton className="h-4 w-64 mb-2" />
                <Skeleton className="h-12 w-full mb-3" />
                <div className="flex space-x-2">
                  <Skeleton className="h-8 w-16" />
                  <Skeleton className="h-8 w-16" />
                  <Skeleton className="h-8 w-16" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!drafts?.length) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>AI Draft Review</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-gray-500">
            No pending drafts to review
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>AI Draft Review</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {drafts.map((draft: any) => (
            <div key={draft.id} className="p-4 border rounded-lg">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center space-x-2 mb-2">
                    <Bot className="w-4 h-4 text-blue-500" />
                    <span className="text-sm font-medium text-gray-800">
                      AI Generated Draft
                    </span>
                    <Badge className={getProviderBadge(draft.aiProvider)}>
                      {draft.aiProvider}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600 mb-2 font-medium">
                    {draft.subject}
                  </p>
                  <p className="text-xs text-gray-500 mb-3 line-clamp-2">
                    {draft.content}
                  </p>
                  <div className="flex items-center space-x-2">
                    <Button
                      size="sm"
                      onClick={() => handleDraftAction(draft.id, 'approved')}
                      disabled={updateDraftMutation.isPending}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <Check className="w-3 h-3 mr-1" />
                      Approve
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleDraftAction(draft.id, 'edited')}
                      disabled={updateDraftMutation.isPending}
                      className="border-yellow-300 text-yellow-700 hover:bg-yellow-50"
                    >
                      <Edit className="w-3 h-3 mr-1" />
                      Edit
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleDraftAction(draft.id, 'rejected')}
                      disabled={updateDraftMutation.isPending}
                      className="border-gray-300 text-gray-700 hover:bg-gray-50"
                    >
                      <X className="w-3 h-3 mr-1" />
                      Reject
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-4 pt-4 border-t border-gray-200">
          <Button variant="link" className="text-sm text-primary hover:text-primary/80 p-0">
            View all drafts →
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
