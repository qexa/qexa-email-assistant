import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDistanceToNow } from "date-fns";
import { Link } from "wouter";

export default function EmailActivity() {
  const { data: activity, isLoading } = useQuery({
    queryKey: ["/api/dashboard/recent-activity"],
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Recent Email Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="flex items-center justify-between p-4 hover:bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <Skeleton className="w-2 h-2 rounded-full" />
                  <div className="space-y-1">
                    <Skeleton className="h-4 w-48" />
                    <Skeleton className="h-3 w-32" />
                  </div>
                </div>
                <div className="text-right space-y-1">
                  <Skeleton className="h-5 w-20" />
                  <Skeleton className="h-3 w-16" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!activity?.recentEmails?.length) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Recent Email Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-gray-500">
            No recent email activity
          </div>
        </CardContent>
      </Card>
    );
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-red-100 text-red-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'low':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (processed: boolean) => {
    return processed ? 'bg-green-500' : 'bg-yellow-500';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Email Activity</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-1">
          {activity.recentEmails.map((email: any) => (
            <div key={email.id} className="flex items-center justify-between p-4 hover:bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className={`status-indicator ${getStatusColor(email.processed)}`} />
                <div>
                  <p className="text-sm font-medium text-gray-800 line-clamp-1">
                    {email.subject || 'No subject'}
                  </p>
                  <p className="text-xs text-gray-500 line-clamp-1">
                    {email.sender}
                  </p>
                </div>
              </div>
              <div className="text-right">
                {email.priority && (
                  <Badge className={`priority-badge ${getPriorityColor(email.priority)}`}>
                    {email.priority} Priority
                  </Badge>
                )}
                <p className="text-xs text-gray-500 mt-1">
                  {formatDistanceToNow(new Date(email.receivedAt), { addSuffix: true })}
                </p>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-4 pt-4 border-t border-gray-200">
          <Link href="/email-accounts">
            <Button variant="link" className="text-sm text-primary hover:text-primary/80 p-0">
              View all emails →
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
