import { Link, useLocation } from "wouter";
import { useState } from "react";
import { 
  Mail, 
  Inbox, 
  Settings, 
  Edit, 
  Calendar, 
  BarChart3, 
  Cog, 
  Gauge,
  User,
  BookOpen,
  Search,
  TrendingUp,
  Menu,
  X,
  Brain,
  Target,
  Bot
} from "lucide-react";
import { cn } from "@/lib/utils";
import qexaLogo from "@assets/qexa_logo-nobackground-1000 (2)_1752849845536.png";

const navigationItems = [
  { path: "/", label: "Dashboard", icon: Gauge },
  { path: "/ai-onboarding", label: "AI Onboarding", icon: Brain },
  { path: "/email-accounts", label: "Email Accounts", icon: Inbox },
  { path: "/ai-email-assistant", label: "AI Email Assistant", icon: Bot },
  { path: "/smart-search", label: "Smart Search", icon: Search },
  { path: "/classification-rules", label: "Classification Rules", icon: Settings },
  { path: "/calendar-integration", label: "Calendar Integration", icon: Calendar },
  { path: "/smart-prioritization", label: "Smart Priority", icon: Target },
  { path: "/analytics", label: "Analytics", icon: BarChart3 },
  { path: "/productivity-insights", label: "Productivity Insights", icon: TrendingUp },
  { path: "/settings", label: "Settings", icon: Cog },
  { path: "/user-guide", label: "User Guide", icon: BookOpen },
];

export default function Sidebar() {
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  const closeMobile = () => setIsOpen(false);

  return (
    <>
      {/* Mobile menu button */}
      <button
        className="lg:hidden fixed top-4 left-4 z-50 p-2 bg-white shadow-lg rounded-lg border border-gray-200"
        onClick={() => setIsOpen(true)}
      >
        <Menu className="w-5 h-5 text-gray-600" />
      </button>

      {/* Mobile overlay */}
      {isOpen && (
        <div 
          className="lg:hidden fixed inset-0 z-40 bg-black bg-opacity-50" 
          onClick={closeMobile}
        />
      )}

      {/* Sidebar */}
      <div className={cn(
        "bg-white shadow-lg border-r border-gray-200 flex flex-col transition-transform duration-300 ease-in-out",
        "fixed lg:static inset-y-0 left-0 z-50",
        "w-64 lg:w-64",
        isOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
      )}>
        {/* Mobile close button */}
        <button
          className="lg:hidden absolute top-4 right-4 p-2"
          onClick={closeMobile}
        >
          <X className="w-5 h-5 text-gray-600" />
        </button>

        {/* Logo/Brand */}
        <div className="p-4 sm:p-6 border-b border-gray-200">
          <div className="flex items-center justify-center">
            <img 
              src={qexaLogo} 
              alt="Qexa Logo" 
              className="h-10 sm:h-12 w-auto object-contain"
            />
          </div>
        </div>

        {/* Navigation Menu */}
        <nav className="flex-1 px-4 py-6 space-y-2 overflow-y-auto">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.path;
            
            return (
              <Link key={item.path} href={item.path}>
                <div 
                  className={cn(
                    "sidebar-nav-item",
                    isActive && "active"
                  )}
                  onClick={closeMobile}
                >
                  <Icon className="w-5 h-5 mr-3 flex-shrink-0" />
                  <span className="truncate">{item.label}</span>
                </div>
              </Link>
            );
          })}
        </nav>

        {/* User Profile */}
        <div className="p-4 border-t border-gray-200">
          <div className="flex items-center">
            <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center flex-shrink-0">
              <User className="w-4 h-4 text-gray-600" />
            </div>
            <div className="ml-3 min-w-0">
              <p className="text-sm font-medium text-gray-800 truncate">Admin User</p>
              <p className="text-xs text-gray-500 truncate">admin@example.com</p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
