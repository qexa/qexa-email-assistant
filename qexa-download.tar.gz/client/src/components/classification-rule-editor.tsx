import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Plus } from "lucide-react";

interface ClassificationRuleEditorProps {
  rule?: any;
  onClose?: () => void;
}

export default function ClassificationRuleEditor({ rule, onClose }: ClassificationRuleEditorProps) {
  const [open, setOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: rule?.name || "",
    priority: rule?.priority || "medium",
    keywords: rule?.keywords?.join(", ") || "",
    senderPatterns: rule?.senderPatterns?.join(", ") || "",
    actions: {
      flag: rule?.actions?.flag || false,
      createDraft: rule?.actions?.createDraft || false,
      createCalendar: rule?.actions?.createCalendar || false,
      moveFolder: rule?.actions?.moveFolder || "",
    },
  });

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createRuleMutation = useMutation({
    mutationFn: async (data: any) => {
      const url = rule ? `/api/classification-rules/${rule.id}` : "/api/classification-rules";
      const method = rule ? "PUT" : "POST";
      return apiRequest(method, url, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/classification-rules"] });
      toast({ title: `Rule ${rule ? 'updated' : 'created'} successfully` });
      setOpen(false);
      onClose?.();
    },
    onError: () => {
      toast({ title: "Failed to save rule", variant: "destructive" });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const ruleData = {
      name: formData.name,
      priority: formData.priority,
      keywords: formData.keywords.split(",").map(k => k.trim()).filter(k => k),
      senderPatterns: formData.senderPatterns.split(",").map(p => p.trim()).filter(p => p),
      actions: {
        flag: formData.actions.flag,
        createDraft: formData.actions.createDraft,
        createCalendar: formData.actions.createCalendar,
        moveFolder: formData.actions.moveFolder || undefined,
      },
      isActive: true,
    };

    createRuleMutation.mutate(ruleData);
  };

  const handleInputChange = (field: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleActionChange = (action: string, value: any) => {
    setFormData(prev => ({
      ...prev,
      actions: {
        ...prev.actions,
        [action]: value,
      },
    }));
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="bg-primary text-white hover:bg-primary/90">
          <Plus className="w-4 h-4 mr-2" />
          Add Rule
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>
            {rule ? 'Edit Classification Rule' : 'Create Classification Rule'}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <div>
              <Label htmlFor="name">Rule Name</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                placeholder="Enter rule name"
                required
              />
            </div>

            <div>
              <Label htmlFor="priority">Priority Level</Label>
              <Select value={formData.priority} onValueChange={(value) => handleInputChange('priority', value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select priority" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="high">High Priority</SelectItem>
                  <SelectItem value="medium">Medium Priority</SelectItem>
                  <SelectItem value="low">Low Priority</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="keywords">Keywords (comma-separated)</Label>
              <Input
                id="keywords"
                value={formData.keywords}
                onChange={(e) => handleInputChange('keywords', e.target.value)}
                placeholder="urgent, meeting, invoice"
              />
            </div>

            <div>
              <Label htmlFor="senderPatterns">Sender Patterns (comma-separated)</Label>
              <Input
                id="senderPatterns"
                value={formData.senderPatterns}
                onChange={(e) => handleInputChange('senderPatterns', e.target.value)}
                placeholder="@company.com, @client.com"
              />
            </div>

            <div>
              <Label>Actions</Label>
              <div className="space-y-3 mt-2">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="flag"
                    checked={formData.actions.flag}
                    onCheckedChange={(checked) => handleActionChange('flag', checked)}
                  />
                  <Label htmlFor="flag" className="text-sm">Flag as important</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="createDraft"
                    checked={formData.actions.createDraft}
                    onCheckedChange={(checked) => handleActionChange('createDraft', checked)}
                  />
                  <Label htmlFor="createDraft" className="text-sm">Create AI draft response</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="createCalendar"
                    checked={formData.actions.createCalendar}
                    onCheckedChange={(checked) => handleActionChange('createCalendar', checked)}
                  />
                  <Label htmlFor="createCalendar" className="text-sm">Create calendar event</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="moveFolder"
                    checked={!!formData.actions.moveFolder}
                    onCheckedChange={(checked) => handleActionChange('moveFolder', checked ? 'inbox' : '')}
                  />
                  <Label htmlFor="moveFolder" className="text-sm">Move to folder</Label>
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-3">
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={createRuleMutation.isPending}
              className="bg-primary text-white hover:bg-primary/90"
            >
              {createRuleMutation.isPending ? 'Saving...' : (rule ? 'Update Rule' : 'Save Rule')}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
