import qexaLogo from "@assets/qexa_logo-nobackground-1000 (2)_1752849845536.png";
import { Link } from "wouter";

export default function Header() {
  return (
    <header className="bg-white shadow-sm border-b border-gray-200 px-4 sm:px-6 py-2 sm:py-3 fixed top-0 left-0 right-0 z-40 lg:left-64">
      <div className="flex items-center justify-center lg:justify-start">
        {/* Logo - Centered on mobile, left on desktop */}
        <Link href="/" className="flex items-center hover:opacity-75 transition-opacity ml-12 lg:ml-0">
          <img 
            src={qexaLogo} 
            alt="Qexa" 
            className="h-8 w-auto sm:h-10 lg:h-12 object-contain"
          />
        </Link>
      </div>
    </header>
  );
}