import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RefreshCw, ExternalLink, Calendar, Plus, BookOpen, ArrowRight } from "lucide-react";
import StatsOverview from "@/components/stats-overview";
import EmailActivity from "@/components/email-activity";
import DraftReviewPanel from "@/components/draft-review-panel";
import ClassificationRuleEditor from "@/components/classification-rule-editor";
import { Link } from "wouter";

export default function Dashboard() {
  const { data: recentEvents, isLoading: eventsLoading } = useQuery({
    queryKey: ["/api/calendar-events/recent"],
  });

  const { data: calendarSettings, isLoading: settingsLoading } = useQuery({
    queryKey: ["/api/calendar/settings"],
  });

  const { data: aiProviders, isLoading: providersLoading } = useQuery({
    queryKey: ["/api/ai-providers"],
  });

  const { data: rules, isLoading: rulesLoading } = useQuery({
    queryKey: ["/api/classification-rules"],
  });

  const { data: accounts, isLoading: accountsLoading } = useQuery({
    queryKey: ["/api/email-accounts"],
  });

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 px-4 sm:px-6 py-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="min-w-0 flex-1">
            <h1 className="text-xl sm:text-2xl font-semibold text-gray-800 break-words">
              Qexa Email Assistant Dashboard
            </h1>
            <p className="text-sm text-gray-600 mt-1">
              Monitor and manage automated email processing
            </p>
          </div>
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-4">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-500 rounded-full flex-shrink-0"></div>
              <span className="text-sm text-gray-600">System Active</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="text-xs sm:text-sm text-gray-500">
                Last sync: 2 minutes ago
              </div>
              <Button variant="outline" size="sm" className="h-8 w-8 p-0">
                <RefreshCw className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Dashboard Content */}
      <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-50 p-4 sm:p-6">
        {/* Welcome & Getting Started */}
        {(!accounts?.length || !rules?.length) && (
          <Card className="mb-6 sm:mb-8 bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
            <CardContent className="p-4 sm:p-6">
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-start gap-3 mb-4">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg bg-blue-100 flex items-center justify-center flex-shrink-0">
                      <BookOpen className="w-5 h-5 sm:w-6 sm:h-6 text-blue-600" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <h3 className="text-base sm:text-lg font-semibold text-gray-900 break-words">
                        Welcome to Qexa Email Assistant!
                      </h3>
                      <p className="text-sm sm:text-base text-gray-600 mt-1">
                        Get started by setting up your first email account and classification rules.
                      </p>
                    </div>
                  </div>
                  <div className="space-y-2 sm:grid sm:grid-cols-2 sm:gap-4 sm:space-y-0">
                    {!accounts?.length && (
                      <div className="flex items-center gap-2 text-xs sm:text-sm text-gray-600">
                        <div className="w-2 h-2 rounded-full bg-orange-400 flex-shrink-0"></div>
                        <span>No email accounts connected yet</span>
                      </div>
                    )}
                    {!rules?.length && (
                      <div className="flex items-center gap-2 text-xs sm:text-sm text-gray-600">
                        <div className="w-2 h-2 rounded-full bg-orange-400 flex-shrink-0"></div>
                        <span>No classification rules created yet</span>
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex-shrink-0 w-full sm:w-auto">
                  <Link href="/user-guide">
                    <Button variant="outline" className="w-full sm:w-auto text-sm">
                      <BookOpen className="w-4 h-4 mr-2" />
                      <span className="sm:hidden">Guide</span>
                      <span className="hidden sm:inline">View Complete Guide</span>
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </Link>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Stats Overview */}
        <div className="mb-6 sm:mb-8">
          <StatsOverview />
        </div>

        {/* Recent Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6 mb-6 sm:mb-8">
          <EmailActivity />
          <DraftReviewPanel />
        </div>

        {/* Configuration Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6 mb-6 sm:mb-8">
          {/* Classification Rules */}
          <Card>
            <CardHeader className="pb-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <CardTitle className="text-base sm:text-lg">Classification Rules</CardTitle>
                <div className="flex-shrink-0">
                  <ClassificationRuleEditor />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {rulesLoading ? (
                <div className="text-center py-4 text-gray-500 text-sm">Loading rules...</div>
              ) : !rules?.length ? (
                <div className="text-center py-4 text-gray-500 text-sm">No rules configured</div>
              ) : (
                <div className="space-y-3 sm:space-y-4">
                  {rules.slice(0, 3).map((rule: any) => (
                    <div key={rule.id} className="border border-gray-200 rounded-lg p-3 sm:p-4">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 sm:gap-3 mb-3">
                        <div className="flex items-center space-x-2 sm:space-x-3 min-w-0 flex-1">
                          <div className={`w-3 h-3 sm:w-4 sm:h-4 rounded-full flex-shrink-0 ${
                            rule.priority === 'high' ? 'bg-red-500' :
                            rule.priority === 'medium' ? 'bg-yellow-500' : 'bg-green-500'
                          }`}></div>
                          <span className="font-medium text-gray-800 text-sm sm:text-base break-words">{rule.name}</span>
                        </div>
                        <Badge variant={rule.isActive ? "default" : "secondary"} className="text-xs flex-shrink-0">
                          {rule.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </div>
                      <div className="space-y-1 sm:space-y-2">
                        <div className="text-xs sm:text-sm text-gray-600">
                          <strong>Keywords:</strong> <span className="break-words">{rule.keywords?.join(", ") || "None"}</span>
                        </div>
                        <div className="text-xs sm:text-sm text-gray-600">
                          <strong>Senders:</strong> <span className="break-words">{rule.senderPatterns?.join(", ") || "None"}</span>
                        </div>
                        <div className="text-xs sm:text-sm text-gray-600">
                          <strong>Actions:</strong> <span className="break-words">{
                            Object.entries(rule.actions || {})
                              .filter(([_, value]) => value)
                              .map(([key, _]) => key)
                              .join(", ") || "None"
                          }</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Email Accounts */}
          <Card>
            <CardHeader className="pb-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <CardTitle className="text-base sm:text-lg">Email Accounts</CardTitle>
                <Button size="sm" className="bg-primary text-white hover:bg-primary/90 w-full sm:w-auto text-sm">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Account
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {accountsLoading ? (
                <div className="text-center py-4 text-gray-500 text-sm">Loading accounts...</div>
              ) : !accounts?.length ? (
                <div className="text-center py-4 text-gray-500 text-sm">No accounts configured</div>
              ) : (
                <div className="space-y-3 sm:space-y-4">
                  {accounts.map((account: any) => (
                    <div key={account.id} className="flex flex-col sm:flex-row sm:items-center justify-between p-3 sm:p-4 border border-gray-200 rounded-lg gap-3 sm:gap-0">
                      <div className="flex items-center space-x-3 min-w-0 flex-1">
                        <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <span className="text-blue-600 font-semibold text-sm">
                            {account.provider.charAt(0).toUpperCase()}
                          </span>
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="font-medium text-gray-800 text-sm sm:text-base break-all">{account.email}</p>
                          <p className="text-xs sm:text-sm text-gray-500 capitalize">{account.provider}</p>
                        </div>
                      </div>
                      <div className="flex items-center justify-center sm:justify-end">
                        <div className="flex items-center space-x-2">
                          <div className={`w-2 h-2 rounded-full flex-shrink-0 ${
                            account.isActive ? 'bg-green-500' : 'bg-red-500'
                          }`}></div>
                          <span className="text-xs sm:text-sm text-gray-600">
                            {account.isActive ? 'Active' : 'Inactive'}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Calendar Integration */}
        <Card className="mb-6 sm:mb-8">
          <CardHeader className="pb-4">
            <CardTitle className="text-base sm:text-lg">Google Calendar Integration</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
              {/* Recent Calendar Events */}
              <div className="space-y-3 sm:space-y-4">
                <h4 className="text-sm sm:text-base font-medium text-gray-800">Recent Calendar Events</h4>
                {eventsLoading ? (
                  <div className="text-center py-4 text-gray-500 text-sm">Loading events...</div>
                ) : !recentEvents?.length ? (
                  <div className="text-center py-4 text-gray-500 text-sm">No recent events</div>
                ) : (
                  <div className="space-y-3">
                    {recentEvents.slice(0, 3).map((event: any) => (
                      <div key={event.id} className="flex items-center space-x-3 sm:space-x-4 p-3 sm:p-4 border border-gray-200 rounded-lg">
                        <div className="w-8 h-8 sm:w-10 sm:h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          <Calendar className="w-4 h-4 sm:w-5 sm:h-5 text-green-600" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-gray-800 text-sm sm:text-base break-words">{event.title}</p>
                          <p className="text-xs sm:text-sm text-gray-600 break-words">
                            {new Date(event.startTime).toLocaleString()}
                          </p>
                          <p className="text-xs text-gray-500">
                            Created from email
                          </p>
                        </div>
                        <Button variant="ghost" size="sm" className="flex-shrink-0 h-8 w-8 p-0">
                          <ExternalLink className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Calendar Settings */}
              <div className="space-y-3 sm:space-y-4">
                <h4 className="text-sm sm:text-base font-medium text-gray-800">Calendar Settings</h4>
                {settingsLoading ? (
                  <div className="text-center py-4 text-gray-500 text-sm">Loading settings...</div>
                ) : (
                  <div className="space-y-3">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between p-3 bg-gray-50 rounded-lg gap-3 sm:gap-0">
                      <div className="min-w-0 flex-1">
                        <p className="text-xs sm:text-sm font-medium text-gray-800">Auto-create calendar events</p>
                        <p className="text-xs text-gray-500">For meeting requests and appointments</p>
                      </div>
                      <div className="flex-shrink-0">
                        <Switch
                          checked={calendarSettings?.autoCreateEvents || false}
                          onCheckedChange={() => {}}
                        />
                      </div>
                    </div>
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between p-3 bg-gray-50 rounded-lg gap-3 sm:gap-0">
                      <div className="min-w-0 flex-1">
                        <p className="text-xs sm:text-sm font-medium text-gray-800">Default event duration</p>
                        <p className="text-xs text-gray-500">When duration is not specified</p>
                      </div>
                      <div className="flex-shrink-0 w-full sm:w-auto">
                        <Select value={calendarSettings?.defaultDuration?.toString() || "60"}>
                          <SelectTrigger className="w-full sm:w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="30">30 minutes</SelectItem>
                            <SelectItem value="60">1 hour</SelectItem>
                            <SelectItem value="90">1.5 hours</SelectItem>
                            <SelectItem value="120">2 hours</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* AI Provider Settings */}
        <Card>
          <CardHeader className="pb-4">
            <CardTitle className="text-base sm:text-lg">AI Provider Configuration</CardTitle>
          </CardHeader>
          <CardContent>
            {providersLoading ? (
              <div className="text-center py-4 text-gray-500 text-sm">Loading providers...</div>
            ) : !aiProviders?.length ? (
              <div className="text-center py-4 text-gray-500 text-sm">No AI providers configured</div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                {aiProviders.map((provider: any) => (
                  <div key={provider.id} className="border border-gray-200 rounded-lg p-3 sm:p-4">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 sm:gap-4 mb-3 sm:mb-4">
                      <div className="flex items-center space-x-3 min-w-0 flex-1">
                        <div className={`w-8 h-8 sm:w-10 sm:h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
                          provider.name === 'openai' ? 'bg-green-100' :
                          provider.name === 'claude' ? 'bg-purple-100' : 'bg-blue-100'
                        }`}>
                          <span className={`text-xs sm:text-sm font-semibold ${
                            provider.name === 'openai' ? 'text-green-600' :
                            provider.name === 'claude' ? 'text-purple-600' : 'text-blue-600'
                          }`}>
                            {provider.name.charAt(0).toUpperCase()}
                          </span>
                        </div>
                        <div className="min-w-0 flex-1">
                          <h4 className="font-medium text-gray-800 capitalize text-sm sm:text-base break-words">{provider.name}</h4>
                          <p className="text-xs sm:text-sm text-gray-500">
                            {provider.name === 'openai' ? 'GPT-4' : 
                             provider.name === 'claude' ? 'Claude 3' : 'Gemini Pro'}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center justify-center sm:justify-end space-x-2 flex-shrink-0">
                        <div className={`w-2 h-2 rounded-full ${
                          provider.isActive ? 'bg-green-500' : 'bg-gray-400'
                        }`}></div>
                        <span className="text-xs sm:text-sm text-gray-600">
                          {provider.isActive ? 'Active' : 'Inactive'}
                        </span>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-xs sm:text-sm">
                        <span className="text-gray-600">Usage today:</span>
                        <span className="font-medium">{provider.usageToday} requests</span>
                      </div>
                      <div className="flex justify-between text-xs sm:text-sm">
                        <span className="text-gray-600">Success rate:</span>
                        <span className="font-medium text-green-600">{provider.successRate}%</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
