import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { insertEmailAccountSchema } from "@shared/schema";
import { Plus, Settings, Trash2, RefreshCw, Inbox, Computer, Mail as MailIcon } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

const emailAccountFormSchema = insertEmailAccountSchema.extend({
  password: z.string().optional(),
  imapHost: z.string().optional(),
  imapPort: z.string().optional(),
});

type EmailAccountForm = z.infer<typeof emailAccountFormSchema>;

export default function EmailAccounts() {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingAccount, setEditingAccount] = useState<any>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: accounts, isLoading } = useQuery({
    queryKey: ["/api/email-accounts"],
  });

  const form = useForm<EmailAccountForm>({
    resolver: zodResolver(emailAccountFormSchema),
    defaultValues: {
      email: "",
      provider: "gmail",
      isActive: true,
      imapHost: "",
      imapPort: "993",
    },
  });

  const createAccountMutation = useMutation({
    mutationFn: async (data: EmailAccountForm) => {
      const accountData = {
        email: data.email,
        provider: data.provider,
        isActive: data.isActive,
        imapConfig: data.provider === 'imap' ? {
          host: data.imapHost,
          port: parseInt(data.imapPort || '993'),
          secure: true,
          auth: {
            user: data.email,
            pass: data.password,
          },
        } : null,
      };

      const url = editingAccount ? `/api/email-accounts/${editingAccount.id}` : "/api/email-accounts";
      const method = editingAccount ? "PUT" : "POST";
      return apiRequest(method, url, accountData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/email-accounts"] });
      toast({ title: `Account ${editingAccount ? 'updated' : 'created'} successfully` });
      setDialogOpen(false);
      setEditingAccount(null);
      form.reset();
    },
    onError: (error: any) => {
      toast({ 
        title: "Failed to save account", 
        description: error.message,
        variant: "destructive" 
      });
    },
  });

  const deleteAccountMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/email-accounts/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/email-accounts"] });
      toast({ title: "Account deleted successfully" });
    },
    onError: () => {
      toast({ title: "Failed to delete account", variant: "destructive" });
    },
  });

  const toggleAccountMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: number; isActive: boolean }) => {
      return apiRequest("PUT", `/api/email-accounts/${id}`, { isActive });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/email-accounts"] });
      toast({ title: "Account status updated" });
    },
    onError: () => {
      toast({ title: "Failed to update account", variant: "destructive" });
    },
  });

  const handleEditAccount = (account: any) => {
    setEditingAccount(account);
    form.reset({
      email: account.email,
      provider: account.provider,
      isActive: account.isActive,
      imapHost: account.imapConfig?.host || "",
      imapPort: account.imapConfig?.port?.toString() || "993",
    });
    setDialogOpen(true);
  };

  const onSubmit = (data: EmailAccountForm) => {
    createAccountMutation.mutate(data);
  };

  const getProviderIcon = (provider: string) => {
    switch (provider) {
      case 'gmail':
        return <Inbox className="w-5 h-5 text-red-500" />;
      case 'outlook':
        return <Computer className="w-5 h-5 text-blue-500" />;
      default:
        return <MailIcon className="w-5 h-5 text-gray-500" />;
    }
  };

  const getProviderColor = (provider: string) => {
    switch (provider) {
      case 'gmail':
        return 'bg-red-100 text-red-800';
      case 'outlook':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="p-4 sm:p-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
        <div>
          <h1 className="text-xl sm:text-2xl font-semibold text-gray-800">Email Accounts</h1>
          <p className="text-sm text-gray-600 mt-1">Manage your connected email accounts</p>
        </div>
        <div className="flex flex-col sm:flex-row gap-2 sm:gap-3">
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-primary text-white hover:bg-primary/90 w-full sm:w-auto" size="sm">
                  <Plus className="w-4 h-4 mr-2" />
                  <span className="hidden sm:inline">Add Email Account</span>
                  <span className="sm:hidden">Add Account</span>
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md mx-4 sm:mx-0">
              <DialogHeader>
                <DialogTitle>
                  {editingAccount ? 'Edit Email Account' : 'Add Email Account'}
                </DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email Address</FormLabel>
                        <FormControl>
                          <Input placeholder="your@email.com" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="provider"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Provider</FormLabel>
                        <Select onValueChange={field.onChange} value={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select provider" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="gmail">Gmail (App Password)</SelectItem>
                            <SelectItem value="outlook">Outlook</SelectItem>
                            <SelectItem value="imap">Other IMAP</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {form.watch("provider") === "gmail" && (
                    <div className="space-y-4">
                      <div className="p-4 bg-blue-50 rounded-lg border">
                        <h4 className="font-medium text-blue-900 mb-2">Gmail App Password Setup (2 minutes)</h4>
                        <ol className="text-sm text-blue-800 space-y-1 list-decimal list-inside">
                          <li>Go to your <a href="https://myaccount.google.com/security" target="_blank" className="underline">Google Account Security</a></li>
                          <li>Enable "2-Step Verification" if not already enabled</li>
                          <li>Click "App passwords" and generate a password for "Qexa"</li>
                          <li>Use that 16-character password below (not your regular Gmail password)</li>
                        </ol>
                      </div>
                      
                      <FormField
                        control={form.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Gmail App Password</FormLabel>
                            <FormControl>
                              <Input 
                                type="password" 
                                placeholder="16-character app password (xxxx xxxx xxxx xxxx)" 
                                {...field} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  )}

                  {form.watch("provider") === "imap" && (
                    <>
                      <FormField
                        control={form.control}
                        name="imapHost"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>IMAP Host</FormLabel>
                            <FormControl>
                              <Input placeholder="imap.example.com" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="imapPort"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>IMAP Port</FormLabel>
                            <FormControl>
                              <Input placeholder="993" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Password</FormLabel>
                            <FormControl>
                              <Input type="password" placeholder="Email password" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </>
                  )}

                  {form.watch("provider") === "outlook" && (
                    <div className="space-y-4">
                      <div className="p-4 bg-blue-50 rounded-lg border">
                        <h4 className="font-medium text-blue-900 mb-2">Outlook Setup</h4>
                        <p className="text-sm text-blue-800">
                          Use your regular Outlook.com password. Make sure IMAP is enabled in your Outlook settings.
                        </p>
                      </div>
                      
                      <FormField
                        control={form.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Password</FormLabel>
                            <FormControl>
                              <Input type="password" placeholder="Your Outlook password" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  )}

                  <FormField
                    control={form.control}
                    name="isActive"
                    render={({ field }) => (
                      <FormItem className="flex items-center justify-between">
                        <FormLabel>Active</FormLabel>
                        <FormControl>
                          <Switch
                            checked={!!field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-2 sm:gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => {
                        setDialogOpen(false);
                        setEditingAccount(null);
                        form.reset();
                      }}
                      className="w-full sm:w-auto"
                    >
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      disabled={createAccountMutation.isPending}
                      className="bg-primary text-white hover:bg-primary/90 w-full sm:w-auto"
                    >
                      {createAccountMutation.isPending ? 'Saving...' : 'Save'}
                    </Button>
                  </div>
                </form>
              </Form>
              </DialogContent>
            </Dialog>
        </div>
      </div>

      <div className="max-w-7xl mx-auto">
        {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
              {[...Array(3)].map((_, i) => (
                <Card key={i}>
                  <CardContent className="p-4 sm:p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <Skeleton className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg" />
                        <div className="space-y-2">
                          <Skeleton className="h-4 w-24 sm:w-32" />
                          <Skeleton className="h-3 w-16 sm:w-20" />
                        </div>
                      </div>
                      <Skeleton className="w-12 h-6 sm:w-16 rounded-full" />
                    </div>
                    <div className="space-y-2">
                      <Skeleton className="h-3 w-20 sm:w-24" />
                      <Skeleton className="h-3 w-24 sm:w-32" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : !accounts || !Array.isArray(accounts) || !accounts.length ? (
            <Card>
              <CardContent className="p-8 sm:p-12 text-center">
                <MailIcon className="w-12 h-12 sm:w-16 sm:h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No email accounts</h3>
                <p className="text-sm sm:text-base text-gray-500 mb-6 px-4">
                  Connect your email accounts to start processing emails automatically.
                </p>
                <Button
                  onClick={() => setDialogOpen(true)}
                  className="bg-primary text-white hover:bg-primary/90 w-full sm:w-auto"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Your First Account
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
              {Array.isArray(accounts) && accounts.map((account: any) => (
                <Card key={account.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4 sm:p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-3 min-w-0 flex-1">
                        <div className="w-8 h-8 sm:w-10 sm:h-10 bg-gray-100 rounded-lg flex items-center justify-center flex-shrink-0">
                          {getProviderIcon(account.provider)}
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="font-medium text-gray-900 truncate text-sm sm:text-base">{account.email}</p>
                          <Badge className={`text-xs ${getProviderColor(account.provider)} mt-1`}>
                            {account.provider.toUpperCase()}
                          </Badge>
                        </div>
                      </div>
                      <div className="flex-shrink-0 ml-2">
                        <Switch
                          checked={account.isActive}
                          onCheckedChange={(checked) => 
                            toggleAccountMutation.mutate({ id: account.id, isActive: checked })
                          }
                          disabled={toggleAccountMutation.isPending}
                        />
                      </div>
                    </div>

                    <div className="space-y-2 text-sm text-gray-500 mb-4">
                      <div className="flex items-center justify-between">
                        <span>Status:</span>
                        <div className="flex items-center space-x-2">
                          <div className={`w-2 h-2 rounded-full ${
                            account.isActive ? 'bg-green-500' : 'bg-gray-400'
                          }`} />
                          <span>{account.isActive ? 'Active' : 'Inactive'}</span>
                        </div>
                      </div>
                      {account.lastSyncAt && (
                        <div className="flex items-center justify-between">
                          <span>Last sync:</span>
                          <span className="text-right text-xs sm:text-sm">{formatDistanceToNow(new Date(account.lastSyncAt), { addSuffix: true })}</span>
                        </div>
                      )}
                    </div>

                    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 sm:gap-0">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEditAccount(account)}
                        className="w-full sm:w-auto"
                      >
                        <Settings className="w-4 h-4 mr-2" />
                        Configure
                      </Button>
                      <div className="flex items-center justify-center sm:justify-end space-x-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            // Trigger sync
                            toast({ title: "Sync initiated" });
                          }}
                          className="flex-1 sm:flex-none"
                        >
                          <RefreshCw className="w-4 h-4 sm:mr-0" />
                          <span className="sm:hidden ml-2">Sync</span>
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteAccountMutation.mutate(account.id)}
                          disabled={deleteAccountMutation.isPending}
                          className="text-red-600 hover:text-red-700 flex-1 sm:flex-none"
                        >
                          <Trash2 className="w-4 h-4 sm:mr-0" />
                          <span className="sm:hidden ml-2">Delete</span>
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
      </div>
    </div>
  );
}
