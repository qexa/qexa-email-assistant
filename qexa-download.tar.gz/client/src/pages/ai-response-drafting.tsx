import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { 
  Bot, 
  Send, 
  RefreshCw, 
  ThumbsUp, 
  ThumbsDown, 
  Edit3, 
  Copy,
  Wand2,
  Clock,
  Target,
  BarChart3,
  Settings,
  MessageSquare,
  Mail,
  ChevronRight,
  Sparkles
} from "lucide-react";

interface EmailContext {
  originalEmail: {
    id?: string;
    subject: string;
    sender: string;
    body: string;
    urgencyScore?: number;
    sentiment?: string;
    actionRequired?: boolean;
  };
  senderHistory?: {
    relationship: string;
    previousEmails: number;
    lastInteraction?: string;
    communicationStyle?: string;
  };
  userPreferences?: {
    tone: 'professional' | 'casual' | 'formal' | 'friendly';
    length: 'brief' | 'detailed' | 'comprehensive';
    includeQuestions?: boolean;
    autoSignature?: boolean;
  };
}

interface DraftResponse {
  id?: number;
  subject: string;
  content: string;
  tone: string;
  responseType: string;
  confidence: number;
  contextUsed: {
    previousEmails?: boolean;
    relationshipHistory?: boolean;
    urgencyLevel?: string;
    detectedIntent?: string;
  };
  alternatives: Array<{
    tone: string;
    content: string;
    confidence: number;
  }>;
  reasoning: string;
  createdAt?: string;
}

export default function AIResponseDrafting() {
  const [emailContext, setEmailContext] = useState<EmailContext>({
    originalEmail: {
      subject: "",
      sender: "",
      body: "",
    },
    userPreferences: {
      tone: 'professional',
      length: 'brief'
    }
  });
  
  const [userInstructions, setUserInstructions] = useState("");
  const [selectedDraft, setSelectedDraft] = useState<DraftResponse | null>(null);
  const [improvements, setImprovements] = useState("");
  const [activeTab, setActiveTab] = useState("generate");
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch existing drafts
  const { data: drafts, isLoading: draftsLoading } = useQuery({
    queryKey: ["/api/drafts"],
  });

  // Generate response mutation
  const generateResponseMutation = useMutation({
    mutationFn: async (data: { emailContext: EmailContext; userInstructions?: string }): Promise<DraftResponse> => {
      const response = await apiRequest("POST", "/api/drafts/generate-response", data);
      return response as DraftResponse;
    },
    onSuccess: (response: DraftResponse) => {
      setSelectedDraft(response);
      setActiveTab("review");
      queryClient.invalidateQueries({ queryKey: ["/api/drafts"] });
      toast({ 
        title: "Response generated successfully", 
        description: `Created ${response.responseType} with ${response.confidence}% confidence` 
      });
    },
    onError: (error: any) => {
      toast({ 
        title: "Failed to generate response", 
        description: error.message,
        variant: "destructive" 
      });
    },
  });

  // Improve draft mutation
  const improveDraftMutation = useMutation({
    mutationFn: async (data: { id: number; improvements: string; emailContext: EmailContext }) => {
      const response = await apiRequest("POST", `/api/drafts/${data.id}/improve`, {
        improvements: data.improvements,
        emailContext: data.emailContext
      });
      return response as any;
    },
    onSuccess: (response: any) => {
      setSelectedDraft({ ...selectedDraft!, content: response.draft.content, confidence: response.confidence });
      setImprovements("");
      queryClient.invalidateQueries({ queryKey: ["/api/drafts"] });
      toast({ 
        title: "Draft improved successfully",
        description: `${response.changes?.length || 0} changes made`
      });
    },
    onError: (error: any) => {
      toast({ 
        title: "Failed to improve draft", 
        description: error.message,
        variant: "destructive" 
      });
    },
  });

  // Approve draft mutation
  const approveDraftMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("PUT", `/api/drafts/${id}`, { status: "approved" });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/drafts"] });
      toast({ title: "Draft approved and ready to send" });
    },
  });

  const handleGenerateResponse = () => {
    if (!emailContext.originalEmail.subject || !emailContext.originalEmail.body) {
      toast({ 
        title: "Missing information", 
        description: "Please fill in the email subject and body",
        variant: "destructive" 
      });
      return;
    }
    
    generateResponseMutation.mutate({ emailContext, userInstructions });
  };

  const handleImproveDraft = () => {
    if (!selectedDraft?.id || !improvements.trim()) {
      toast({ 
        title: "Missing information", 
        description: "Please provide improvement instructions",
        variant: "destructive" 
      });
      return;
    }
    
    improveDraftMutation.mutate({
      id: selectedDraft.id,
      improvements,
      emailContext
    });
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Copied to clipboard" });
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 80) return "text-green-600 bg-green-100";
    if (confidence >= 60) return "text-yellow-600 bg-yellow-100";
    return "text-red-600 bg-red-100";
  };

  return (
    <div className="p-4 sm:p-6 max-w-7xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-gray-800 flex items-center gap-2">
          <Wand2 className="w-6 h-6 text-blue-500" />
          AI-Powered Email Response Drafting
        </h1>
        <p className="text-gray-600 mt-1">Generate intelligent, context-aware email responses using AI</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="generate" className="flex items-center gap-2">
            <Bot className="w-4 h-4" />
            Generate
          </TabsTrigger>
          <TabsTrigger value="review" className="flex items-center gap-2">
            <MessageSquare className="w-4 h-4" />
            Review
          </TabsTrigger>
          <TabsTrigger value="history" className="flex items-center gap-2">
            <Clock className="w-4 h-4" />
            History
          </TabsTrigger>
        </TabsList>

        <TabsContent value="generate" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Input Form */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Mail className="w-5 h-5" />
                  Original Email
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="sender">From</Label>
                  <Input
                    id="sender"
                    placeholder="sender@example.com"
                    value={emailContext.originalEmail.sender}
                    onChange={(e) => setEmailContext({
                      ...emailContext,
                      originalEmail: { ...emailContext.originalEmail, sender: e.target.value }
                    })}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="subject">Subject</Label>
                  <Input
                    id="subject"
                    placeholder="Email subject"
                    value={emailContext.originalEmail.subject}
                    onChange={(e) => setEmailContext({
                      ...emailContext,
                      originalEmail: { ...emailContext.originalEmail, subject: e.target.value }
                    })}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="body">Email Body</Label>
                  <Textarea
                    id="body"
                    placeholder="Paste the email content here..."
                    rows={8}
                    value={emailContext.originalEmail.body}
                    onChange={(e) => setEmailContext({
                      ...emailContext,
                      originalEmail: { ...emailContext.originalEmail, body: e.target.value }
                    })}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Preferences */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5" />
                  Response Preferences
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Tone</Label>
                    <Select
                      value={emailContext.userPreferences?.tone}
                      onValueChange={(value: any) => setEmailContext({
                        ...emailContext,
                        userPreferences: { ...emailContext.userPreferences!, tone: value }
                      })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="professional">Professional</SelectItem>
                        <SelectItem value="formal">Formal</SelectItem>
                        <SelectItem value="casual">Casual</SelectItem>
                        <SelectItem value="friendly">Friendly</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Length</Label>
                    <Select
                      value={emailContext.userPreferences?.length}
                      onValueChange={(value: any) => setEmailContext({
                        ...emailContext,
                        userPreferences: { ...emailContext.userPreferences!, length: value }
                      })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="brief">Brief</SelectItem>
                        <SelectItem value="detailed">Detailed</SelectItem>
                        <SelectItem value="comprehensive">Comprehensive</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="instructions">Special Instructions (Optional)</Label>
                  <Textarea
                    id="instructions"
                    placeholder="e.g., Include pricing information, mention upcoming deadline, ask for clarification..."
                    rows={4}
                    value={userInstructions}
                    onChange={(e) => setUserInstructions(e.target.value)}
                  />
                </div>
                
                <Button 
                  onClick={handleGenerateResponse}
                  disabled={generateResponseMutation.isPending}
                  className="w-full"
                  size="lg"
                >
                  {generateResponseMutation.isPending ? (
                    <>
                      <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                      Generating Response...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Generate AI Response
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="review" className="space-y-6">
          {selectedDraft ? (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Main Draft */}
              <div className="lg:col-span-2 space-y-4">
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center gap-2">
                        <MessageSquare className="w-5 h-5" />
                        Generated Response
                      </CardTitle>
                      <div className="flex items-center gap-2">
                        <Badge className={getConfidenceColor(selectedDraft.confidence)}>
                          {selectedDraft.confidence}% Confidence
                        </Badge>
                        <Badge variant="outline">{selectedDraft.tone}</Badge>
                        <Badge variant="outline">{selectedDraft.responseType}</Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label className="text-sm font-medium text-gray-700">Subject</Label>
                      <div className="mt-1 p-3 bg-gray-50 rounded-md">
                        {selectedDraft.subject}
                      </div>
                    </div>
                    
                    <div>
                      <Label className="text-sm font-medium text-gray-700">Response Content</Label>
                      <div className="mt-1 p-4 bg-gray-50 rounded-md whitespace-pre-wrap">
                        {selectedDraft.content}
                      </div>
                    </div>
                    
                    <div className="flex gap-2 pt-4">
                      <Button 
                        onClick={() => selectedDraft.id && approveDraftMutation.mutate(selectedDraft.id)}
                        disabled={approveDraftMutation.isPending}
                        className="flex-1"
                      >
                        <ThumbsUp className="w-4 h-4 mr-2" />
                        Approve & Send
                      </Button>
                      <Button 
                        variant="outline"
                        onClick={() => copyToClipboard(selectedDraft.content)}
                        className="flex-1"
                      >
                        <Copy className="w-4 h-4 mr-2" />
                        Copy Content
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                {/* Improve Section */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Edit3 className="w-5 h-5" />
                      Improve Draft
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Textarea
                      placeholder="e.g., Make it more formal, add urgency, include specific details..."
                      rows={3}
                      value={improvements}
                      onChange={(e) => setImprovements(e.target.value)}
                    />
                    <Button 
                      onClick={handleImproveDraft}
                      disabled={improveDraftMutation.isPending}
                      variant="outline"
                      className="w-full"
                    >
                      {improveDraftMutation.isPending ? (
                        <>
                          <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                          Improving...
                        </>
                      ) : (
                        <>
                          <Wand2 className="w-4 h-4 mr-2" />
                          Improve Draft
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>
              </div>

              {/* Alternatives & Context */}
              <div className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Alternative Versions</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {selectedDraft.alternatives.length > 0 ? (
                      <div className="space-y-3">
                        {selectedDraft.alternatives.map((alt, index) => (
                          <div key={index} className="p-3 border rounded-lg">
                            <div className="flex items-center justify-between mb-2">
                              <Badge variant="outline">{alt.tone}</Badge>
                              <span className="text-sm text-gray-500">{alt.confidence}%</span>
                            </div>
                            <p className="text-sm text-gray-700 line-clamp-3">{alt.content}</p>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="mt-2 w-full"
                              onClick={() => setSelectedDraft({ ...selectedDraft, content: alt.content, tone: alt.tone })}
                            >
                              Use This Version
                            </Button>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-500 text-sm">No alternatives generated</p>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Context Used</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 text-sm">
                      {selectedDraft.contextUsed.detectedIntent && (
                        <div className="flex justify-between">
                          <span className="text-gray-600">Intent:</span>
                          <span className="font-medium">{selectedDraft.contextUsed.detectedIntent}</span>
                        </div>
                      )}
                      {selectedDraft.contextUsed.urgencyLevel && (
                        <div className="flex justify-between">
                          <span className="text-gray-600">Urgency:</span>
                          <span className="font-medium">{selectedDraft.contextUsed.urgencyLevel}</span>
                        </div>
                      )}
                      <div className="mt-3 pt-2 border-t">
                        <p className="text-xs text-gray-500">{selectedDraft.reasoning}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          ) : (
            <Card>
              <CardContent className="p-12 text-center">
                <Bot className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No Draft Selected</h3>
                <p className="text-gray-500 mb-4">Generate a new response or select an existing draft to review</p>
                <Button onClick={() => setActiveTab("generate")}>
                  <ChevronRight className="w-4 h-4 mr-2" />
                  Generate New Response
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5" />
                Recent Drafts
              </CardTitle>
            </CardHeader>
            <CardContent>
              {draftsLoading ? (
                <div className="space-y-3">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="animate-pulse">
                      <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                      <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                    </div>
                  ))}
                </div>
              ) : drafts && Array.isArray(drafts) && drafts.length > 0 ? (
                <div className="space-y-3">
                  {drafts.slice(0, 10).map((draft: any) => (
                    <div 
                      key={draft.id} 
                      className="p-3 border rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                      onClick={() => {
                        setSelectedDraft(draft);
                        setActiveTab("review");
                      }}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium text-sm truncate">{draft.subject}</span>
                        <div className="flex items-center gap-2">
                          <Badge 
                            className={`text-xs ${getConfidenceColor(draft.confidence || 0)}`}
                          >
                            {draft.confidence}%
                          </Badge>
                          <Badge 
                            variant={draft.status === 'approved' ? 'default' : 'outline'} 
                            className="text-xs"
                          >
                            {draft.status}
                          </Badge>
                        </div>
                      </div>
                      <p className="text-xs text-gray-500 line-clamp-2">{draft.content}</p>
                      <div className="flex items-center justify-between mt-2">
                        <span className="text-xs text-gray-400">{draft.tone} • {draft.responseType}</span>
                        <span className="text-xs text-gray-400">
                          {new Date(draft.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <MessageSquare className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                  <p className="text-gray-500">No drafts created yet</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}