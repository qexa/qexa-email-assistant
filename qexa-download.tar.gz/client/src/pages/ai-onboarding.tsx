import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { 
  User, 
  Mail, 
  Clock, 
  Brain, 
  CheckCircle2, 
  ArrowRight, 
  Lightbulb,
  Target,
  Settings,
  Calendar
} from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import type { UserProfile, OnboardingStep } from '@shared/schema';

interface OnboardingProgress {
  totalSteps: number;
  completedSteps: number;
  currentStep: OnboardingStep | null;
  progress: number;
  nextRecommendations?: any[];
}

const profileSchema = z.object({
  role: z.string().min(1, 'Role is required'),
  emailVolume: z.string(),
  priorities: z.array(z.string()),
  timeZone: z.string(),
  workingHours: z.object({
    start: z.string(),
    end: z.string()
  }),
  preferences: z.object({
    aiAssistanceLevel: z.string(),
    autoResponse: z.boolean(),
    priorityNotifications: z.boolean()
  })
});

type ProfileFormData = z.infer<typeof profileSchema>;

const ROLE_OPTIONS = [
  { value: 'executive', label: 'Executive/C-Level' },
  { value: 'manager', label: 'Manager/Team Lead' },
  { value: 'sales', label: 'Sales Professional' },
  { value: 'support', label: 'Customer Support' },
  { value: 'consultant', label: 'Consultant' },
  { value: 'freelancer', label: 'Freelancer' },
  { value: 'other', label: 'Other' }
];

const EMAIL_VOLUME_OPTIONS = [
  { value: 'light', label: 'Light (0-25 emails/day)' },
  { value: 'moderate', label: 'Moderate (25-100 emails/day)' },
  { value: 'heavy', label: 'Heavy (100-250 emails/day)' },
  { value: 'enterprise', label: 'Enterprise (250+ emails/day)' }
];

const PRIORITY_OPTIONS = [
  'Customer inquiries', 
  'Team communication', 
  'Sales opportunities', 
  'Project updates',
  'Meeting requests',
  'Financial reports',
  'Legal documents',
  'Marketing campaigns'
];

export default function AIOnboarding() {
  const [activeTab, setActiveTab] = useState('profile');
  const [userId, setUserId] = useState<number | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Check existing profile
  const { data: existingProfile } = useQuery({
    queryKey: ['/api/onboarding/profile'],
    enabled: true
  });

  // Get onboarding progress
  const { data: progress } = useQuery<OnboardingProgress>({
    queryKey: ['/api/onboarding/progress', userId],
    enabled: !!userId
  });

  const form = useForm<ProfileFormData>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      role: '',
      emailVolume: 'moderate',
      priorities: [],
      timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      workingHours: {
        start: '09:00',
        end: '17:00'
      },
      preferences: {
        aiAssistanceLevel: 'moderate',
        autoResponse: false,
        priorityNotifications: true
      }
    }
  });

  const createProfileMutation = useMutation({
    mutationFn: async (data: ProfileFormData) => {
      const response = await apiRequest('/api/onboarding/profile', 'POST', data);
      return response;
    },
    onSuccess: (profile: any) => {
      setUserId(profile.id);
      setActiveTab('setup');
      toast({
        title: "Profile Created",
        description: "Your personalized onboarding has begun!"
      });
      queryClient.invalidateQueries({ queryKey: ['/api/onboarding/profile'] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create profile. Please try again.",
        variant: "destructive"
      });
    }
  });

  const completeStepMutation = useMutation({
    mutationFn: ({ stepType, userChoices }: { stepType: string; userChoices: any }) => 
      apiRequest('/api/onboarding/complete-step', 'POST', { userId, stepType, userChoices }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/onboarding/progress', userId] });
      toast({
        title: "Step Completed",
        description: "Moving to the next step!"
      });
    }
  });

  const onSubmitProfile = (data: ProfileFormData) => {
    createProfileMutation.mutate(data);
  };

  const togglePriority = (priority: string) => {
    const current = form.getValues('priorities');
    if (current.includes(priority)) {
      form.setValue('priorities', current.filter(p => p !== priority));
    } else {
      form.setValue('priorities', [...current, priority]);
    }
  };

  React.useEffect(() => {
    if (existingProfile && 'id' in existingProfile && existingProfile.id && !userId) {
      setUserId(existingProfile.id);
    }
  }, [existingProfile, userId]);

  return (
    <div className="container max-w-4xl mx-auto p-4 sm:p-6">
      <div className="mb-6 sm:mb-8">
        <h1 className="text-2xl sm:text-3xl font-bold flex items-center gap-2 sm:gap-3">
          <Brain className="h-6 w-6 sm:h-8 sm:w-8 text-primary flex-shrink-0" />
          <span className="break-words">AI-Powered Onboarding</span>
        </h1>
        <p className="text-muted-foreground mt-2 text-sm sm:text-base">
          Let's personalize your email management experience with intelligent recommendations
        </p>
      </div>

      {progress && (
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold">Your Progress</h3>
              <Badge variant={progress?.progress === 100 ? "default" : "secondary"}>
                {progress?.completedSteps || 0}/{progress?.totalSteps || 0} Complete
              </Badge>
            </div>
            <Progress value={progress?.progress || 0} className="mb-2" />
            <p className="text-sm text-muted-foreground">
              {progress?.progress || 0}% complete
            </p>
          </CardContent>
        </Card>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 h-auto">
          <TabsTrigger value="profile" className="text-xs sm:text-sm px-2 py-2">
            Profile
          </TabsTrigger>
          <TabsTrigger value="setup" disabled={!userId} className="text-xs sm:text-sm px-2 py-2">
            Setup
          </TabsTrigger>
          <TabsTrigger value="recommendations" disabled={!userId} className="text-xs sm:text-sm px-2 py-2">
            <span className="hidden sm:inline">AI Tips</span>
            <span className="sm:hidden">Tips</span>
          </TabsTrigger>
          <TabsTrigger value="complete" disabled={!userId || (progress?.progress || 0) !== 100} className="text-xs sm:text-sm px-2 py-2">
            Done
          </TabsTrigger>
        </TabsList>

        <TabsContent value="profile">
          <Card>
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center gap-2 text-lg sm:text-xl">
                <User className="h-4 w-4 sm:h-5 sm:w-5 flex-shrink-0" />
                Tell Us About Yourself
              </CardTitle>
              <CardDescription className="text-sm">
                Help us understand your role and email habits for personalized recommendations
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 sm:space-y-6">
              <form onSubmit={form.handleSubmit(onSubmitProfile)} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="role">Your Role</Label>
                    <Select 
                      value={form.watch('role')} 
                      onValueChange={(value) => form.setValue('role', value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select your role" />
                      </SelectTrigger>
                      <SelectContent>
                        {ROLE_OPTIONS.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="emailVolume">Email Volume</Label>
                    <Select 
                      value={form.watch('emailVolume')} 
                      onValueChange={(value) => form.setValue('emailVolume', value)}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {EMAIL_VOLUME_OPTIONS.map((option) => (
                          <SelectItem key={option.value} value={option.value}>
                            {option.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-3">
                  <Label className="text-sm font-medium">Email Priorities</Label>
                  <p className="text-xs sm:text-sm text-muted-foreground">
                    Select the types of emails that are most important to you
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
                    {PRIORITY_OPTIONS.map((priority) => (
                      <Button
                        key={priority}
                        type="button"
                        variant={form.watch('priorities').includes(priority) ? "default" : "outline"}
                        size="sm"
                        onClick={() => togglePriority(priority)}
                        className="h-auto py-3 px-3 text-xs sm:text-sm text-left justify-start"
                      >
                        {priority}
                      </Button>
                    ))}
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="timeZone" className="text-sm font-medium">Time Zone</Label>
                    <Input 
                      {...form.register('timeZone')}
                      readOnly
                      className="bg-muted text-sm"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="workingHours.start" className="text-sm font-medium">Work Start</Label>
                      <Input 
                        {...form.register('workingHours.start')}
                        type="time"
                        className="text-sm"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="workingHours.end" className="text-sm font-medium">Work End</Label>
                      <Input 
                        {...form.register('workingHours.end')}
                        type="time"
                        className="text-sm"
                      />
                    </div>
                  </div>
                </div>

                <Separator />

                <div className="space-y-4">
                  <h4 className="font-medium text-sm sm:text-base">AI Preferences</h4>
                  
                  <div className="space-y-2">
                    <Label htmlFor="aiAssistanceLevel" className="text-sm font-medium">AI Assistance Level</Label>
                    <Select 
                      value={form.watch('preferences.aiAssistanceLevel')} 
                      onValueChange={(value) => form.setValue('preferences.aiAssistanceLevel', value)}
                    >
                      <SelectTrigger className="text-sm">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="minimal">Minimal - Just organize emails</SelectItem>
                        <SelectItem value="moderate">Moderate - Suggest actions</SelectItem>
                        <SelectItem value="aggressive">Aggressive - Auto-handle routine emails</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Button 
                  type="submit" 
                  className="w-full h-12 text-sm sm:text-base font-medium" 
                  disabled={createProfileMutation.isPending}
                >
                  {createProfileMutation.isPending ? (
                    "Creating Your Profile..."
                  ) : (
                    <>
                      Start Personalized Setup
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="setup">
          <OnboardingStepsComponent 
            userId={userId} 
            progress={progress}
            onCompleteStep={completeStepMutation.mutate}
          />
        </TabsContent>

        <TabsContent value="recommendations">
          <AIRecommendationsComponent userId={userId} />
        </TabsContent>

        <TabsContent value="complete">
          <Card>
            <CardContent className="p-6 sm:p-8 text-center">
              <CheckCircle2 className="h-12 w-12 sm:h-16 sm:w-16 text-green-500 mx-auto mb-4" />
              <h2 className="text-xl sm:text-2xl font-bold mb-2">Onboarding Complete!</h2>
              <p className="text-muted-foreground mb-6 text-sm sm:text-base">
                Your email assistant is now personalized and ready to help you be more productive.
              </p>
              <Button 
                onClick={() => window.location.href = '/dashboard'}
                className="h-12 px-6 text-sm sm:text-base font-medium"
              >
                Go to Dashboard
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

// Supporting Components
function OnboardingStepsComponent({ 
  userId, 
  progress, 
  onCompleteStep 
}: { 
  userId: number | null;
  progress: any;
  onCompleteStep: (data: any) => void;
}) {
  if (!progress || !progress.currentStep) {
    return (
      <Card>
        <CardContent className="p-6 sm:p-8 text-center">
          <Lightbulb className="h-10 w-10 sm:h-12 sm:w-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-base sm:text-lg font-medium mb-2">Setting up your personalized experience...</h3>
          <p className="text-muted-foreground text-sm">Please wait while we prepare your recommendations.</p>
        </CardContent>
      </Card>
    );
  }

  const { currentStep } = progress;
  const recommendations = currentStep.aiRecommendations || [];

  return (
    <Card>
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-lg sm:text-xl">
          <Settings className="h-4 w-4 sm:h-5 sm:w-5 flex-shrink-0" />
          <span className="break-words">{getStepTitle(currentStep.stepType)}</span>
        </CardTitle>
        <CardDescription className="text-sm">
          {getStepDescription(currentStep.stepType)}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3 sm:space-y-4">
        {recommendations.map((rec: any, index: number) => (
          <div key={index} className="p-3 sm:p-4 bg-muted/50 rounded-lg">
            <div className="flex items-start gap-2 sm:gap-3">
              <Target className="h-4 w-4 sm:h-5 sm:w-5 text-primary mt-0.5 flex-shrink-0" />
              <div className="min-w-0 flex-1">
                <p className="font-medium text-xs sm:text-sm break-words">{rec.text || rec.title}</p>
                {rec.description && (
                  <p className="text-xs text-muted-foreground mt-1 break-words">{rec.description}</p>
                )}
              </div>
            </div>
          </div>
        ))}
        
        <Button 
          onClick={() => onCompleteStep({ 
            stepType: currentStep.stepType, 
            userChoices: { reviewed: true, timestamp: new Date() } 
          })}
          className="w-full mt-4 sm:mt-6 h-12 text-sm sm:text-base font-medium"
        >
          Complete This Step
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </CardContent>
    </Card>
  );
}

function AIRecommendationsComponent({ userId }: { userId: number | null }) {
  const { data: smartRules } = useQuery({
    queryKey: ['/api/onboarding/smart-rules'],
    queryFn: async () => {
      const response = await apiRequest('/api/onboarding/smart-rules', 'POST', { userId });
      return response;
    },
    enabled: !!userId
  });

  const rules = Array.isArray(smartRules) ? smartRules : [];

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-lg sm:text-xl">
            <Brain className="h-4 w-4 sm:h-5 sm:w-5 flex-shrink-0" />
            Smart Rule Suggestions
          </CardTitle>
          <CardDescription className="text-sm">
            AI-generated classification rules based on your profile
          </CardDescription>
        </CardHeader>
        <CardContent>
          {rules.length > 0 ? (
            <div className="space-y-3 sm:space-y-4">
              {rules.map((rule: any, index: number) => (
                <div key={index} className="p-3 sm:p-4 border rounded-lg">
                  <div className="flex items-start justify-between mb-2 gap-2">
                    <h4 className="font-medium text-sm sm:text-base break-words flex-1">{rule.name}</h4>
                    <Badge 
                      variant={rule.priority === 'high' ? 'destructive' : 
                               rule.priority === 'medium' ? 'default' : 'secondary'}
                      className="text-xs flex-shrink-0"
                    >
                      {rule.priority}
                    </Badge>
                  </div>
                  <p className="text-xs sm:text-sm text-muted-foreground mb-3 break-words">{rule.explanation}</p>
                  <div className="flex flex-wrap gap-1 sm:gap-2">
                    {rule.keywords?.map((keyword: string) => (
                      <Badge key={keyword} variant="outline" className="text-xs">
                        {keyword}
                      </Badge>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-6 sm:py-8 text-muted-foreground">
              <Brain className="h-10 w-10 sm:h-12 sm:w-12 mx-auto mb-4 opacity-50" />
              <p className="text-sm">Analyzing your profile to generate smart recommendations...</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function getStepTitle(stepType: string): string {
  const titles: Record<string, string> = {
    'email_accounts': 'Email Account Setup',
    'classification_rules': 'Smart Classification Rules',
    'ai_setup': 'AI Assistant Configuration', 
    'preferences': 'Personal Preferences'
  };
  return titles[stepType] || 'Setup Step';
}

function getStepDescription(stepType: string): string {
  const descriptions: Record<string, string> = {
    'email_accounts': 'Connect and configure your email accounts for optimal performance',
    'classification_rules': 'Set up intelligent rules to automatically categorize your emails',
    'ai_setup': 'Configure your AI assistant preferences and response settings',
    'preferences': 'Fine-tune notifications, automation, and personal settings'
  };
  return descriptions[stepType] || 'Configure this step based on AI recommendations';
}