import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Mail, 
  Wand2, 
  Clock, 
  Send, 
  Save, 
  Lightbulb, 
  Gauge,
  Calendar,
  Sparkles,
  RefreshCw,
  CheckCircle
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

export default function EmailComposer() {
  const [emailData, setEmailData] = useState({
    to: "",
    cc: "",
    bcc: "",
    subject: "",
    body: ""
  });
  const [aiPrompt, setAiPrompt] = useState("");
  const [tone, setTone] = useState("professional");
  const [length, setLength] = useState("medium");
  const [isGenerating, setIsGenerating] = useState(false);
  const [suggestions, setSuggestions] = useState<any[]>([]);
  const [scheduleDate, setScheduleDate] = useState("");
  const [scheduleTime, setScheduleTime] = useState("");

  const generateEmail = async () => {
    if (!aiPrompt.trim()) return;
    
    setIsGenerating(true);
    try {
      const result = await apiRequest("POST", "/api/emails/generate", {
        prompt: aiPrompt,
        tone,
        length,
        context: emailData.to ? `Recipient: ${emailData.to}` : ""
      });
      
      setEmailData(prev => ({
        ...prev,
        subject: result.subject || prev.subject,
        body: result.body || prev.body
      }));
    } catch (error) {
      console.error("Generation failed:", error);
    } finally {
      setIsGenerating(false);
    }
  };

  const analyzeTone = async () => {
    if (!emailData.body.trim()) return;
    
    try {
      const result = await apiRequest("POST", "/api/emails/analyze-tone", {
        content: emailData.body
      });
      
      setSuggestions(result.suggestions || []);
    } catch (error) {
      console.error("Analysis failed:", error);
    }
  };

  const sendEmail = async (scheduled = false) => {
    try {
      const payload = {
        ...emailData,
        scheduled,
        scheduleFor: scheduled ? `${scheduleDate}T${scheduleTime}` : null
      };
      
      await apiRequest("POST", "/api/emails/send", payload);
      
      // Reset form
      setEmailData({ to: "", cc: "", bcc: "", subject: "", body: "" });
      setAiPrompt("");
      setSuggestions([]);
    } catch (error) {
      console.error("Send failed:", error);
    }
  };

  const templates = [
    {
      name: "Follow-up Meeting",
      prompt: "Write a professional follow-up email asking about the status of our meeting discussion"
    },
    {
      name: "Project Update", 
      prompt: "Compose an email updating the team on project progress with key milestones"
    },
    {
      name: "Thank You Note",
      prompt: "Draft a gracious thank you email for someone's help or collaboration"
    },
    {
      name: "Introduction Email",
      prompt: "Write an introduction email connecting two people who should meet"
    }
  ];

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <header className="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-gray-800">AI Email Composer</h1>
            <p className="text-sm text-gray-600">Compose emails with AI assistance and smart features</p>
          </div>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto bg-gray-50 p-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-3 gap-6">
            
            {/* AI Generation Panel */}
            <div className="lg:col-span-1 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Wand2 className="w-5 h-5 text-purple-600" />
                    AI Assistant
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-2 block">
                      What do you want to write?
                    </label>
                    <Textarea
                      placeholder="Describe the email you want to create..."
                      value={aiPrompt}
                      onChange={(e) => setAiPrompt(e.target.value)}
                      rows={3}
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-sm font-medium text-gray-700 mb-1 block">Tone</label>
                      <Select value={tone} onValueChange={setTone}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="professional">Professional</SelectItem>
                          <SelectItem value="friendly">Friendly</SelectItem>
                          <SelectItem value="formal">Formal</SelectItem>
                          <SelectItem value="casual">Casual</SelectItem>
                          <SelectItem value="persuasive">Persuasive</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium text-gray-700 mb-1 block">Length</label>
                      <Select value={length} onValueChange={setLength}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="short">Short</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="long">Long</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <Button 
                    onClick={generateEmail} 
                    disabled={isGenerating || !aiPrompt.trim()}
                    className="w-full"
                  >
                    <Sparkles className="w-4 h-4 mr-2" />
                    {isGenerating ? "Generating..." : "Generate Email"}
                  </Button>
                </CardContent>
              </Card>

              {/* Templates */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Lightbulb className="w-5 h-5 text-yellow-600" />
                    Quick Templates
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {templates.map((template, index) => (
                      <Button
                        key={index}
                        variant="outline"
                        size="sm"
                        className="w-full justify-start h-auto py-2"
                        onClick={() => setAiPrompt(template.prompt)}
                      >
                        <span className="text-left text-xs">{template.name}</span>
                      </Button>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Tone Analysis */}
              {suggestions.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Gauge className="w-5 h-5 text-blue-600" />
                      Tone Analysis
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {suggestions.map((suggestion, index) => (
                        <div key={index} className="p-2 bg-blue-50 rounded text-sm">
                          <div className="font-medium text-blue-900">{suggestion.type}</div>
                          <div className="text-blue-700">{suggestion.message}</div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Email Composer */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Mail className="w-5 h-5 text-blue-600" />
                    Compose Email
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-4">
                    <div>
                      <label className="text-sm font-medium text-gray-700 mb-1 block">To</label>
                      <Input
                        placeholder="recipient@example.com"
                        value={emailData.to}
                        onChange={(e) => setEmailData(prev => ({ ...prev, to: e.target.value }))}
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium text-gray-700 mb-1 block">CC</label>
                        <Input
                          placeholder="Optional"
                          value={emailData.cc}
                          onChange={(e) => setEmailData(prev => ({ ...prev, cc: e.target.value }))}
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium text-gray-700 mb-1 block">BCC</label>
                        <Input
                          placeholder="Optional"
                          value={emailData.bcc}
                          onChange={(e) => setEmailData(prev => ({ ...prev, bcc: e.target.value }))}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium text-gray-700 mb-1 block">Subject</label>
                      <Input
                        placeholder="Email subject"
                        value={emailData.subject}
                        onChange={(e) => setEmailData(prev => ({ ...prev, subject: e.target.value }))}
                      />
                    </div>
                    
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-sm font-medium text-gray-700">Message</label>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={analyzeTone}
                          disabled={!emailData.body.trim()}
                        >
                          <Gauge className="w-4 h-4 mr-1" />
                          Analyze Tone
                        </Button>
                      </div>
                      <Textarea
                        placeholder="Compose your email..."
                        value={emailData.body}
                        onChange={(e) => setEmailData(prev => ({ ...prev, body: e.target.value }))}
                        rows={12}
                      />
                    </div>
                  </div>

                  {/* Email Scheduling */}
                  <Tabs defaultValue="send-now" className="w-full">
                    <TabsList className="grid w-full grid-cols-2">
                      <TabsTrigger value="send-now">Send Now</TabsTrigger>
                      <TabsTrigger value="schedule">Schedule</TabsTrigger>
                    </TabsList>
                    
                    <TabsContent value="send-now" className="space-y-4">
                      <div className="flex gap-3">
                        <Button onClick={() => sendEmail(false)} className="flex-1">
                          <Send className="w-4 h-4 mr-2" />
                          Send Email
                        </Button>
                        <Button variant="outline">
                          <Save className="w-4 h-4 mr-2" />
                          Save Draft
                        </Button>
                      </div>
                    </TabsContent>
                    
                    <TabsContent value="schedule" className="space-y-4">
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="text-sm font-medium text-gray-700 mb-1 block">Date</label>
                          <Input
                            type="date"
                            value={scheduleDate}
                            onChange={(e) => setScheduleDate(e.target.value)}
                          />
                        </div>
                        <div>
                          <label className="text-sm font-medium text-gray-700 mb-1 block">Time</label>
                          <Input
                            type="time"
                            value={scheduleTime}
                            onChange={(e) => setScheduleTime(e.target.value)}
                          />
                        </div>
                      </div>
                      <Button 
                        onClick={() => sendEmail(true)} 
                        className="w-full"
                        disabled={!scheduleDate || !scheduleTime}
                      >
                        <Calendar className="w-4 h-4 mr-2" />
                        Schedule Email
                      </Button>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}