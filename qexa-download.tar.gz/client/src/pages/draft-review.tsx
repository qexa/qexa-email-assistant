import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Check, X, Edit, Eye, Bot, Filter, Search } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function DraftReview() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedDraft, setSelectedDraft] = useState<any>(null);
  const [editingDraft, setEditingDraft] = useState<any>(null);
  const [editContent, setEditContent] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: drafts, isLoading } = useQuery({
    queryKey: ["/api/drafts"],
  });

  const updateDraftMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: any }) => {
      return apiRequest("PUT", `/api/drafts/${id}`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/drafts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/drafts/pending"] });
      toast({ title: "Draft updated successfully" });
      setEditingDraft(null);
    },
    onError: () => {
      toast({ title: "Failed to update draft", variant: "destructive" });
    },
  });

  const deleteDraftMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/drafts/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/drafts"] });
      toast({ title: "Draft deleted successfully" });
    },
    onError: () => {
      toast({ title: "Failed to delete draft", variant: "destructive" });
    },
  });

  const handleDraftAction = (id: number, action: string) => {
    updateDraftMutation.mutate({
      id,
      updates: { status: action },
    });
  };

  const handleEditDraft = (draft: any) => {
    setEditingDraft(draft);
    setEditContent(draft.content);
  };

  const handleSaveEdit = () => {
    if (editingDraft) {
      updateDraftMutation.mutate({
        id: editingDraft.id,
        updates: { 
          content: editContent,
          status: 'edited' 
        },
      });
    }
  };

  const filteredDrafts = drafts?.filter((draft: any) => {
    const matchesSearch = draft.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         draft.content.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || draft.status === statusFilter;
    return matchesSearch && matchesStatus;
  }) || [];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'approved':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      case 'edited':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getProviderBadge = (provider: string) => {
    switch (provider) {
      case 'openai':
        return 'bg-green-100 text-green-800';
      case 'claude':
        return 'bg-purple-100 text-purple-800';
      case 'gemini':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 80) return 'text-green-600';
    if (confidence >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <header className="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-gray-800">Draft Review</h1>
            <p className="text-sm text-gray-600">Review and manage AI-generated email drafts</p>
          </div>
          <div className="flex items-center space-x-2 text-sm text-gray-500">
            <span>Total drafts: {drafts?.length || 0}</span>
            <span>•</span>
            <span>Pending: {drafts?.filter((d: any) => d.status === 'pending').length || 0}</span>
          </div>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto bg-gray-50 p-6">
        <div className="max-w-6xl mx-auto">
          {/* Search and Filters */}
          <div className="mb-6 flex items-center space-x-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search drafts..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Filter className="w-4 h-4 text-gray-500" />
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="approved">Approved</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                  <SelectItem value="edited">Edited</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {isLoading ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <Card key={i}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <Skeleton className="w-6 h-6" />
                        <Skeleton className="h-5 w-48" />
                        <Skeleton className="w-16 h-6 rounded-full" />
                      </div>
                      <Skeleton className="w-20 h-6 rounded-full" />
                    </div>
                    <Skeleton className="h-16 w-full mb-4" />
                    <div className="flex space-x-2">
                      <Skeleton className="h-8 w-20" />
                      <Skeleton className="h-8 w-16" />
                      <Skeleton className="h-8 w-20" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : !filteredDrafts.length ? (
            <Card>
              <CardContent className="p-12 text-center">
                <Bot className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  {searchTerm || statusFilter !== "all" ? 'No drafts found' : 'No drafts available'}
                </h3>
                <p className="text-gray-500">
                  {searchTerm || statusFilter !== "all" 
                    ? 'Try adjusting your search terms or filters.'
                    : 'AI-generated drafts will appear here when emails are processed.'
                  }
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {filteredDrafts.map((draft: any) => (
                <Card key={draft.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center space-x-3 flex-1">
                        <Bot className="w-5 h-5 text-blue-500 flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center space-x-2 mb-1">
                            <h3 className="font-medium text-gray-900 truncate">{draft.subject}</h3>
                            <Badge className={getProviderBadge(draft.aiProvider)}>
                              {draft.aiProvider}
                            </Badge>
                          </div>
                          <div className="flex items-center space-x-4 text-sm text-gray-500">
                            <span>
                              Created {formatDistanceToNow(new Date(draft.createdAt), { addSuffix: true })}
                            </span>
                            {draft.confidence && (
                              <span className={`font-medium ${getConfidenceColor(draft.confidence)}`}>
                                {draft.confidence}% confidence
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                      <Badge className={getStatusBadge(draft.status)}>
                        {draft.status}
                      </Badge>
                    </div>

                    <div className="mb-4">
                      <p className="text-sm text-gray-600 line-clamp-3">
                        {draft.content}
                      </p>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => setSelectedDraft(draft)}
                            >
                              <Eye className="w-4 h-4 mr-2" />
                              View
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="max-w-2xl">
                            <DialogHeader>
                              <DialogTitle>Draft Preview</DialogTitle>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div>
                                <Label>Subject</Label>
                                <p className="text-sm text-gray-900 mt-1">{draft.subject}</p>
                              </div>
                              <div>
                                <Label>Content</Label>
                                <div className="mt-2 p-4 bg-gray-50 rounded-lg">
                                  <p className="text-sm text-gray-900 whitespace-pre-wrap">{draft.content}</p>
                                </div>
                              </div>
                              <div className="flex items-center space-x-4 text-sm text-gray-500">
                                <span>AI Provider: {draft.aiProvider}</span>
                                <span>Confidence: {draft.confidence}%</span>
                                <span>Status: {draft.status}</span>
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>

                        {draft.status === 'pending' && (
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleEditDraft(draft)}
                              >
                                <Edit className="w-4 h-4 mr-2" />
                                Edit
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="max-w-2xl">
                              <DialogHeader>
                                <DialogTitle>Edit Draft</DialogTitle>
                              </DialogHeader>
                              <div className="space-y-4">
                                <div>
                                  <Label>Subject</Label>
                                  <Input value={draft.subject} readOnly className="mt-1" />
                                </div>
                                <div>
                                  <Label>Content</Label>
                                  <Textarea
                                    value={editContent}
                                    onChange={(e) => setEditContent(e.target.value)}
                                    rows={10}
                                    className="mt-1"
                                  />
                                </div>
                                <div className="flex justify-end space-x-2">
                                  <Button variant="outline" onClick={() => setEditingDraft(null)}>
                                    Cancel
                                  </Button>
                                  <Button
                                    onClick={handleSaveEdit}
                                    disabled={updateDraftMutation.isPending}
                                  >
                                    Save Changes
                                  </Button>
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>
                        )}
                      </div>

                      {draft.status === 'pending' && (
                        <div className="flex items-center space-x-2">
                          <Button
                            size="sm"
                            onClick={() => handleDraftAction(draft.id, 'approved')}
                            disabled={updateDraftMutation.isPending}
                            className="bg-green-600 hover:bg-green-700"
                          >
                            <Check className="w-4 h-4 mr-1" />
                            Approve
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleDraftAction(draft.id, 'rejected')}
                            disabled={updateDraftMutation.isPending}
                            className="text-red-600 hover:text-red-700"
                          >
                            <X className="w-4 h-4 mr-1" />
                            Reject
                          </Button>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
