import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Settings as SettingsIcon, 
  Key, 
  Bell, 
  Shield, 
  Database, 
  Mail,
  Save,
  Eye,
  EyeOff
} from "lucide-react";
import QuickStartGuide from "@/components/quick-start-guide";

export default function Settings() {
  const [showApiKeys, setShowApiKeys] = useState<{ [key: string]: boolean }>({});
  const [apiKeyValues, setApiKeyValues] = useState<{ [key: string]: string }>({});
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: providers, isLoading: providersLoading } = useQuery({
    queryKey: ["/api/ai-providers"],
  });

  const { data: settings, isLoading: settingsLoading } = useQuery({
    queryKey: ["/api/settings"],
  });

  const { data: calendarSettings, isLoading: calendarLoading } = useQuery({
    queryKey: ["/api/calendar/settings"],
  });

  const updateProviderMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: any }) => {
      return apiRequest("PUT", `/api/ai-providers/${id}`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/ai-providers"] });
      toast({ title: "Provider updated successfully" });
    },
    onError: () => {
      toast({ title: "Failed to update provider", variant: "destructive" });
    },
  });

  const updateSettingMutation = useMutation({
    mutationFn: async ({ key, value }: { key: string; value: string }) => {
      return apiRequest("PUT", `/api/settings/${key}`, { value });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({ title: "Setting updated successfully" });
    },
    onError: () => {
      toast({ title: "Failed to update setting", variant: "destructive" });
    },
  });

  const updateCalendarSettingMutation = useMutation({
    mutationFn: async (settings: any) => {
      return apiRequest("PUT", "/api/calendar/settings", settings);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/calendar/settings"] });
      toast({ title: "Calendar settings updated successfully" });
    },
    onError: () => {
      toast({ title: "Failed to update calendar settings", variant: "destructive" });
    },
  });

  const handleProviderUpdate = (id: number, updates: any) => {
    updateProviderMutation.mutate({ id, updates });
  };

  const handleApiKeyUpdate = (id: number, apiKey: string) => {
    handleProviderUpdate(id, { apiKey });
    setApiKeyValues(prev => ({ ...prev, [id]: '' }));
  };

  const toggleApiKeyVisibility = (id: number) => {
    setShowApiKeys(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const handleSettingUpdate = (key: string, value: string) => {
    updateSettingMutation.mutate({ key, value });
  };

  const handleCalendarSettingUpdate = (setting: any) => {
    updateCalendarSettingMutation.mutate(setting);
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <header className="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-gray-800">Settings</h1>
            <p className="text-sm text-gray-600">Configure system preferences and integrations</p>
          </div>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto bg-gray-50 p-6">
        <div className="max-w-4xl mx-auto">
          {/* Quick Start Guide */}
          <QuickStartGuide />
          
          <Tabs defaultValue="providers" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="providers">AI Providers</TabsTrigger>
              <TabsTrigger value="email">Email</TabsTrigger>
              <TabsTrigger value="calendar">Calendar</TabsTrigger>
              <TabsTrigger value="system">System</TabsTrigger>
            </TabsList>

            {/* AI Providers Tab */}
            <TabsContent value="providers" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Key className="w-5 h-5 mr-2" />
                    AI Provider Configuration
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {providersLoading ? (
                    <div className="space-y-6">
                      {[...Array(3)].map((_, i) => (
                        <div key={i} className="border rounded-lg p-4">
                          <div className="flex items-center justify-between mb-4">
                            <Skeleton className="h-6 w-24" />
                            <Skeleton className="h-6 w-16" />
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <Skeleton className="h-10 w-full" />
                            <Skeleton className="h-10 w-full" />
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="space-y-6">
                      {providers?.map((provider: any) => (
                        <div key={provider.id} className="border rounded-lg p-4">
                          <div className="flex items-center justify-between mb-4">
                            <div className="flex items-center space-x-3">
                              <h3 className="font-medium text-gray-900 capitalize">{provider.name}</h3>
                              <Badge variant={provider.isActive ? "default" : "secondary"}>
                                {provider.isActive ? "Active" : "Inactive"}
                              </Badge>
                            </div>
                            <Switch
                              checked={provider.isActive}
                              onCheckedChange={(checked) => handleProviderUpdate(provider.id, { isActive: checked })}
                            />
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                              <Label htmlFor={`apikey-${provider.id}`}>API Key</Label>
                              <div className="flex mt-1">
                                <Input
                                  id={`apikey-${provider.id}`}
                                  type={showApiKeys[provider.id] ? "text" : "password"}
                                  placeholder="Enter API key"
                                  value={apiKeyValues[provider.id] || ''}
                                  onChange={(e) => setApiKeyValues(prev => ({ ...prev, [provider.id]: e.target.value }))}
                                  className="flex-1"
                                />
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="sm"
                                  className="ml-2"
                                  onClick={() => toggleApiKeyVisibility(provider.id)}
                                >
                                  {showApiKeys[provider.id] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                                </Button>
                              </div>
                            </div>

                            <div>
                              <Label htmlFor={`priority-${provider.id}`}>Priority</Label>
                              <Select
                                value={provider.priority?.toString() || "1"}
                                onValueChange={(value) => handleProviderUpdate(provider.id, { priority: parseInt(value) })}
                              >
                                <SelectTrigger className="mt-1">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="1">1 (Highest)</SelectItem>
                                  <SelectItem value="2">2</SelectItem>
                                  <SelectItem value="3">3</SelectItem>
                                  <SelectItem value="4">4</SelectItem>
                                  <SelectItem value="5">5 (Lowest)</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </div>

                          <div className="mt-4 flex justify-between items-center">
                            <div className="text-sm text-gray-500">
                              <span>Usage today: {provider.usageToday || 0}</span>
                              <span className="ml-4">Success rate: {provider.successRate || 0}%</span>
                            </div>
                            <Button
                              size="sm"
                              onClick={() => handleApiKeyUpdate(provider.id, apiKeyValues[provider.id] || '')}
                              disabled={!apiKeyValues[provider.id]}
                            >
                              <Save className="w-4 h-4 mr-2" />
                              Update
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Email Tab */}
            <TabsContent value="email" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Mail className="w-5 h-5 mr-2" />
                    Email Processing Settings
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="processingInterval">Processing Interval (minutes)</Label>
                        <Select defaultValue="5">
                          <SelectTrigger className="mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="1">1 minute</SelectItem>
                            <SelectItem value="5">5 minutes</SelectItem>
                            <SelectItem value="10">10 minutes</SelectItem>
                            <SelectItem value="15">15 minutes</SelectItem>
                            <SelectItem value="30">30 minutes</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label htmlFor="maxEmailsPerBatch">Max Emails per Batch</Label>
                        <Select defaultValue="50">
                          <SelectTrigger className="mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="10">10</SelectItem>
                            <SelectItem value="25">25</SelectItem>
                            <SelectItem value="50">50</SelectItem>
                            <SelectItem value="100">100</SelectItem>
                            <SelectItem value="200">200</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label>Auto-classify emails</Label>
                          <p className="text-sm text-gray-500">Automatically classify incoming emails</p>
                        </div>
                        <Switch defaultChecked />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label>Create draft responses</Label>
                          <p className="text-sm text-gray-500">Generate AI draft responses for classified emails</p>
                        </div>
                        <Switch defaultChecked />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label>Archive processed emails</Label>
                          <p className="text-sm text-gray-500">Move processed emails to archive folder</p>
                        </div>
                        <Switch />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Calendar Tab */}
            <TabsContent value="calendar" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <SettingsIcon className="w-5 h-5 mr-2" />
                    Calendar Integration Settings
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {calendarLoading ? (
                    <div className="space-y-4">
                      {[...Array(4)].map((_, i) => (
                        <div key={i} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                          <div className="space-y-1">
                            <Skeleton className="h-4 w-48" />
                            <Skeleton className="h-3 w-32" />
                          </div>
                          <Skeleton className="w-12 h-6" />
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div>
                          <Label>Auto-create calendar events</Label>
                          <p className="text-sm text-gray-500">Automatically create events from meeting requests</p>
                        </div>
                        <Switch
                          checked={calendarSettings?.autoCreateEvents || false}
                          onCheckedChange={(checked) => handleCalendarSettingUpdate({ autoCreateEvents: checked })}
                        />
                      </div>

                      <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div>
                          <Label>Default event duration</Label>
                          <p className="text-sm text-gray-500">Default duration when not specified</p>
                        </div>
                        <Select
                          value={calendarSettings?.defaultDuration?.toString() || "60"}
                          onValueChange={(value) => handleCalendarSettingUpdate({ defaultDuration: parseInt(value) })}
                        >
                          <SelectTrigger className="w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="30">30 minutes</SelectItem>
                            <SelectItem value="60">1 hour</SelectItem>
                            <SelectItem value="90">1.5 hours</SelectItem>
                            <SelectItem value="120">2 hours</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div>
                          <Label>Target calendar</Label>
                          <p className="text-sm text-gray-500">Which calendar to create events in</p>
                        </div>
                        <Select
                          value={calendarSettings?.targetCalendar || "primary"}
                          onValueChange={(value) => handleCalendarSettingUpdate({ targetCalendar: value })}
                        >
                          <SelectTrigger className="w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="primary">Primary</SelectItem>
                            <SelectItem value="work">Work</SelectItem>
                            <SelectItem value="meetings">Meetings</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* System Tab */}
            <TabsContent value="system" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Database className="w-5 h-5 mr-2" />
                    System Configuration
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="logLevel">Log Level</Label>
                        <Select defaultValue="info">
                          <SelectTrigger className="mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="debug">Debug</SelectItem>
                            <SelectItem value="info">Info</SelectItem>
                            <SelectItem value="warn">Warning</SelectItem>
                            <SelectItem value="error">Error</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div>
                        <Label htmlFor="dataRetention">Data Retention (days)</Label>
                        <Select defaultValue="90">
                          <SelectTrigger className="mt-1">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="30">30 days</SelectItem>
                            <SelectItem value="90">90 days</SelectItem>
                            <SelectItem value="180">180 days</SelectItem>
                            <SelectItem value="365">1 year</SelectItem>
                            <SelectItem value="0">Never delete</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label>Enable debug logging</Label>
                          <p className="text-sm text-gray-500">Log detailed debug information</p>
                        </div>
                        <Switch />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label>Auto-backup database</Label>
                          <p className="text-sm text-gray-500">Automatically backup system data</p>
                        </div>
                        <Switch defaultChecked />
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <Label>Performance monitoring</Label>
                          <p className="text-sm text-gray-500">Track system performance metrics</p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Bell className="w-5 h-5 mr-2" />
                    Notifications
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Email notifications</Label>
                        <p className="text-sm text-gray-500">Send email alerts for system events</p>
                      </div>
                      <Switch defaultChecked />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Error notifications</Label>
                        <p className="text-sm text-gray-500">Alert on system errors</p>
                      </div>
                      <Switch defaultChecked />
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Daily reports</Label>
                        <p className="text-sm text-gray-500">Send daily processing reports</p>
                      </div>
                      <Switch />
                    </div>

                    <div className="mt-4">
                      <Label htmlFor="notificationEmail">Notification Email</Label>
                      <Input
                        id="notificationEmail"
                        type="email"
                        placeholder="admin@example.com"
                        className="mt-1"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
}
