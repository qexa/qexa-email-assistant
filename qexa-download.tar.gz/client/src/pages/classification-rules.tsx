import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import ClassificationRuleEditor from "@/components/classification-rule-editor";
import { Plus, Edit, Trash2, Search, Settings } from "lucide-react";

export default function ClassificationRules() {
  const [searchTerm, setSearchTerm] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: rules, isLoading } = useQuery({
    queryKey: ["/api/classification-rules"],
  });

  const deleteRuleMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/classification-rules/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/classification-rules"] });
      toast({ title: "Rule deleted successfully" });
    },
    onError: () => {
      toast({ title: "Failed to delete rule", variant: "destructive" });
    },
  });

  const toggleRuleMutation = useMutation({
    mutationFn: async ({ id, isActive }: { id: number; isActive: boolean }) => {
      return apiRequest("PUT", `/api/classification-rules/${id}`, { isActive });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/classification-rules"] });
      toast({ title: "Rule status updated" });
    },
    onError: () => {
      toast({ title: "Failed to update rule", variant: "destructive" });
    },
  });

  const filteredRules = rules?.filter((rule: any) =>
    rule.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    rule.keywords?.some((keyword: string) => 
      keyword.toLowerCase().includes(searchTerm.toLowerCase())
    )
  ) || [];

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-red-500';
      case 'medium':
        return 'bg-yellow-500';
      case 'low':
        return 'bg-green-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-red-100 text-red-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'low':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <header className="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-gray-800">Classification Rules</h1>
            <p className="text-sm text-gray-600">Configure automated email classification and actions</p>
          </div>
          <ClassificationRuleEditor />
        </div>
      </header>

      <main className="flex-1 overflow-y-auto bg-gray-50 p-6">
        <div className="max-w-6xl mx-auto">
          {/* Search and Filters */}
          <div className="mb-6 flex items-center space-x-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search rules..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex items-center space-x-2 text-sm text-gray-500">
              <span>Total rules: {rules?.length || 0}</span>
              <span>•</span>
              <span>Active: {rules?.filter((r: any) => r.isActive).length || 0}</span>
            </div>
          </div>

          {isLoading ? (
            <div className="space-y-4">
              {[...Array(3)].map((_, i) => (
                <Card key={i}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <Skeleton className="w-4 h-4 rounded-full" />
                        <Skeleton className="h-5 w-48" />
                      </div>
                      <Skeleton className="w-16 h-6 rounded-full" />
                    </div>
                    <div className="space-y-2">
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-3/4" />
                      <Skeleton className="h-4 w-1/2" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : !filteredRules.length ? (
            <Card>
              <CardContent className="p-12 text-center">
                <Settings className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  {searchTerm ? 'No rules found' : 'No classification rules'}
                </h3>
                <p className="text-gray-500 mb-6">
                  {searchTerm 
                    ? 'Try adjusting your search terms or create a new rule.'
                    : 'Create your first classification rule to start automating email processing.'
                  }
                </p>
                <ClassificationRuleEditor />
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {filteredRules.map((rule: any) => (
                <Card key={rule.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <div className={`w-4 h-4 rounded-full ${getPriorityColor(rule.priority)}`} />
                        <h3 className="font-medium text-gray-900">{rule.name}</h3>
                        <Badge className={getPriorityBadge(rule.priority)}>
                          {rule.priority} priority
                        </Badge>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Switch
                          checked={rule.isActive}
                          onCheckedChange={(checked) => 
                            toggleRuleMutation.mutate({ id: rule.id, isActive: checked })
                          }
                          disabled={toggleRuleMutation.isPending}
                        />
                        <div className="flex items-center space-x-2">
                          <ClassificationRuleEditor rule={rule} />
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteRuleMutation.mutate(rule.id)}
                            disabled={deleteRuleMutation.isPending}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                      <div>
                        <p className="font-medium text-gray-700 mb-1">Keywords</p>
                        <p className="text-gray-600">
                          {rule.keywords?.length > 0 
                            ? rule.keywords.join(", ") 
                            : "No keywords"
                          }
                        </p>
                      </div>
                      <div>
                        <p className="font-medium text-gray-700 mb-1">Sender Patterns</p>
                        <p className="text-gray-600">
                          {rule.senderPatterns?.length > 0 
                            ? rule.senderPatterns.join(", ") 
                            : "No sender patterns"
                          }
                        </p>
                      </div>
                      <div>
                        <p className="font-medium text-gray-700 mb-1">Actions</p>
                        <div className="flex flex-wrap gap-1">
                          {rule.actions?.flag && (
                            <Badge variant="outline" className="text-xs">Flag</Badge>
                          )}
                          {rule.actions?.createDraft && (
                            <Badge variant="outline" className="text-xs">Create Draft</Badge>
                          )}
                          {rule.actions?.createCalendar && (
                            <Badge variant="outline" className="text-xs">Create Calendar</Badge>
                          )}
                          {rule.actions?.moveFolder && (
                            <Badge variant="outline" className="text-xs">Move to Folder</Badge>
                          )}
                          {!Object.values(rule.actions || {}).some(Boolean) && (
                            <span className="text-gray-500 text-xs">No actions</span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 pt-4 border-t border-gray-200 flex items-center justify-between text-xs text-gray-500">
                      <span>
                        Created: {new Date(rule.createdAt).toLocaleDateString()}
                      </span>
                      <span className={`flex items-center space-x-2 ${
                        rule.isActive ? 'text-green-600' : 'text-gray-400'
                      }`}>
                        <div className={`w-2 h-2 rounded-full ${
                          rule.isActive ? 'bg-green-500' : 'bg-gray-400'
                        }`} />
                        <span>{rule.isActive ? 'Active' : 'Inactive'}</span>
                      </span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
