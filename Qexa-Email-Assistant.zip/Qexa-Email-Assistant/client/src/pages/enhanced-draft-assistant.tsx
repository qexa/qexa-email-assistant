import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { AlertCircle, Brain, Lightbulb, MessageSquare, Sparkles, Target, TrendingUp, Users, CheckCircle2, Clock } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

type ToneAnalysis = {
  tone: string;
  confidence: number;
  sentiment: 'positive' | 'neutral' | 'negative';
  formality: 'formal' | 'semi-formal' | 'casual';
  suggestions: string[];
};

type DraftSuggestion = {
  type: 'improvement' | 'tone' | 'clarity' | 'brevity';
  priority: 'high' | 'medium' | 'low';
  suggestion: string;
  example?: string;
};

type RelationshipContext = {
  sender: string;
  totalEmails: number;
  lastInteraction: string;
  relationship: string;
  responsePattern: string;
  commonTopics: string[];
  preferredTone: string;
};

type EnhancedDraft = {
  content: string;
  tone: string;
  confidence: number;
  wordCount: number;
  estimatedReadTime: string;
  suggestions: DraftSuggestion[];
};

export default function EnhancedDraftAssistant() {
  const [draftContent, setDraftContent] = useState("");
  const [selectedTone, setSelectedTone] = useState("professional");
  const [selectedPriority, setSelectedPriority] = useState("medium");
  const [selectedEmailId, setSelectedEmailId] = useState("");
  const [selectedSender, setSelectedSender] = useState("");
  const [toneAnalysis, setToneAnalysis] = useState<ToneAnalysis | null>(null);
  const [enhancedDraft, setEnhancedDraft] = useState<EnhancedDraft | null>(null);
  const [suggestions, setSuggestions] = useState<DraftSuggestion[]>([]);

  // Fetch relationship context
  const { data: relationshipContext, isLoading: contextLoading } = useQuery<RelationshipContext>({
    queryKey: ["/api/drafts/relationship-context", selectedSender],
    enabled: !!selectedSender,
  });

  // Generate enhanced draft mutation
  const generateDraftMutation = useMutation({
    mutationFn: async ({ emailId, tone, priority }: { emailId: string; tone: string; priority: string }) => {
      const response = await apiRequest("/api/drafts/generate-enhanced", {
        method: "POST",
        body: JSON.stringify({ emailId, tone, priority }),
      });
      return response as EnhancedDraft;
    },
    onSuccess: (result: EnhancedDraft) => {
      setEnhancedDraft(result);
      setDraftContent(result.content);
    },
  });

  // Analyze tone mutation
  const analyzeToneMutation = useMutation({
    mutationFn: async (content: string) => {
      const response = await apiRequest("/api/drafts/analyze-tone", {
        method: "POST",
        body: JSON.stringify({ content }),
      });
      return response as ToneAnalysis;
    },
    onSuccess: (result: ToneAnalysis) => {
      setToneAnalysis(result);
    },
  });

  // Suggest improvements mutation
  const suggestImprovementsMutation = useMutation({
    mutationFn: async ({ draftContent, originalEmailId }: { draftContent: string; originalEmailId: string }) => {
      const response = await apiRequest("/api/drafts/suggest-improvements", {
        method: "POST",
        body: JSON.stringify({ draftContent, originalEmailId }),
      });
      return response as DraftSuggestion[];
    },
    onSuccess: (result: DraftSuggestion[]) => {
      setSuggestions(result);
    },
  });

  const generateEnhancedDraft = () => {
    if (!selectedEmailId) return;
    generateDraftMutation.mutate({
      emailId: selectedEmailId,
      tone: selectedTone,
      priority: selectedPriority,
    });
  };

  const analyzeTone = () => {
    if (!draftContent.trim()) return;
    analyzeToneMutation.mutate(draftContent);
  };

  const getSuggestions = () => {
    if (!draftContent.trim() || !selectedEmailId) return;
    suggestImprovementsMutation.mutate({
      draftContent,
      originalEmailId: selectedEmailId,
    });
  };

  const getToneColor = (tone: string) => {
    switch (tone.toLowerCase()) {
      case 'professional':
        return 'bg-blue-500';
      case 'friendly':
        return 'bg-green-500';
      case 'formal':
        return 'bg-purple-500';
      case 'casual':
        return 'bg-orange-500';
      case 'urgent':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getSuggestionIcon = (type: string) => {
    switch (type) {
      case 'improvement':
        return <TrendingUp className="w-4 h-4" />;
      case 'tone':
        return <MessageSquare className="w-4 h-4" />;
      case 'clarity':
        return <Target className="w-4 h-4" />;
      case 'brevity':
        return <Sparkles className="w-4 h-4" />;
      default:
        return <Lightbulb className="w-4 h-4" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'text-red-600 bg-red-50 border-red-200';
      case 'medium':
        return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'low':
        return 'text-green-600 bg-green-50 border-green-200';
      default:
        return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  return (
    <div className="container mx-auto p-4 space-y-6">
      <div className="flex flex-col space-y-2">
        <h1 className="text-3xl font-bold tracking-tight">Enhanced Draft Assistant</h1>
        <p className="text-muted-foreground">
          AI-powered email composition with context-aware suggestions and tone analysis
        </p>
      </div>

      <Tabs defaultValue="compose" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="compose">
            <Brain className="w-4 h-4 mr-2" />
            AI Compose
          </TabsTrigger>
          <TabsTrigger value="analyze">
            <Target className="w-4 h-4 mr-2" />
            Tone Analysis
          </TabsTrigger>
          <TabsTrigger value="context">
            <Users className="w-4 h-4 mr-2" />
            Relationship Context
          </TabsTrigger>
        </TabsList>

        <TabsContent value="compose" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-2">
            {/* Draft Controls */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5" />
                  Draft Configuration
                </CardTitle>
                <CardDescription>
                  Configure AI settings for generating context-aware responses
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email-select">Original Email ID</Label>
                  <Select value={selectedEmailId} onValueChange={setSelectedEmailId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select email to respond to" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="email1">Sample Email 1 - Project Update</SelectItem>
                      <SelectItem value="email2">Sample Email 2 - Meeting Request</SelectItem>
                      <SelectItem value="email3">Sample Email 3 - Client Question</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="tone-select">Response Tone</Label>
                  <Select value={selectedTone} onValueChange={setSelectedTone}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="professional">Professional</SelectItem>
                      <SelectItem value="friendly">Friendly</SelectItem>
                      <SelectItem value="formal">Formal</SelectItem>
                      <SelectItem value="casual">Casual</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="priority-select">Email Priority</Label>
                  <Select value={selectedPriority} onValueChange={setSelectedPriority}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="high">High Priority</SelectItem>
                      <SelectItem value="medium">Medium Priority</SelectItem>
                      <SelectItem value="low">Low Priority</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="sender-input">Sender Email (for context)</Label>
                  <Select value={selectedSender} onValueChange={setSelectedSender}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select sender for context" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="john.doe@company.com">john.doe@company.com</SelectItem>
                      <SelectItem value="sarah.smith@client.com">sarah.smith@client.com</SelectItem>
                      <SelectItem value="manager@company.com">manager@company.com</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button 
                  onClick={generateEnhancedDraft}
                  disabled={!selectedEmailId || generateDraftMutation.isPending}
                  className="w-full"
                >
                  {generateDraftMutation.isPending ? (
                    <>
                      <Brain className="w-4 h-4 mr-2 animate-spin" />
                      Generating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Generate AI Draft
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* Enhanced Draft Results */}
            {enhancedDraft && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-green-500" />
                    Generated Draft
                  </CardTitle>
                  <CardDescription>
                    AI-generated response with context awareness
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-3">
                    <div className="space-y-1">
                      <Label className="text-xs text-muted-foreground">Tone</Label>
                      <Badge className={getToneColor(enhancedDraft.tone)}>
                        {enhancedDraft.tone}
                      </Badge>
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs text-muted-foreground">Confidence</Label>
                      <div className="flex items-center gap-2">
                        <Progress value={enhancedDraft.confidence} className="flex-1" />
                        <span className="text-sm text-muted-foreground">
                          {enhancedDraft.confidence}%
                        </span>
                      </div>
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs text-muted-foreground">Read Time</Label>
                      <Badge variant="outline">
                        <Clock className="w-3 h-3 mr-1" />
                        {enhancedDraft.estimatedReadTime}
                      </Badge>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Word Count: {enhancedDraft.wordCount}</Label>
                    <div className="text-xs text-muted-foreground">
                      Optimal for {selectedPriority} priority emails
                    </div>
                  </div>

                  {enhancedDraft.suggestions.length > 0 && (
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">AI Suggestions:</Label>
                      <div className="space-y-2">
                        {enhancedDraft.suggestions.slice(0, 3).map((suggestion, index) => (
                          <div key={index} className={`p-2 rounded-lg border ${getPriorityColor(suggestion.priority)}`}>
                            <div className="flex items-start gap-2">
                              {getSuggestionIcon(suggestion.type)}
                              <div className="flex-1">
                                <p className="text-sm font-medium capitalize">{suggestion.type}</p>
                                <p className="text-xs">{suggestion.suggestion}</p>
                              </div>
                              <Badge variant="outline" className="text-xs">
                                {suggestion.priority}
                              </Badge>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>

          {/* Draft Editor */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5" />
                Draft Editor
              </CardTitle>
              <CardDescription>
                Review and edit your AI-generated draft
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="draft-content">Email Content</Label>
                <Textarea
                  id="draft-content"
                  value={draftContent}
                  onChange={(e) => setDraftContent(e.target.value)}
                  placeholder="Your email draft will appear here, or write your own..."
                  rows={12}
                  className="min-h-[300px]"
                />
              </div>

              <div className="flex gap-2">
                <Button 
                  onClick={analyzeTone}
                  disabled={!draftContent.trim() || analyzeToneMutation.isPending}
                  variant="outline"
                >
                  {analyzeToneMutation.isPending ? (
                    <>
                      <Brain className="w-4 h-4 mr-2 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Target className="w-4 h-4 mr-2" />
                      Analyze Tone
                    </>
                  )}
                </Button>

                <Button 
                  onClick={getSuggestions}
                  disabled={!draftContent.trim() || !selectedEmailId || suggestImprovementsMutation.isPending}
                  variant="outline"
                >
                  {suggestImprovementsMutation.isPending ? (
                    <>
                      <Brain className="w-4 h-4 mr-2 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Lightbulb className="w-4 h-4 mr-2" />
                      Get Suggestions
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Improvement Suggestions */}
          {suggestions.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lightbulb className="w-5 h-5" />
                  Improvement Suggestions
                </CardTitle>
                <CardDescription>
                  AI-powered suggestions to enhance your email
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {suggestions.map((suggestion, index) => (
                    <div key={index} className={`p-4 rounded-lg border ${getPriorityColor(suggestion.priority)}`}>
                      <div className="flex items-start gap-3">
                        {getSuggestionIcon(suggestion.type)}
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-medium capitalize">{suggestion.type}</span>
                            <Badge variant="outline" className="text-xs">
                              {suggestion.priority}
                            </Badge>
                          </div>
                          <p className="text-sm text-muted-foreground mb-2">
                            {suggestion.suggestion}
                          </p>
                          {suggestion.example && (
                            <div className="p-2 bg-muted rounded text-xs">
                              <strong>Example:</strong> {suggestion.example}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="analyze" className="space-y-6">
          {toneAnalysis ? (
            <div className="grid gap-6 lg:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="w-5 h-5" />
                    Tone Analysis Results
                  </CardTitle>
                  <CardDescription>
                    AI analysis of your email's tone and sentiment
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label>Primary Tone</Label>
                      <Badge className={getToneColor(toneAnalysis.tone)}>
                        {toneAnalysis.tone}
                      </Badge>
                    </div>

                    <div className="space-y-2">
                      <Label>Confidence Score</Label>
                      <div className="flex items-center gap-2">
                        <Progress value={toneAnalysis.confidence} className="flex-1" />
                        <span className="text-sm text-muted-foreground">
                          {toneAnalysis.confidence}%
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <Label>Sentiment</Label>
                      <Badge variant="outline" className={
                        toneAnalysis.sentiment === 'positive' ? 'text-green-600' :
                        toneAnalysis.sentiment === 'negative' ? 'text-red-600' :
                        'text-gray-600'
                      }>
                        {toneAnalysis.sentiment}
                      </Badge>
                    </div>

                    <div className="flex items-center justify-between">
                      <Label>Formality</Label>
                      <Badge variant="outline">
                        {toneAnalysis.formality}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Lightbulb className="w-5 h-5" />
                    Tone Suggestions
                  </CardTitle>
                  <CardDescription>
                    Recommendations to improve your email's tone
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {toneAnalysis.suggestions.map((suggestion, index) => (
                      <div key={index} className="flex items-start gap-2 p-3 bg-muted rounded-lg">
                        <AlertCircle className="w-4 h-4 mt-0.5 text-blue-500 flex-shrink-0" />
                        <p className="text-sm">{suggestion}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Target className="w-12 h-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">No Tone Analysis Yet</h3>
                <p className="text-muted-foreground text-center mb-4">
                  Write or generate a draft in the Compose tab, then analyze its tone here
                </p>
                <Button 
                  onClick={analyzeTone}
                  disabled={!draftContent.trim() || analyzeToneMutation.isPending}
                >
                  Analyze Current Draft
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="context" className="space-y-6">
          {selectedSender ? (
            <div className="space-y-6">
              {contextLoading ? (
                <Card>
                  <CardContent className="flex items-center justify-center py-12">
                    <div className="text-center">
                      <Brain className="w-8 h-8 animate-spin mx-auto mb-4 text-muted-foreground" />
                      <p className="text-muted-foreground">Loading relationship context...</p>
                    </div>
                  </CardContent>
                </Card>
              ) : relationshipContext ? (
                <div className="grid gap-6 lg:grid-cols-2">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Users className="w-5 h-5" />
                        Relationship Overview
                      </CardTitle>
                      <CardDescription>
                        Context about your communication history with {relationshipContext.sender}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid gap-4 md:grid-cols-2">
                        <div className="space-y-2">
                          <Label className="text-sm text-muted-foreground">Total Emails</Label>
                          <div className="text-2xl font-bold">{relationshipContext.totalEmails}</div>
                        </div>
                        <div className="space-y-2">
                          <Label className="text-sm text-muted-foreground">Last Interaction</Label>
                          <div className="text-sm">{relationshipContext.lastInteraction}</div>
                        </div>
                      </div>

                      <Separator />

                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <Label>Relationship Type</Label>
                          <Badge variant="outline">{relationshipContext.relationship}</Badge>
                        </div>
                        <div className="flex items-center justify-between">
                          <Label>Response Pattern</Label>
                          <Badge variant="outline">{relationshipContext.responsePattern}</Badge>
                        </div>
                        <div className="flex items-center justify-between">
                          <Label>Preferred Tone</Label>
                          <Badge className={getToneColor(relationshipContext.preferredTone)}>
                            {relationshipContext.preferredTone}
                          </Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <MessageSquare className="w-5 h-5" />
                        Communication Insights
                      </CardTitle>
                      <CardDescription>
                        Common topics and communication patterns
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <Label>Common Topics</Label>
                        <div className="flex flex-wrap gap-1">
                          {relationshipContext.commonTopics.map((topic, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {topic}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <Separator />

                      <div className="p-3 bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg">
                        <div className="flex items-start gap-2">
                          <Lightbulb className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
                          <div>
                            <p className="text-sm font-medium text-blue-800 dark:text-blue-200 mb-1">
                              AI Recommendation
                            </p>
                            <p className="text-sm text-blue-700 dark:text-blue-300">
                              Based on your history, use a {relationshipContext.preferredTone} tone and 
                              reference previous discussions about {relationshipContext.commonTopics[0]} 
                              for better context.
                            </p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ) : (
                <Card>
                  <CardContent className="flex flex-col items-center justify-center py-12">
                    <AlertCircle className="w-12 h-12 text-muted-foreground mb-4" />
                    <h3 className="text-lg font-medium mb-2">No Context Available</h3>
                    <p className="text-muted-foreground text-center">
                      Unable to load relationship context for {selectedSender}
                    </p>
                  </CardContent>
                </Card>
              )}
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Users className="w-12 h-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">Select a Sender</h3>
                <p className="text-muted-foreground text-center mb-4">
                  Choose a sender in the Compose tab to view relationship context and communication history
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}