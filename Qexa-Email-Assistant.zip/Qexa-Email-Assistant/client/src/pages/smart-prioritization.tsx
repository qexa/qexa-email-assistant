import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Separator } from "@/components/ui/separator";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertVipContactSchema, type VipContact } from "@shared/schema";
import { Brain, Clock, Star, Users, AlertTriangle, TrendingUp, Target, CheckCircle2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { z } from "zod";

type PriorityAnalysis = {
  urgency: 'urgent' | 'high' | 'medium' | 'low';
  importance: 'critical' | 'high' | 'medium' | 'low';
  score: number;
  reasons: string[];
  isFromVip: boolean;
  needsResponse: boolean;
  estimatedResponseTime: string;
};

type InboxTriage = {
  urgent: any[];
  highPriority: any[];
  mediumPriority: any[];
  lowPriority: any[];
  requiresAction: any[];
  canAutoRespond: any[];
  statistics: {
    totalEmails: number;
    processed: number;
    avgResponseTime: string;
    vipEmails: number;
  };
};

export default function SmartPrioritization() {
  const [selectedEmail, setSelectedEmail] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<PriorityAnalysis | null>(null);
  const queryClient = useQueryClient();

  const form = useForm<z.infer<typeof insertVipContactSchema>>({
    resolver: zodResolver(insertVipContactSchema),
    defaultValues: {
      name: "",
      email: "",
      title: "",
      company: "",
      priorityLevel: 3,
      relationship: "colleague",
      notes: "",
    },
  });

  // Fetch VIP contacts
  const { data: vipContacts = [], isLoading: vipLoading } = useQuery<VipContact[]>({
    queryKey: ["/api/prioritization/vip-contacts"],
  });

  // Fetch inbox triage
  const { data: inboxTriage, isLoading: triageLoading } = useQuery<InboxTriage>({
    queryKey: ["/api/prioritization/inbox-triage"],
  });

  // Create VIP contact mutation
  const createVipMutation = useMutation({
    mutationFn: async (data: z.infer<typeof insertVipContactSchema>) => {
      const response = await apiRequest("/api/prioritization/vip-contacts", {
        method: "POST",
        body: JSON.stringify(data),
      });
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/prioritization/vip-contacts"] });
      form.reset();
    },
  });

  // Analyze email priority mutation
  const analyzeMutation = useMutation({
    mutationFn: async (emailId: string) => {
      const response = await apiRequest("/api/prioritization/analyze", {
        method: "POST",
        body: JSON.stringify({ emailId }),
      });
      return response as PriorityAnalysis;
    },
    onSuccess: (result: PriorityAnalysis) => {
      setAnalysisResult(result);
    },
  });

  const onSubmitVip = (data: z.infer<typeof insertVipContactSchema>) => {
    createVipMutation.mutate(data);
  };

  const analyzeEmailPriority = (emailId: string) => {
    setSelectedEmail(emailId);
    analyzeMutation.mutate(emailId);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent':
      case 'critical':
        return 'bg-red-500';
      case 'high':
        return 'bg-orange-500';
      case 'medium':
        return 'bg-yellow-500';
      case 'low':
        return 'bg-green-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'urgent':
      case 'critical':
        return <AlertTriangle className="w-4 h-4" />;
      case 'high':
        return <TrendingUp className="w-4 h-4" />;
      case 'medium':
        return <Target className="w-4 h-4" />;
      case 'low':
        return <CheckCircle2 className="w-4 h-4" />;
      default:
        return <Clock className="w-4 h-4" />;
    }
  };

  return (
    <div className="container mx-auto p-4 space-y-6">
      <div className="flex flex-col space-y-2">
        <h1 className="text-3xl font-bold tracking-tight">Smart Email Prioritization</h1>
        <p className="text-muted-foreground">
          AI-powered email triage and priority management for busy executives
        </p>
      </div>

      <Tabs defaultValue="triage" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="triage">
            <Brain className="w-4 h-4 mr-2" />
            Inbox Triage
          </TabsTrigger>
          <TabsTrigger value="vip">
            <Star className="w-4 h-4 mr-2" />
            VIP Contacts
          </TabsTrigger>
          <TabsTrigger value="analytics">
            <TrendingUp className="w-4 h-4 mr-2" />
            Analytics
          </TabsTrigger>
        </TabsList>

        <TabsContent value="triage" className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Urgent Emails</CardTitle>
                <AlertTriangle className="h-4 w-4 text-red-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {triageLoading ? '...' : inboxTriage?.urgent?.length || 0}
                </div>
                <p className="text-xs text-muted-foreground">
                  Requires immediate attention
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">High Priority</CardTitle>
                <TrendingUp className="h-4 w-4 text-orange-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {triageLoading ? '...' : inboxTriage?.highPriority?.length || 0}
                </div>
                <p className="text-xs text-muted-foreground">
                  Important emails
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">VIP Emails</CardTitle>
                <Star className="h-4 w-4 text-yellow-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {triageLoading ? '...' : inboxTriage?.statistics?.vipEmails || 0}
                </div>
                <p className="text-xs text-muted-foreground">
                  From VIP contacts
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Auto-Response</CardTitle>
                <CheckCircle2 className="h-4 w-4 text-green-500" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {triageLoading ? '...' : inboxTriage?.canAutoRespond?.length || 0}
                </div>
                <p className="text-xs text-muted-foreground">
                  Can be auto-responded
                </p>
              </CardContent>
            </Card>
          </div>

          {inboxTriage && (
            <div className="space-y-4">
              <Card className="border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-950">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-red-700 dark:text-red-300">
                    <AlertTriangle className="w-5 h-5" />
                    Urgent Attention Required
                  </CardTitle>
                  <CardDescription>
                    These emails need immediate response within the next hour
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {inboxTriage.urgent.length > 0 ? (
                    <div className="space-y-2">
                      {inboxTriage.urgent.map((email: any, index: number) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-white dark:bg-gray-800 rounded-lg">
                          <div className="flex-1">
                            <p className="font-medium">{email.subject}</p>
                            <p className="text-sm text-muted-foreground">{email.sender}</p>
                          </div>
                          <Button 
                            size="sm" 
                            onClick={() => analyzeEmailPriority(email.id)}
                            className="ml-4"
                          >
                            Analyze
                          </Button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-muted-foreground">No urgent emails at the moment.</p>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="w-5 h-5" />
                    High Priority Queue
                  </CardTitle>
                  <CardDescription>
                    Important emails that should be addressed today
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {inboxTriage.highPriority.length > 0 ? (
                    <div className="space-y-2">
                      {inboxTriage.highPriority.slice(0, 5).map((email: any, index: number) => (
                        <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                          <div className="flex-1">
                            <p className="font-medium">{email.subject}</p>
                            <p className="text-sm text-muted-foreground">{email.sender}</p>
                          </div>
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => analyzeEmailPriority(email.id)}
                          >
                            Analyze
                          </Button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-muted-foreground">No high priority emails.</p>
                  )}
                </CardContent>
              </Card>
            </div>
          )}

          {analysisResult && (
            <Card className="border-blue-200 bg-blue-50 dark:border-blue-800 dark:bg-blue-950">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="w-5 h-5" />
                  AI Priority Analysis
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-3">
                  <div className="flex items-center gap-2">
                    <Badge className={getPriorityColor(analysisResult.urgency)}>
                      {getPriorityIcon(analysisResult.urgency)}
                      {analysisResult.urgency.toUpperCase()}
                    </Badge>
                    <span className="text-sm text-muted-foreground">Urgency</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={getPriorityColor(analysisResult.importance)}>
                      {getPriorityIcon(analysisResult.importance)}
                      {analysisResult.importance.toUpperCase()}
                    </Badge>
                    <span className="text-sm text-muted-foreground">Importance</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">
                      Score: {analysisResult.score}/100
                    </Badge>
                  </div>
                </div>

                <Separator />

                <div className="space-y-2">
                  <h4 className="font-medium">Analysis Reasons:</h4>
                  <ul className="space-y-1">
                    {analysisResult.reasons.map((reason, index) => (
                      <li key={index} className="text-sm text-muted-foreground flex items-start gap-2">
                        <span className="w-1 h-1 bg-current rounded-full mt-2 flex-shrink-0" />
                        {reason}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label>Response Required</Label>
                    <Badge variant={analysisResult.needsResponse ? "default" : "secondary"}>
                      {analysisResult.needsResponse ? "Yes" : "No"}
                    </Badge>
                  </div>
                  <div className="space-y-2">
                    <Label>Estimated Response Time</Label>
                    <Badge variant="outline">
                      <Clock className="w-3 h-3 mr-1" />
                      {analysisResult.estimatedResponseTime}
                    </Badge>
                  </div>
                </div>

                {analysisResult.isFromVip && (
                  <div className="p-3 bg-yellow-50 dark:bg-yellow-950 border border-yellow-200 dark:border-yellow-800 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Star className="w-4 h-4 text-yellow-600" />
                      <span className="text-sm font-medium text-yellow-800 dark:text-yellow-200">
                        This email is from a VIP contact
                      </span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="vip" className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-2xl font-bold">VIP Contacts</h2>
              <p className="text-muted-foreground">
                Manage your important contacts for priority email handling
              </p>
            </div>
            <Dialog>
              <DialogTrigger asChild>
                <Button>
                  <Users className="w-4 h-4 mr-2" />
                  Add VIP Contact
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>Add VIP Contact</DialogTitle>
                  <DialogDescription>
                    Add a new VIP contact for priority email handling
                  </DialogDescription>
                </DialogHeader>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmitVip)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Full name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="email@example.com" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Title</FormLabel>
                          <FormControl>
                            <Input placeholder="Job title" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="company"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Company</FormLabel>
                          <FormControl>
                            <Input placeholder="Company name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="priorityLevel"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Priority Level</FormLabel>
                          <FormControl>
                            <Select value={field.value?.toString()} onValueChange={(value) => field.onChange(parseInt(value))}>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="5">Critical</SelectItem>
                                <SelectItem value="4">High</SelectItem>
                                <SelectItem value="3">Medium</SelectItem>
                                <SelectItem value="2">Low</SelectItem>
                                <SelectItem value="1">Very Low</SelectItem>
                              </SelectContent>
                            </Select>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="relationship"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Relationship</FormLabel>
                          <FormControl>
                            <Select value={field.value} onValueChange={field.onChange}>
                              <SelectTrigger>
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="boss">Boss</SelectItem>
                                <SelectItem value="colleague">Colleague</SelectItem>
                                <SelectItem value="client">Client</SelectItem>
                                <SelectItem value="partner">Partner</SelectItem>
                                <SelectItem value="investor">Investor</SelectItem>
                                <SelectItem value="other">Other</SelectItem>
                              </SelectContent>
                            </Select>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button 
                      type="submit" 
                      className="w-full"
                      disabled={createVipMutation.isPending}
                    >
                      {createVipMutation.isPending ? "Adding..." : "Add VIP Contact"}
                    </Button>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {vipLoading ? (
              <div className="col-span-full text-center py-8">
                <p className="text-muted-foreground">Loading VIP contacts...</p>
              </div>
            ) : vipContacts.length > 0 ? (
              vipContacts.map((contact) => (
                <Card key={contact.id}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg">{contact.name}</CardTitle>
                        <CardDescription>{contact.email}</CardDescription>
                      </div>
                      <Badge className={getPriorityColor(contact.priorityLevel?.toString() || 'medium')}>
                        {contact.priorityLevel === 5 ? 'Critical' : 
                         contact.priorityLevel === 4 ? 'High' : 
                         contact.priorityLevel === 3 ? 'Medium' : 
                         contact.priorityLevel === 2 ? 'Low' : 'Very Low'}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Title:</span>
                        <span>{contact.title || 'N/A'}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Company:</span>
                        <span>{contact.company || 'N/A'}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Relationship:</span>
                        <span className="capitalize">{contact.relationship}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Interactions:</span>
                        <span>{contact.interactionCount}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="col-span-full text-center py-8">
                <Star className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">No VIP contacts yet</h3>
                <p className="text-muted-foreground mb-4">
                  Add your important contacts to prioritize their emails
                </p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Processed</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {triageLoading ? '...' : inboxTriage?.statistics?.totalEmails || 0}
                </div>
                <p className="text-xs text-muted-foreground">
                  Emails analyzed today
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Avg Response Time</CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {triageLoading ? '...' : inboxTriage?.statistics?.avgResponseTime || 'N/A'}
                </div>
                <p className="text-xs text-muted-foreground">
                  For high priority emails
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">VIP Contacts</CardTitle>
                <Star className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {vipLoading ? '...' : vipContacts.length}
                </div>
                <p className="text-xs text-muted-foreground">
                  Active VIP contacts
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Accuracy Rate</CardTitle>
                <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">94%</div>
                <p className="text-xs text-muted-foreground">
                  Priority classification accuracy
                </p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Priority Distribution</CardTitle>
              <CardDescription>
                How your emails are being categorized by our AI system
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                    <span>Urgent</span>
                  </div>
                  <span className="text-sm text-muted-foreground">
                    {triageLoading ? '...' : `${inboxTriage?.urgent?.length || 0} emails`}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
                    <span>High Priority</span>
                  </div>
                  <span className="text-sm text-muted-foreground">
                    {triageLoading ? '...' : `${inboxTriage?.highPriority?.length || 0} emails`}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                    <span>Medium Priority</span>
                  </div>
                  <span className="text-sm text-muted-foreground">
                    {triageLoading ? '...' : `${inboxTriage?.mediumPriority?.length || 0} emails`}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span>Low Priority</span>
                  </div>
                  <span className="text-sm text-muted-foreground">
                    {triageLoading ? '...' : `${inboxTriage?.lowPriority?.length || 0} emails`}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}