import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useState } from "react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line
} from "recharts";
import { 
  Mail, 
  TrendingUp, 
  Clock, 
  Target,
  Calendar,
  Bot,
  AlertCircle,
  CheckCircle
} from "lucide-react";

export default function Analytics() {
  const [timeRange, setTimeRange] = useState("7d");

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
  });

  const { data: emails, isLoading: emailsLoading } = useQuery({
    queryKey: ["/api/emails", { limit: 100 }],
  });

  const { data: drafts, isLoading: draftsLoading } = useQuery({
    queryKey: ["/api/drafts"],
  });

  const { data: providers, isLoading: providersLoading } = useQuery({
    queryKey: ["/api/ai-providers"],
  });

  const { data: events, isLoading: eventsLoading } = useQuery({
    queryKey: ["/api/calendar-events"],
  });

  // Generate chart data
  const generateEmailVolumeData = () => {
    if (!emails) return [];
    
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - i);
      return {
        date: date.toISOString().split('T')[0],
        day: date.toLocaleDateString('en-US', { weekday: 'short' }),
        count: 0
      };
    }).reverse();

    emails.forEach((email: any) => {
      const emailDate = new Date(email.receivedAt).toISOString().split('T')[0];
      const dayData = last7Days.find(d => d.date === emailDate);
      if (dayData) dayData.count++;
    });

    return last7Days;
  };

  const generatePriorityData = () => {
    if (!emails) return [];
    
    const priorities = emails.reduce((acc: any, email: any) => {
      const priority = email.priority || 'unclassified';
      acc[priority] = (acc[priority] || 0) + 1;
      return acc;
    }, {});

    return Object.entries(priorities).map(([priority, count]) => ({
      priority,
      count,
      color: priority === 'high' ? '#ef4444' : 
             priority === 'medium' ? '#f59e0b' : 
             priority === 'low' ? '#10b981' : '#6b7280'
    }));
  };

  const generateProviderUsageData = () => {
    if (!providers) return [];
    
    return providers.map((provider: any) => ({
      name: provider.name,
      usage: provider.usageToday || 0,
      successRate: provider.successRate || 0,
      color: provider.name === 'openai' ? '#10b981' :
             provider.name === 'claude' ? '#8b5cf6' : '#3b82f6'
    }));
  };

  const emailVolumeData = generateEmailVolumeData();
  const priorityData = generatePriorityData();
  const providerData = generateProviderUsageData();

  const processedEmailsToday = emails?.filter((email: any) => {
    const today = new Date();
    const emailDate = new Date(email.processedAt || email.receivedAt);
    return emailDate.toDateString() === today.toDateString();
  }).length || 0;

  const averageResponseTime = "2.3 minutes"; // This would be calculated from actual data
  const classificationAccuracy = stats?.accuracy || "0%";

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <header className="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-gray-800">Analytics</h1>
            <p className="text-sm text-gray-600">Email processing performance and insights</p>
          </div>
          <div className="flex items-center space-x-4">
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="24h">Last 24 hours</SelectItem>
                <SelectItem value="7d">Last 7 days</SelectItem>
                <SelectItem value="30d">Last 30 days</SelectItem>
                <SelectItem value="90d">Last 3 months</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto bg-gray-50 p-6">
        <div className="max-w-7xl mx-auto">
          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <Mail className="w-5 h-5 text-blue-600" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm text-gray-600">Total Emails</p>
                    <p className="text-2xl font-semibold text-gray-800">
                      {statsLoading ? <Skeleton className="w-16 h-8" /> : stats?.totalEmails || 0}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm text-gray-600">Processed Today</p>
                    <p className="text-2xl font-semibold text-gray-800">
                      {emailsLoading ? <Skeleton className="w-16 h-8" /> : processedEmailsToday}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                      <Target className="w-5 h-5 text-purple-600" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm text-gray-600">Classification Accuracy</p>
                    <p className="text-2xl font-semibold text-gray-800">
                      {statsLoading ? <Skeleton className="w-16 h-8" /> : classificationAccuracy}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
                      <Clock className="w-5 h-5 text-yellow-600" />
                    </div>
                  </div>
                  <div className="ml-4">
                    <p className="text-sm text-gray-600">Avg Response Time</p>
                    <p className="text-2xl font-semibold text-gray-800">
                      {averageResponseTime}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            {/* Email Volume Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Email Volume (Last 7 Days)</CardTitle>
              </CardHeader>
              <CardContent>
                {emailsLoading ? (
                  <Skeleton className="w-full h-64" />
                ) : (
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={emailVolumeData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="day" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="count" fill="#3b82f6" />
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>

            {/* Priority Distribution */}
            <Card>
              <CardHeader>
                <CardTitle>Priority Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                {emailsLoading ? (
                  <Skeleton className="w-full h-64" />
                ) : (
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={priorityData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ priority, count }) => `${priority}: ${count}`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="count"
                      >
                        {priorityData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                )}
              </CardContent>
            </Card>
          </div>

          {/* AI Provider Performance */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>AI Provider Performance</CardTitle>
            </CardHeader>
            <CardContent>
              {providersLoading ? (
                <div className="space-y-4">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <Skeleton className="w-8 h-8 rounded-lg" />
                        <div className="space-y-1">
                          <Skeleton className="h-4 w-16" />
                          <Skeleton className="h-3 w-24" />
                        </div>
                      </div>
                      <div className="text-right space-y-1">
                        <Skeleton className="h-4 w-20" />
                        <Skeleton className="h-3 w-16" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="space-y-4">
                  {providers?.map((provider: any) => (
                    <div key={provider.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                          provider.name === 'openai' ? 'bg-green-100' :
                          provider.name === 'claude' ? 'bg-purple-100' : 'bg-blue-100'
                        }`}>
                          <Bot className={`w-4 h-4 ${
                            provider.name === 'openai' ? 'text-green-600' :
                            provider.name === 'claude' ? 'text-purple-600' : 'text-blue-600'
                          }`} />
                        </div>
                        <div>
                          <p className="font-medium text-gray-900 capitalize">{provider.name}</p>
                          <p className="text-sm text-gray-500">
                            {provider.isActive ? 'Active' : 'Inactive'}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-gray-900">
                          {provider.usageToday || 0} requests today
                        </p>
                        <p className="text-sm text-gray-500">
                          {provider.successRate || 0}% success rate
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Draft Statistics */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Draft Statistics</CardTitle>
              </CardHeader>
              <CardContent>
                {draftsLoading ? (
                  <div className="space-y-4">
                    {[...Array(4)].map((_, i) => (
                      <div key={i} className="flex items-center justify-between">
                        <Skeleton className="h-4 w-24" />
                        <Skeleton className="h-4 w-12" />
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Total Drafts</span>
                      <span className="font-medium">{drafts?.length || 0}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Pending Review</span>
                      <Badge className="bg-yellow-100 text-yellow-800">
                        {drafts?.filter((d: any) => d.status === 'pending').length || 0}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Approved</span>
                      <Badge className="bg-green-100 text-green-800">
                        {drafts?.filter((d: any) => d.status === 'approved').length || 0}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Rejected</span>
                      <Badge className="bg-red-100 text-red-800">
                        {drafts?.filter((d: any) => d.status === 'rejected').length || 0}
                      </Badge>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Calendar Events</CardTitle>
              </CardHeader>
              <CardContent>
                {eventsLoading ? (
                  <div className="space-y-4">
                    {[...Array(3)].map((_, i) => (
                      <div key={i} className="flex items-center justify-between">
                        <Skeleton className="h-4 w-32" />
                        <Skeleton className="h-4 w-12" />
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Total Events</span>
                      <span className="font-medium">{events?.length || 0}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Auto-Created</span>
                      <span className="font-medium">
                        {events?.filter((e: any) => e.emailId && e.emailId !== 'manual-event').length || 0}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Manual</span>
                      <span className="font-medium">
                        {events?.filter((e: any) => e.emailId === 'manual-event').length || 0}
                      </span>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
