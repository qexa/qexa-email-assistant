import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Mail, 
  Brain, 
  Calendar, 
  Settings, 
  Plus, 
  Eye, 
  BarChart3, 
  Shield,
  CheckCircle,
  AlertCircle,
  Info,
  Zap
} from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import InteractiveDemo from "@/components/interactive-demo";

export default function UserGuide() {
  return (
    <div className="flex flex-col h-full">
      <div className="border-b bg-white/50 backdrop-blur supports-[backdrop-filter]:bg-white/50 p-6">
        <h1 className="text-3xl font-bold text-gray-900">Qexa Email Assistant User Guide</h1>
        <p className="text-gray-600 mt-2">Learn how to use your intelligent email management system</p>
      </div>

      <div className="flex-1 overflow-auto p-6">
        <div className="max-w-4xl mx-auto space-y-8">
          
          {/* Overview Section */}
          <section className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                <Info className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-900">What This Tool Does</h2>
                <p className="text-gray-600">Your AI-powered email assistant</p>
              </div>
            </div>
            
            <Card>
              <CardContent className="p-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="font-semibold mb-3 text-gray-900">Key Features:</h3>
                    <ul className="space-y-2 text-sm text-gray-600">
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        Monitors multiple email accounts automatically
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        Sorts emails by importance using AI
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        Creates draft replies automatically
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        Adds meetings to your calendar
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="w-4 h-4 text-green-500" />
                        Shows detailed analytics and insights
                      </li>
                    </ul>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-3 text-gray-900">Supported Email Providers:</h3>
                    <div className="space-y-2">
                      <Badge variant="secondary" className="mr-2">Gmail</Badge>
                      <Badge variant="secondary" className="mr-2">Outlook</Badge>
                      <Badge variant="secondary" className="mr-2">IMAP</Badge>
                    </div>
                    
                    <h3 className="font-semibold mb-3 mt-4 text-gray-900">AI Providers:</h3>
                    <div className="space-y-2">
                      <Badge variant="outline" className="mr-2">OpenAI GPT-4</Badge>
                      <Badge variant="outline" className="mr-2">Anthropic Claude</Badge>
                      <Badge variant="outline" className="mr-2">Google Gemini</Badge>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </section>

          {/* Getting Started */}
          <section className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
                <Zap className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Getting Started</h2>
                <p className="text-gray-600">Set up your system in 4 easy steps</p>
              </div>
            </div>

            <div className="grid gap-4">
              {[
                {
                  step: "1",
                  title: "Connect Your Email Accounts",
                  description: "Add Gmail, Outlook, or IMAP email accounts",
                  icon: Mail,
                  action: "Go to Email Accounts page and click 'Add Account'"
                },
                {
                  step: "2", 
                  title: "Create Classification Rules",
                  description: "Tell the AI how to sort your emails",
                  icon: Brain,
                  action: "Visit Classification Rules and create your first rule"
                },
                {
                  step: "3",
                  title: "Configure AI Settings",
                  description: "Choose which AI providers to use",
                  icon: Settings,
                  action: "Check Settings page to configure AI preferences"
                },
                {
                  step: "4",
                  title: "Review Your Dashboard",
                  description: "Monitor everything from the main dashboard",
                  icon: BarChart3,
                  action: "Dashboard shows all activity and statistics"
                }
              ].map((step, index) => (
                <Card key={index} className="relative">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold text-lg shrink-0">
                        {step.step}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <step.icon className="w-5 h-5 text-gray-600" />
                          <h3 className="font-semibold text-gray-900">{step.title}</h3>
                        </div>
                        <p className="text-gray-600 mb-2">{step.description}</p>
                        <p className="text-sm text-blue-600 font-medium">{step.action}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>

          {/* Interactive Demo */}
          <section className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
                <Zap className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-900">See It In Action</h2>
                <p className="text-gray-600">Interactive demos showing how each feature works</p>
              </div>
            </div>
            
            <InteractiveDemo />
          </section>

          {/* Detailed Features */}
          <section className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-orange-100 flex items-center justify-center">
                <Settings className="w-5 h-5 text-orange-600" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Detailed Feature Guide</h2>
                <p className="text-gray-600">Learn how to use each feature effectively</p>
              </div>
            </div>

            {/* Email Accounts */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Mail className="w-5 h-5" />
                  Email Accounts Management
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-600">Connect and manage multiple email accounts from different providers.</p>
                
                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-900">How to Add an Account:</h4>
                  <ol className="list-decimal list-inside space-y-2 text-sm text-gray-600 ml-4">
                    <li>Click the "Add Email Account" button</li>
                    <li>Choose your email provider (Gmail, Outlook, or IMAP)</li>
                    <li>For Gmail/Outlook: You'll be redirected to sign in securely</li>
                    <li>For IMAP: Enter your server settings manually</li>
                    <li>The system will test the connection and save your account</li>
                  </ol>
                </div>

                <Alert>
                  <Shield className="h-4 w-4" />
                  <AlertDescription>
                    Your login information is encrypted and stored securely. We never see your passwords.
                  </AlertDescription>
                </Alert>

                <div className="space-y-2">
                  <h4 className="font-semibold text-gray-900">Account Status Indicators:</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-green-500"></div>
                      <span className="text-gray-600">Active and syncing</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                      <span className="text-gray-600">Needs attention</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-red-500"></div>
                      <span className="text-gray-600">Connection error</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-gray-400"></div>
                      <span className="text-gray-600">Paused</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Classification Rules */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="w-5 h-5" />
                  Smart Email Classification
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-600">Create rules to automatically categorize and handle your emails based on content, sender, and keywords.</p>
                
                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-900">Creating a Classification Rule:</h4>
                  <ol className="list-decimal list-inside space-y-2 text-sm text-gray-600 ml-4">
                    <li>Click "Create New Rule"</li>
                    <li>Give your rule a descriptive name</li>
                    <li>Set the priority level (High, Medium, Low)</li>
                    <li>Add keywords to look for in emails</li>
                    <li>Specify sender patterns (like @company.com)</li>
                    <li>Choose what actions to take automatically</li>
                  </ol>
                </div>

                <div className="space-y-2">
                  <h4 className="font-semibold text-gray-900">Available Actions:</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-blue-500" />
                      <span className="text-gray-600">Flag as important</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-blue-500" />
                      <span className="text-gray-600">Create draft response</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-blue-500" />
                      <span className="text-gray-600">Add to calendar</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-blue-500" />
                      <span className="text-gray-600">Move to folder</span>
                    </div>
                  </div>
                </div>

                <Alert>
                  <Info className="h-4 w-4" />
                  <AlertDescription>
                    <strong>Pro Tip:</strong> Start with broad rules and refine them based on the results you see in analytics.
                  </AlertDescription>
                </Alert>
              </CardContent>
            </Card>

            {/* Draft Review */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Eye className="w-5 h-5" />
                  AI-Generated Draft Review
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-600">Review and approve draft responses created by AI before they're sent.</p>
                
                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-900">Draft Review Process:</h4>
                  <ol className="list-decimal list-inside space-y-2 text-sm text-gray-600 ml-4">
                    <li>AI creates draft responses based on your rules</li>
                    <li>Drafts appear in the Review queue with confidence scores</li>
                    <li>You can edit, approve, or reject each draft</li>
                    <li>Approved drafts can be sent automatically or manually</li>
                  </ol>
                </div>

                <div className="space-y-2">
                  <h4 className="font-semibold text-gray-900">Understanding Confidence Scores:</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center justify-between p-2 bg-green-50 rounded">
                      <span className="text-gray-600">90-100%</span>
                      <span className="text-green-700 font-medium">High confidence - AI is very sure</span>
                    </div>
                    <div className="flex items-center justify-between p-2 bg-yellow-50 rounded">
                      <span className="text-gray-600">70-89%</span>
                      <span className="text-yellow-700 font-medium">Medium confidence - Review recommended</span>
                    </div>
                    <div className="flex items-center justify-between p-2 bg-red-50 rounded">
                      <span className="text-gray-600">Below 70%</span>
                      <span className="text-red-700 font-medium">Low confidence - Manual review needed</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Calendar Integration */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="w-5 h-5" />
                  Calendar Integration
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-600">Automatically detect meeting requests and create calendar events.</p>
                
                <div className="space-y-3">
                  <h4 className="font-semibold text-gray-900">How It Works:</h4>
                  <ol className="list-decimal list-inside space-y-2 text-sm text-gray-600 ml-4">
                    <li>AI scans emails for meeting-related content</li>
                    <li>Extracts date, time, location, and attendees</li>
                    <li>Creates calendar events automatically or asks for approval</li>
                    <li>Sends calendar invites to all participants</li>
                  </ol>
                </div>

                <div className="space-y-2">
                  <h4 className="font-semibold text-gray-900">Configuration Options:</h4>
                  <div className="grid gap-2 text-sm text-gray-600">
                    <label className="flex items-center gap-2">
                      <input type="checkbox" defaultChecked className="rounded" />
                      Auto-create events for confirmed meetings
                    </label>
                    <label className="flex items-center gap-2">
                      <input type="checkbox" className="rounded" />
                      Require approval before creating events
                    </label>
                    <label className="flex items-center gap-2">
                      <input type="checkbox" defaultChecked className="rounded" />
                      Send invites to attendees automatically
                    </label>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Analytics */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5" />
                  Analytics & Insights
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-600">Track your email patterns, AI performance, and productivity metrics.</p>
                
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Email Metrics:</h4>
                    <ul className="space-y-1 text-sm text-gray-600">
                      <li>• Total emails processed</li>
                      <li>• Daily/weekly volume trends</li>
                      <li>• Response time averages</li>
                      <li>• Priority distribution</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">AI Performance:</h4>
                    <ul className="space-y-1 text-sm text-gray-600">
                      <li>• Classification accuracy</li>
                      <li>• Draft approval rates</li>
                      <li>• Provider usage statistics</li>
                      <li>• Confidence score trends</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </section>

          {/* Troubleshooting */}
          <section className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-red-100 flex items-center justify-center">
                <AlertCircle className="w-5 h-5 text-red-600" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Troubleshooting</h2>
                <p className="text-gray-600">Common issues and solutions</p>
              </div>
            </div>

            <div className="grid gap-4">
              {[
                {
                  problem: "Email account won't connect",
                  solution: "Check your credentials and ensure 2-factor authentication is properly configured. For Gmail, you may need an app-specific password."
                },
                {
                  problem: "AI drafts seem inaccurate",
                  solution: "Review your classification rules and provide more specific keywords. The AI learns from your feedback over time."
                },
                {
                  problem: "Calendar events aren't being created",
                  solution: "Verify your Google Calendar integration is active and check the auto-create settings in Calendar Integration."
                },
                {
                  problem: "System seems slow",
                  solution: "Check the number of active email accounts and rules. Consider temporarily disabling some accounts if you have many connected."
                }
              ].map((item, index) => (
                <Card key={index}>
                  <CardContent className="p-4">
                    <h4 className="font-semibold text-gray-900 mb-2">{item.problem}</h4>
                    <p className="text-sm text-gray-600">{item.solution}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>

          {/* Best Practices */}
          <section className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-yellow-100 flex items-center justify-center">
                <CheckCircle className="w-5 h-5 text-yellow-600" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Best Practices</h2>
                <p className="text-gray-600">Tips for getting the most out of your system</p>
              </div>
            </div>

            <Card>
              <CardContent className="p-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Do's:</h4>
                    <ul className="space-y-2 text-sm text-gray-600">
                      <li className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 shrink-0" />
                        Start with a few simple rules and expand gradually
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 shrink-0" />
                        Review AI drafts regularly to improve accuracy
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 shrink-0" />
                        Use specific keywords in your classification rules
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 shrink-0" />
                        Monitor analytics to optimize your setup
                      </li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Don'ts:</h4>
                    <ul className="space-y-2 text-sm text-gray-600">
                      <li className="flex items-start gap-2">
                        <AlertCircle className="w-4 h-4 text-red-500 mt-0.5 shrink-0" />
                        Don't create too many overlapping rules
                      </li>
                      <li className="flex items-start gap-2">
                        <AlertCircle className="w-4 h-4 text-red-500 mt-0.5 shrink-0" />
                        Don't approve all drafts without reviewing them
                      </li>
                      <li className="flex items-start gap-2">
                        <AlertCircle className="w-4 h-4 text-red-500 mt-0.5 shrink-0" />
                        Don't connect inactive email accounts
                      </li>
                      <li className="flex items-start gap-2">
                        <AlertCircle className="w-4 h-4 text-red-500 mt-0.5 shrink-0" />
                        Don't ignore system notifications and alerts
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </section>

        </div>
      </div>
    </div>
  );
}