import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  TrendingUp, 
  Clock, 
  Target, 
  Zap, 
  Mail, 
  Calendar,
  Brain,
  CheckCircle,
  AlertTriangle,
  BarChart3
} from "lucide-react";

export default function ProductivityInsights() {
  const { data: insights, isLoading } = useQuery({
    queryKey: ["/api/analytics/productivity-insights"],
  });

  const { data: timeMetrics } = useQuery({
    queryKey: ["/api/analytics/time-metrics"],
  });

  const { data: aiMetrics } = useQuery({
    queryKey: ["/api/analytics/ai-metrics"],
  });

  if (isLoading) {
    return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
          <h1 className="text-2xl font-semibold text-gray-800">Productivity Insights</h1>
        </header>
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-gray-600">Loading insights...</p>
          </div>
        </main>
      </div>
    );
  }

  const timeSavedWeekly = timeMetrics?.timeSavedWeekly || 0;
  const responseTimeImprovement = timeMetrics?.responseTimeImprovement || 0;
  const emailsProcessedAutomatically = insights?.emailsProcessedAutomatically || 0;
  const aiAccuracy = aiMetrics?.overallAccuracy || 0;

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <header className="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-gray-800">Productivity Insights</h1>
            <p className="text-sm text-gray-600">Track your email productivity and AI performance</p>
          </div>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto bg-gray-50 p-6">
        <div className="max-w-6xl mx-auto space-y-6">
          
          {/* Key Metrics Overview */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Time Saved This Week</p>
                    <p className="text-2xl font-bold text-green-600">{timeSavedWeekly}h</p>
                  </div>
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <Clock className="w-6 h-6 text-green-600" />
                  </div>
                </div>
                <div className="mt-4 flex items-center text-sm">
                  <TrendingUp className="w-4 h-4 text-green-500 mr-1" />
                  <span className="text-green-600">+15% from last week</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Response Time</p>
                    <p className="text-2xl font-bold text-blue-600">{responseTimeImprovement}%</p>
                  </div>
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Zap className="w-6 h-6 text-blue-600" />
                  </div>
                </div>
                <div className="mt-4 flex items-center text-sm">
                  <span className="text-gray-600">Faster than before</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Auto-Processed</p>
                    <p className="text-2xl font-bold text-purple-600">{emailsProcessedAutomatically}</p>
                  </div>
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                    <Mail className="w-6 h-6 text-purple-600" />
                  </div>
                </div>
                <div className="mt-4 flex items-center text-sm">
                  <span className="text-gray-600">Emails this month</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">AI Accuracy</p>
                    <p className="text-2xl font-bold text-orange-600">{aiAccuracy}%</p>
                  </div>
                  <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                    <Target className="w-6 h-6 text-orange-600" />
                  </div>
                </div>
                <div className="mt-4 flex items-center text-sm">
                  <CheckCircle className="w-4 h-4 text-green-500 mr-1" />
                  <span className="text-green-600">Excellent performance</span>
                </div>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="overview" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="ai-performance">AI Performance</TabsTrigger>
              <TabsTrigger value="time-analysis">Time Analysis</TabsTrigger>
              <TabsTrigger value="trends">Trends</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              <div className="grid lg:grid-cols-2 gap-6">
                {/* Weekly Summary */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <BarChart3 className="w-5 h-5" />
                      Weekly Summary
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Emails Processed</span>
                        <span className="font-medium">847</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Drafts Generated</span>
                        <span className="font-medium">234</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Calendar Events Created</span>
                        <span className="font-medium">18</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Rules Triggered</span>
                        <span className="font-medium">456</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Top Productivity Gains */}
                <Card>
                  <CardHeader>
                    <CardTitle>Top Productivity Gains</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Brain className="w-4 h-4 text-blue-500" />
                          <span className="text-sm">AI Draft Generation</span>
                        </div>
                        <span className="text-sm font-medium text-green-600">8.5h saved</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Mail className="w-4 h-4 text-purple-500" />
                          <span className="text-sm">Auto Classification</span>
                        </div>
                        <span className="text-sm font-medium text-green-600">3.2h saved</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-orange-500" />
                          <span className="text-sm">Calendar Integration</span>
                        </div>
                        <span className="text-sm font-medium text-green-600">1.8h saved</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Daily Breakdown */}
              <Card>
                <CardHeader>
                  <CardTitle>Daily Email Volume</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-7 gap-4">
                    {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, index) => {
                      const volume = [45, 67, 89, 52, 78, 23, 12][index];
                      const maxVolume = 89;
                      const height = (volume / maxVolume) * 100;
                      
                      return (
                        <div key={day} className="text-center">
                          <div className="h-24 flex items-end justify-center mb-2">
                            <div 
                              className="w-8 bg-blue-500 rounded-t" 
                              style={{ height: `${height}%` }}
                            ></div>
                          </div>
                          <div className="text-xs text-gray-600">{day}</div>
                          <div className="text-xs font-medium">{volume}</div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="ai-performance" className="space-y-6">
              <div className="grid lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>AI Provider Performance</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {[
                        { name: 'OpenAI GPT-4', accuracy: 94, usage: 45 },
                        { name: 'Anthropic Claude', accuracy: 91, usage: 35 },
                        { name: 'Google Gemini', accuracy: 88, usage: 20 }
                      ].map((provider, index) => (
                        <div key={index} className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium">{provider.name}</span>
                            <span className="text-sm text-gray-600">{provider.accuracy}%</span>
                          </div>
                          <Progress value={provider.accuracy} className="h-2" />
                          <div className="text-xs text-gray-500">{provider.usage}% usage this month</div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Classification Accuracy</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {[
                        { category: 'High Priority', accuracy: 96, count: 156 },
                        { category: 'Meeting Requests', accuracy: 92, count: 89 },
                        { category: 'Customer Support', accuracy: 88, count: 234 },
                        { category: 'Newsletters', accuracy: 98, count: 345 }
                      ].map((cat, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <div>
                            <div className="text-sm font-medium">{cat.category}</div>
                            <div className="text-xs text-gray-500">{cat.count} emails</div>
                          </div>
                          <Badge variant={cat.accuracy >= 95 ? "default" : cat.accuracy >= 90 ? "secondary" : "outline"}>
                            {cat.accuracy}%
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="time-analysis" className="space-y-6">
              <div className="grid lg:grid-cols-3 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Average Response Time</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-blue-600">2.4h</div>
                      <div className="text-sm text-gray-600 mt-1">Down from 5.1h</div>
                      <div className="mt-4">
                        <Badge variant="default" className="bg-green-100 text-green-800">
                          53% improvement
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Peak Activity Hours</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">9:00 AM - 10:00 AM</span>
                        <Badge>Peak</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">2:00 PM - 3:00 PM</span>
                        <Badge variant="secondary">High</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">4:00 PM - 5:00 PM</span>
                        <Badge variant="secondary">High</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Time Distribution</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Reading</span>
                        <span className="text-sm font-medium">35%</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Writing</span>
                        <span className="text-sm font-medium">25%</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Organizing</span>
                        <span className="text-sm font-medium">20%</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Automated</span>
                        <span className="text-sm font-medium text-green-600">20%</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="trends" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>30-Day Trend Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid lg:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h4 className="font-medium text-gray-900">Positive Trends</h4>
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <TrendingUp className="w-4 h-4 text-green-500" />
                          <span className="text-sm">AI accuracy improved by 8%</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <TrendingUp className="w-4 h-4 text-green-500" />
                          <span className="text-sm">Response time decreased by 45%</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <TrendingUp className="w-4 h-4 text-green-500" />
                          <span className="text-sm">Automation rate increased to 68%</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <h4 className="font-medium text-gray-900">Areas for Improvement</h4>
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <AlertTriangle className="w-4 h-4 text-yellow-500" />
                          <span className="text-sm">Calendar integration usage is low</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <AlertTriangle className="w-4 h-4 text-yellow-500" />
                          <span className="text-sm">Some classification rules need refinement</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
}