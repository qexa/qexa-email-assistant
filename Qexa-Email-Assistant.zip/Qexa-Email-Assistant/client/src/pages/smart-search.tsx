import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Search, Brain, Clock, User, Calendar, Mail, Sparkles } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

export default function SmartSearch() {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    try {
      const results = await apiRequest("POST", "/api/emails/smart-search", {
        query: searchQuery,
        includeContext: true,
        analyzeSentiment: true
      });
      setSearchResults(results);
    } catch (error) {
      console.error("Search failed:", error);
    } finally {
      setIsSearching(false);
    }
  };

  const quickSearches = [
    { label: "Urgent emails from last week", icon: Clock },
    { label: "Meetings scheduled for next month", icon: Calendar },
    { label: "Positive feedback from customers", icon: Sparkles },
    { label: "Invoices waiting for approval", icon: Mail },
    { label: "Team discussions about project X", icon: User }
  ];

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric"
    });
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <header className="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-gray-800">Smart Email Search</h1>
            <p className="text-sm text-gray-600">Search your emails using natural language powered by AI</p>
          </div>
        </div>
      </header>

      <main className="flex-1 overflow-y-auto bg-gray-50 p-6">
        <div className="max-w-4xl mx-auto space-y-6">
          
          {/* Search Interface */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="w-5 h-5 text-blue-600" />
                AI-Powered Email Search
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-3">
                <div className="flex-1">
                  <Input
                    placeholder="Ask anything about your emails... (e.g., 'Show me urgent emails from John about the project')"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && handleSearch()}
                    className="text-base"
                  />
                </div>
                <Button onClick={handleSearch} disabled={isSearching || !searchQuery.trim()}>
                  <Search className="w-4 h-4 mr-2" />
                  {isSearching ? "Searching..." : "Search"}
                </Button>
              </div>
              
              {/* Quick Search Suggestions */}
              <div className="mt-4">
                <p className="text-sm text-gray-600 mb-3">Try these quick searches:</p>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                  {quickSearches.map((search, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      size="sm"
                      className="justify-start h-auto py-2 text-left"
                      onClick={() => setSearchQuery(search.label)}
                    >
                      <search.icon className="w-4 h-4 mr-2 shrink-0" />
                      <span className="text-xs">{search.label}</span>
                    </Button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Search Results */}
          {searchResults.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Search Results ({searchResults.length})</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {searchResults.map((email, index) => (
                    <div key={index} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-medium text-gray-900 line-clamp-1">{email.subject}</h3>
                            {email.priority && (
                              <Badge variant={email.priority === 'high' ? 'destructive' : email.priority === 'medium' ? 'default' : 'secondary'}>
                                {email.priority}
                              </Badge>
                            )}
                          </div>
                          <div className="flex items-center gap-4 text-sm text-gray-600">
                            <div className="flex items-center gap-1">
                              <User className="w-3 h-3" />
                              {email.sender}
                            </div>
                            <div className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {formatDate(email.receivedAt)}
                            </div>
                          </div>
                        </div>
                        {email.sentiment && (
                          <Badge variant="outline" className="ml-4">
                            {email.sentiment}
                          </Badge>
                        )}
                      </div>
                      
                      {email.aiSummary && (
                        <div className="bg-blue-50 rounded p-3 mb-3">
                          <div className="flex items-center gap-2 mb-1">
                            <Sparkles className="w-4 h-4 text-blue-600" />
                            <span className="text-sm font-medium text-blue-900">AI Summary</span>
                          </div>
                          <p className="text-sm text-blue-800">{email.aiSummary}</p>
                        </div>
                      )}
                      
                      <p className="text-gray-700 line-clamp-2">{email.body}</p>
                      
                      {email.extractedData && Object.keys(email.extractedData).length > 0 && (
                        <div className="mt-3 pt-3 border-t">
                          <p className="text-xs text-gray-500 mb-2">Extracted Information:</p>
                          <div className="flex flex-wrap gap-2">
                            {Object.entries(email.extractedData).map(([key, value], i) => (
                              <Badge key={i} variant="secondary" className="text-xs">
                                {key}: {String(value)}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* No Results */}
          {searchResults.length === 0 && searchQuery && !isSearching && (
            <Card>
              <CardContent className="text-center py-8">
                <Search className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No results found</h3>
                <p className="text-gray-600">Try rephrasing your search or using different keywords.</p>
              </CardContent>
            </Card>
          )}

          {/* Search Tips */}
          <Card>
            <CardHeader>
              <CardTitle>Search Tips & Examples</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium text-gray-900 mb-3">Natural Language Queries</h4>
                  <div className="space-y-2 text-sm">
                    <div className="bg-gray-50 p-2 rounded">
                      "Emails from Sarah about the budget"
                    </div>
                    <div className="bg-gray-50 p-2 rounded">
                      "Urgent messages from last month"
                    </div>
                    <div className="bg-gray-50 p-2 rounded">
                      "Meeting requests for next week"
                    </div>
                  </div>
                </div>
                <div>
                  <h4 className="font-medium text-gray-900 mb-3">Advanced Features</h4>
                  <ul className="space-y-1 text-sm text-gray-600">
                    <li>• Sentiment analysis on email tone</li>
                    <li>• Automatic data extraction</li>
                    <li>• Context-aware summaries</li>
                    <li>• Priority-based filtering</li>
                    <li>• Date range understanding</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}