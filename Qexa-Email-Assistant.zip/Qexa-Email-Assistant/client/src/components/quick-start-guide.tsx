import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  BookOpen, 
  Mail, 
  Brain, 
  Settings, 
  BarChart3, 
  CheckCircle, 
  ArrowRight,
  ExternalLink
} from "lucide-react";
import { Link } from "wouter";

export default function QuickStartGuide() {
  const quickSteps = [
    {
      step: "1",
      title: "Connect Email Accounts",
      description: "Add Gmail, Outlook, or IMAP accounts to start monitoring",
      icon: Mail,
      link: "/email-accounts",
      status: "required"
    },
    {
      step: "2",
      title: "Create Classification Rules",
      description: "Set up rules to automatically sort and handle your emails",
      icon: Brain,
      link: "/classification-rules", 
      status: "required"
    },
    {
      step: "3",
      title: "Configure AI Settings",
      description: "Choose AI providers and set automation preferences",
      icon: Settings,
      link: "/settings",
      status: "recommended"
    },
    {
      step: "4",
      title: "Monitor Analytics",
      description: "Track performance and optimize your email workflow",
      icon: BarChart3,
      link: "/analytics",
      status: "optional"
    }
  ];

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <CardTitle>Quick Start Guide</CardTitle>
              <p className="text-sm text-gray-600">Get up and running in 4 easy steps</p>
            </div>
          </div>
          <Link href="/user-guide">
            <Button variant="outline" size="sm">
              <BookOpen className="w-4 h-4 mr-2" />
              Full Guide
              <ExternalLink className="w-4 h-4 ml-2" />
            </Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {quickSteps.map((step, index) => (
            <div key={index} className="flex items-center gap-4 p-4 rounded-lg border border-gray-200 hover:border-gray-300 transition-colors">
              <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-semibold text-sm shrink-0">
                {step.step}
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <step.icon className="w-4 h-4 text-gray-600" />
                  <h4 className="font-medium text-gray-900">{step.title}</h4>
                  <Badge 
                    variant={step.status === 'required' ? 'destructive' : step.status === 'recommended' ? 'default' : 'secondary'}
                    className="text-xs"
                  >
                    {step.status}
                  </Badge>
                </div>
                <p className="text-sm text-gray-600">{step.description}</p>
              </div>
              
              <Link href={step.link}>
                <Button variant="ghost" size="sm">
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
            </div>
          ))}
        </div>
        
        <div className="mt-6 p-4 bg-green-50 rounded-lg border border-green-200">
          <div className="flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 shrink-0" />
            <div>
              <h4 className="font-medium text-green-900 mb-1">Pro Tip</h4>
              <p className="text-sm text-green-700">
                Start with one email account and simple rules. Once you see how it works, you can add more accounts and create sophisticated automation workflows.
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}