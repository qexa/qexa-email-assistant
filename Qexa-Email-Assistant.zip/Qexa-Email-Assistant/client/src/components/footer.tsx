import { ExternalLink } from "lucide-react";
import qexaLogo from "@assets/2024-09-18_20-29-24_1752796955274.jpg";

export default function Footer() {
  return (
    <footer className="border-t border-gray-200 bg-white/50 backdrop-blur supports-[backdrop-filter]:bg-white/50 px-6 py-3">
      <div className="flex items-center justify-center">
        <div className="flex items-center gap-2 text-sm text-gray-500">
          <span>Powered by</span>
          <a 
            href="https://qexa.com" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center gap-2 text-blue-600 hover:text-blue-700 transition-colors font-medium"
          >
            <img 
              src={qexaLogo} 
              alt="Qexa Logo" 
              className="w-5 h-5 object-contain"
            />
            Qexa.com
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>
    </footer>
  );
}