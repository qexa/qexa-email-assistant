import {
  emailAccounts,
  classificationRules,
  emails,
  drafts,
  calendarEvents,
  aiProviders,
  systemSettings,
  userProfiles,
  onboardingSteps,
  onboardingInsights,
  vipContacts,
  emailThreads,
  type EmailAccount,
  type InsertEmailAccount,
  type ClassificationRule,
  type InsertClassificationRule,
  type Email,
  type InsertEmail,
  type Draft,
  type InsertDraft,
  type CalendarEvent,
  type InsertCalendarEvent,
  type AiProvider,
  type InsertAiProvider,
  type SystemSetting,
  type InsertSystemSetting,
  type UserProfile,
  type InsertUserProfile,
  type OnboardingStep,
  type InsertOnboardingStep,
  type OnboardingInsight,
  type InsertOnboardingInsight,
  type VipContact,
  type InsertVipContact,
  type EmailThread,
  type InsertEmailThread,
} from "@shared/schema";

export interface IStorage {
  // Email Accounts
  getEmailAccounts(): Promise<EmailAccount[]>;
  getEmailAccount(id: number): Promise<EmailAccount | undefined>;
  createEmailAccount(account: InsertEmailAccount): Promise<EmailAccount>;
  updateEmailAccount(id: number, account: Partial<InsertEmailAccount>): Promise<EmailAccount>;
  deleteEmailAccount(id: number): Promise<void>;

  // Classification Rules
  getClassificationRules(): Promise<ClassificationRule[]>;
  getClassificationRule(id: number): Promise<ClassificationRule | undefined>;
  createClassificationRule(rule: InsertClassificationRule): Promise<ClassificationRule>;
  updateClassificationRule(id: number, rule: Partial<InsertClassificationRule>): Promise<ClassificationRule>;
  deleteClassificationRule(id: number): Promise<void>;

  // Emails
  getEmails(limit?: number, offset?: number): Promise<Email[]>;
  getEmail(id: string): Promise<Email | undefined>;
  getEmailsByAccount(accountId: number): Promise<Email[]>;
  getEmailsBySender(sender: string, limit?: number): Promise<Email[]>;
  createEmail(email: InsertEmail): Promise<Email>;
  updateEmail(id: string, email: Partial<InsertEmail>): Promise<Email>;
  getRecentEmails(limit?: number): Promise<Email[]>;
  getEmailStats(): Promise<{
    totalEmails: number;
    processedToday: number;
    highPriority: number;
    mediumPriority: number;
    lowPriority: number;
  }>;

  // Drafts
  getDrafts(limit?: number, offset?: number): Promise<Draft[]>;
  getDraft(id: number): Promise<Draft | undefined>;
  getDraftsByEmail(emailId: string): Promise<Draft[]>;
  createDraft(draft: InsertDraft): Promise<Draft>;
  updateDraft(id: number, draft: Partial<InsertDraft>): Promise<Draft>;
  deleteDraft(id: number): Promise<void>;
  getPendingDrafts(): Promise<Draft[]>;

  // Calendar Events
  getCalendarEvents(): Promise<CalendarEvent[]>;
  getCalendarEvent(id: number): Promise<CalendarEvent | undefined>;
  createCalendarEvent(event: InsertCalendarEvent): Promise<CalendarEvent>;
  updateCalendarEvent(id: number, event: Partial<InsertCalendarEvent>): Promise<CalendarEvent>;
  deleteCalendarEvent(id: number): Promise<void>;
  getRecentCalendarEvents(limit?: number): Promise<CalendarEvent[]>;

  // AI Providers
  getAiProviders(): Promise<AiProvider[]>;
  getAiProvider(id: number): Promise<AiProvider | undefined>;
  getAiProviderByName(name: string): Promise<AiProvider | undefined>;
  createAiProvider(provider: InsertAiProvider): Promise<AiProvider>;
  updateAiProvider(id: number, provider: Partial<InsertAiProvider>): Promise<AiProvider>;
  deleteAiProvider(id: number): Promise<void>;

  // System Settings
  getSystemSettings(): Promise<SystemSetting[]>;
  getSystemSetting(key: string): Promise<SystemSetting | undefined>;
  createSystemSetting(setting: InsertSystemSetting): Promise<SystemSetting>;
  updateSystemSetting(key: string, value: string): Promise<SystemSetting>;
  deleteSystemSetting(key: string): Promise<void>;

  // User Profiles & Onboarding
  getUserProfile(): Promise<UserProfile | undefined>;
  createUserProfile(profile: InsertUserProfile): Promise<UserProfile>;
  updateUserProfile(id: number, profile: Partial<InsertUserProfile>): Promise<UserProfile>;
  getOnboardingSteps(userId: number): Promise<OnboardingStep[]>;
  createOnboardingStep(step: InsertOnboardingStep): Promise<OnboardingStep>;
  updateOnboardingStep(id: number, step: Partial<InsertOnboardingStep>): Promise<OnboardingStep>;
  getOnboardingInsights(userId: number): Promise<OnboardingInsight[]>;
  createOnboardingInsight(insight: InsertOnboardingInsight): Promise<OnboardingInsight>;
  getOnboardingProgress(userId: number): Promise<{
    totalSteps: number;
    completedSteps: number;
    currentStep: OnboardingStep | null;
    progress: number;
  }>;

  // VIP Contacts
  getVipContacts(): Promise<VipContact[]>;
  getVipContact(id: number): Promise<VipContact | undefined>;
  getVipContactByEmail(email: string): Promise<VipContact | undefined>;
  createVipContact(contact: InsertVipContact): Promise<VipContact>;
  updateVipContact(id: number, contact: Partial<InsertVipContact>): Promise<VipContact>;
  deleteVipContact(id: number): Promise<void>;

  // Email Threads
  getEmailThreads(): Promise<EmailThread[]>;
  getEmailThread(id: number): Promise<EmailThread | undefined>;
  getEmailThreadByMessageId(messageId: string): Promise<EmailThread | undefined>;
  createEmailThread(thread: InsertEmailThread): Promise<EmailThread>;
  updateEmailThread(id: number, thread: Partial<InsertEmailThread>): Promise<EmailThread>;
}

export class MemStorage implements IStorage {
  private emailAccounts: Map<number, EmailAccount> = new Map();
  private classificationRules: Map<number, ClassificationRule> = new Map();
  private emails: Map<string, Email> = new Map();
  private drafts: Map<number, Draft> = new Map();
  private calendarEvents: Map<number, CalendarEvent> = new Map();
  private aiProviders: Map<number, AiProvider> = new Map();
  private systemSettings: Map<string, SystemSetting> = new Map();
  private userProfiles: Map<number, UserProfile> = new Map();
  private onboardingSteps: Map<number, OnboardingStep> = new Map();
  private onboardingInsights: Map<number, OnboardingInsight> = new Map();
  private vipContacts: Map<number, VipContact> = new Map();
  private emailThreads: Map<number, EmailThread> = new Map();

  private currentAccountId = 1;
  private currentRuleId = 1;
  private currentDraftId = 1;
  private currentEventId = 1;
  private currentProviderId = 1;
  private currentSettingId = 1;
  private currentProfileId = 1;
  private currentStepId = 1;
  private currentInsightId = 1;
  private currentVipContactId = 1;
  private currentThreadId = 1;

  constructor() {
    // Initialize with default AI providers
    this.initializeDefaults();
  }

  private initializeDefaults() {
    const defaultProviders: InsertAiProvider[] = [
      {
        name: "openai",
        apiKey: process.env.OPENAI_API_KEY || "",
        isActive: true,
        priority: 1,
        usageToday: 0,
        successRate: 100,
      },
      {
        name: "claude",
        apiKey: process.env.ANTHROPIC_API_KEY || "",
        isActive: true,
        priority: 2,
        usageToday: 0,
        successRate: 100,
      },
      {
        name: "gemini",
        apiKey: process.env.GEMINI_API_KEY || "",
        isActive: true,
        priority: 3,
        usageToday: 0,
        successRate: 100,
      },
    ];

    defaultProviders.forEach((provider) => {
      const id = this.currentProviderId++;
      this.aiProviders.set(id, { ...provider, id });
    });
  }

  // Email Accounts
  async getEmailAccounts(): Promise<EmailAccount[]> {
    return Array.from(this.emailAccounts.values());
  }

  async getEmailAccount(id: number): Promise<EmailAccount | undefined> {
    return this.emailAccounts.get(id);
  }

  async createEmailAccount(account: InsertEmailAccount): Promise<EmailAccount> {
    const id = this.currentAccountId++;
    const newAccount: EmailAccount = {
      ...account,
      id,
      createdAt: new Date(),
      lastSyncAt: null,
    };
    this.emailAccounts.set(id, newAccount);
    return newAccount;
  }

  async updateEmailAccount(id: number, account: Partial<InsertEmailAccount>): Promise<EmailAccount> {
    const existing = this.emailAccounts.get(id);
    if (!existing) throw new Error("Email account not found");

    const updated = { ...existing, ...account };
    this.emailAccounts.set(id, updated);
    return updated;
  }

  async deleteEmailAccount(id: number): Promise<void> {
    this.emailAccounts.delete(id);
  }

  // Classification Rules
  async getClassificationRules(): Promise<ClassificationRule[]> {
    return Array.from(this.classificationRules.values());
  }

  async getClassificationRule(id: number): Promise<ClassificationRule | undefined> {
    return this.classificationRules.get(id);
  }

  async createClassificationRule(rule: InsertClassificationRule): Promise<ClassificationRule> {
    const id = this.currentRuleId++;
    const newRule: ClassificationRule = {
      ...rule,
      id,
      createdAt: new Date(),
    };
    this.classificationRules.set(id, newRule);
    return newRule;
  }

  async updateClassificationRule(id: number, rule: Partial<InsertClassificationRule>): Promise<ClassificationRule> {
    const existing = this.classificationRules.get(id);
    if (!existing) throw new Error("Classification rule not found");

    const updated = { ...existing, ...rule };
    this.classificationRules.set(id, updated);
    return updated;
  }

  async deleteClassificationRule(id: number): Promise<void> {
    this.classificationRules.delete(id);
  }

  // Emails
  async getEmails(limit = 50, offset = 0): Promise<Email[]> {
    const emails = Array.from(this.emails.values())
      .sort((a, b) => b.receivedAt.getTime() - a.receivedAt.getTime())
      .slice(offset, offset + limit);
    return emails;
  }

  async getEmail(id: string): Promise<Email | undefined> {
    return this.emails.get(id);
  }

  async getEmailsByAccount(accountId: number): Promise<Email[]> {
    return Array.from(this.emails.values()).filter(email => email.accountId === accountId);
  }

  async getEmailsBySender(sender: string, limit = 10): Promise<Email[]> {
    return Array.from(this.emails.values())
      .filter(email => email.sender.toLowerCase().includes(sender.toLowerCase()))
      .sort((a, b) => b.receivedAt.getTime() - a.receivedAt.getTime())
      .slice(0, limit);
  }

  async createEmail(email: InsertEmail): Promise<Email> {
    const newEmail: Email = {
      ...email,
      createdAt: new Date(),
      processedAt: null,
    };
    this.emails.set(email.id, newEmail);
    return newEmail;
  }

  async updateEmail(id: string, email: Partial<InsertEmail>): Promise<Email> {
    const existing = this.emails.get(id);
    if (!existing) throw new Error("Email not found");

    const updated = { ...existing, ...email };
    this.emails.set(id, updated);
    return updated;
  }

  async getRecentEmails(limit = 10): Promise<Email[]> {
    return Array.from(this.emails.values())
      .sort((a, b) => b.receivedAt.getTime() - a.receivedAt.getTime())
      .slice(0, limit);
  }

  async getEmailStats(): Promise<{
    totalEmails: number;
    processedToday: number;
    highPriority: number;
    mediumPriority: number;
    lowPriority: number;
  }> {
    const emails = Array.from(this.emails.values());
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const processedToday = emails.filter(email => 
      email.processedAt && email.processedAt >= today
    ).length;

    return {
      totalEmails: emails.length,
      processedToday,
      highPriority: emails.filter(e => e.priority === 'high').length,
      mediumPriority: emails.filter(e => e.priority === 'medium').length,
      lowPriority: emails.filter(e => e.priority === 'low').length,
    };
  }

  // Drafts
  async getDrafts(limit = 50, offset = 0): Promise<Draft[]> {
    const drafts = Array.from(this.drafts.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(offset, offset + limit);
    return drafts;
  }

  async getDraft(id: number): Promise<Draft | undefined> {
    return this.drafts.get(id);
  }

  async getDraftsByEmail(emailId: string): Promise<Draft[]> {
    return Array.from(this.drafts.values()).filter(draft => draft.emailId === emailId);
  }

  async createDraft(draft: InsertDraft): Promise<Draft> {
    const id = this.currentDraftId++;
    const newDraft: Draft = {
      ...draft,
      id,
      createdAt: new Date(),
      reviewedAt: null,
    };
    this.drafts.set(id, newDraft);
    return newDraft;
  }

  async updateDraft(id: number, draft: Partial<InsertDraft>): Promise<Draft> {
    const existing = this.drafts.get(id);
    if (!existing) throw new Error("Draft not found");

    const updated = { ...existing, ...draft };
    this.drafts.set(id, updated);
    return updated;
  }

  async deleteDraft(id: number): Promise<void> {
    this.drafts.delete(id);
  }

  async getPendingDrafts(): Promise<Draft[]> {
    return Array.from(this.drafts.values()).filter(draft => draft.status === 'pending');
  }

  // Calendar Events
  async getCalendarEvents(): Promise<CalendarEvent[]> {
    return Array.from(this.calendarEvents.values());
  }

  async getCalendarEvent(id: number): Promise<CalendarEvent | undefined> {
    return this.calendarEvents.get(id);
  }

  async createCalendarEvent(event: InsertCalendarEvent): Promise<CalendarEvent> {
    const id = this.currentEventId++;
    const newEvent: CalendarEvent = {
      ...event,
      id,
      createdAt: new Date(),
    };
    this.calendarEvents.set(id, newEvent);
    return newEvent;
  }

  async updateCalendarEvent(id: number, event: Partial<InsertCalendarEvent>): Promise<CalendarEvent> {
    const existing = this.calendarEvents.get(id);
    if (!existing) throw new Error("Calendar event not found");

    const updated = { ...existing, ...event };
    this.calendarEvents.set(id, updated);
    return updated;
  }

  async deleteCalendarEvent(id: number): Promise<void> {
    this.calendarEvents.delete(id);
  }

  async getRecentCalendarEvents(limit = 10): Promise<CalendarEvent[]> {
    return Array.from(this.calendarEvents.values())
      .sort((a, b) => b.startTime.getTime() - a.startTime.getTime())
      .slice(0, limit);
  }

  // AI Providers
  async getAiProviders(): Promise<AiProvider[]> {
    return Array.from(this.aiProviders.values()).sort((a, b) => a.priority - b.priority);
  }

  async getAiProvider(id: number): Promise<AiProvider | undefined> {
    return this.aiProviders.get(id);
  }

  async getAiProviderByName(name: string): Promise<AiProvider | undefined> {
    return Array.from(this.aiProviders.values()).find(provider => provider.name === name);
  }

  async createAiProvider(provider: InsertAiProvider): Promise<AiProvider> {
    const id = this.currentProviderId++;
    const newProvider: AiProvider = {
      ...provider,
      id,
      createdAt: new Date(),
      lastUsedAt: null,
    };
    this.aiProviders.set(id, newProvider);
    return newProvider;
  }

  async updateAiProvider(id: number, provider: Partial<InsertAiProvider>): Promise<AiProvider> {
    const existing = this.aiProviders.get(id);
    if (!existing) throw new Error("AI provider not found");

    const updated = { ...existing, ...provider };
    this.aiProviders.set(id, updated);
    return updated;
  }

  async deleteAiProvider(id: number): Promise<void> {
    this.aiProviders.delete(id);
  }

  // System Settings
  async getSystemSettings(): Promise<SystemSetting[]> {
    return Array.from(this.systemSettings.values());
  }

  async getSystemSetting(key: string): Promise<SystemSetting | undefined> {
    return this.systemSettings.get(key);
  }

  async createSystemSetting(setting: InsertSystemSetting): Promise<SystemSetting> {
    const id = this.currentSettingId++;
    const newSetting: SystemSetting = {
      ...setting,
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.systemSettings.set(setting.key, newSetting);
    return newSetting;
  }

  async updateSystemSetting(key: string, value: string): Promise<SystemSetting> {
    const existing = this.systemSettings.get(key);
    if (!existing) {
      return this.createSystemSetting({ key, value });
    }

    const updated = { ...existing, value, updatedAt: new Date() };
    this.systemSettings.set(key, updated);
    return updated;
  }

  async deleteSystemSetting(key: string): Promise<void> {
    this.systemSettings.delete(key);
  }

  // User Profiles & Onboarding
  async getUserProfile(): Promise<UserProfile | undefined> {
    const profiles = Array.from(this.userProfiles.values());
    return profiles[0]; // Single user system for now
  }

  async createUserProfile(profile: InsertUserProfile): Promise<UserProfile> {
    const id = this.currentProfileId++;
    const newProfile: UserProfile = {
      ...profile,
      id,
      createdAt: new Date(),
      completedAt: null,
    };
    this.userProfiles.set(id, newProfile);
    return newProfile;
  }

  async updateUserProfile(id: number, profile: Partial<InsertUserProfile>): Promise<UserProfile> {
    const existing = this.userProfiles.get(id);
    if (!existing) {
      throw new Error(`User profile ${id} not found`);
    }
    const updated = { ...existing, ...profile };
    this.userProfiles.set(id, updated);
    return updated;
  }

  async getOnboardingSteps(userId: number): Promise<OnboardingStep[]> {
    return Array.from(this.onboardingSteps.values()).filter(step => step.userId === userId);
  }

  async createOnboardingStep(step: InsertOnboardingStep): Promise<OnboardingStep> {
    const id = this.currentStepId++;
    const newStep: OnboardingStep = {
      ...step,
      id,
      status: 'pending',
      createdAt: new Date(),
      completedAt: null,
    };
    this.onboardingSteps.set(id, newStep);
    return newStep;
  }

  async updateOnboardingStep(id: number, step: Partial<InsertOnboardingStep>): Promise<OnboardingStep> {
    const existing = this.onboardingSteps.get(id);
    if (!existing) {
      throw new Error(`Onboarding step ${id} not found`);
    }
    const updated = { ...existing, ...step };
    this.onboardingSteps.set(id, updated);
    return updated;
  }

  async getOnboardingInsights(userId: number): Promise<OnboardingInsight[]> {
    return Array.from(this.onboardingInsights.values()).filter(insight => insight.userId === userId);
  }

  async createOnboardingInsight(insight: InsertOnboardingInsight): Promise<OnboardingInsight> {
    const id = this.currentInsightId++;
    const newInsight: OnboardingInsight = {
      ...insight,
      id,
      createdAt: new Date(),
    };
    this.onboardingInsights.set(id, newInsight);
    return newInsight;
  }

  async getOnboardingProgress(userId: number): Promise<{
    totalSteps: number;
    completedSteps: number;
    currentStep: OnboardingStep | null;
    progress: number;
  }> {
    const steps = await this.getOnboardingSteps(userId);
    const totalSteps = steps.length;
    const completedSteps = steps.filter(s => s.status === 'completed').length;
    const currentStep = steps.find(s => s.status === 'in_progress') || 
                       steps.find(s => s.status === 'pending') || null;
    
    const progress = totalSteps > 0 ? Math.round((completedSteps / totalSteps) * 100) : 0;

    return {
      totalSteps,
      completedSteps,
      currentStep,
      progress
    };
  }

  // VIP Contacts
  async getVipContacts(): Promise<VipContact[]> {
    return Array.from(this.vipContacts.values()).filter(contact => contact.isActive);
  }

  async getVipContact(id: number): Promise<VipContact | undefined> {
    return this.vipContacts.get(id);
  }

  async getVipContactByEmail(email: string): Promise<VipContact | undefined> {
    return Array.from(this.vipContacts.values())
      .find(contact => contact.email.toLowerCase() === email.toLowerCase());
  }

  async createVipContact(contact: InsertVipContact): Promise<VipContact> {
    const id = this.currentVipContactId++;
    const newContact: VipContact = {
      ...contact,
      id,
      interactionCount: 0,
      isActive: true,
      createdAt: new Date(),
      lastInteraction: null,
    };
    this.vipContacts.set(id, newContact);
    return newContact;
  }

  async updateVipContact(id: number, contact: Partial<InsertVipContact>): Promise<VipContact> {
    const existing = this.vipContacts.get(id);
    if (!existing) throw new Error("VIP contact not found");

    const updated = { ...existing, ...contact };
    this.vipContacts.set(id, updated);
    return updated;
  }

  async deleteVipContact(id: number): Promise<void> {
    this.vipContacts.delete(id);
  }

  // Email Threads
  async getEmailThreads(): Promise<EmailThread[]> {
    return Array.from(this.emailThreads.values())
      .sort((a, b) => b.lastActivity.getTime() - a.lastActivity.getTime());
  }

  async getEmailThread(id: number): Promise<EmailThread | undefined> {
    return this.emailThreads.get(id);
  }

  async getEmailThreadByMessageId(messageId: string): Promise<EmailThread | undefined> {
    // This is a simplified implementation - in a real system, you'd track message to thread relationships
    return Array.from(this.emailThreads.values())
      .find(thread => thread.threadId === messageId);
  }

  async createEmailThread(thread: InsertEmailThread): Promise<EmailThread> {
    const id = this.currentThreadId++;
    const newThread: EmailThread = {
      ...thread,
      id,
      createdAt: new Date(),
    };
    this.emailThreads.set(id, newThread);
    return newThread;
  }

  async updateEmailThread(id: number, thread: Partial<InsertEmailThread>): Promise<EmailThread> {
    const existing = this.emailThreads.get(id);
    if (!existing) throw new Error("Email thread not found");

    const updated = { ...existing, ...thread };
    this.emailThreads.set(id, updated);
    return updated;
  }
}

export const storage = new MemStorage();
