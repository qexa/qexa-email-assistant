import { google } from 'googleapis';
import { storage } from "../storage";
import type { CalendarEvent, InsertCalendarEvent } from "@shared/schema";

export class CalendarIntegrationService {
  private calendar: any = null;

  async initialize() {
    try {
      // Initialize Google Calendar API
      const auth = new google.auth.GoogleAuth({
        keyFile: process.env.GOOGLE_SERVICE_ACCOUNT_KEY_FILE,
        scopes: ['https://www.googleapis.com/auth/calendar'],
      });

      this.calendar = google.calendar({ version: 'v3', auth });
    } catch (error) {
      console.error('Error initializing Google Calendar:', error);
    }
  }

  async createEvent(eventData: InsertCalendarEvent): Promise<CalendarEvent> {
    try {
      // Create event in our database first
      const localEvent = await storage.createCalendarEvent(eventData);

      // Create event in Google Calendar if API is available
      if (this.calendar) {
        const googleEvent = {
          summary: eventData.title,
          start: {
            dateTime: eventData.startTime.toISOString(),
            timeZone: 'UTC',
          },
          end: {
            dateTime: eventData.endTime.toISOString(),
            timeZone: 'UTC',
          },
          location: eventData.location || '',
          description: eventData.description || '',
          attendees: eventData.attendees?.map(email => ({ email })) || [],
        };

        const response = await this.calendar.events.insert({
          calendarId: 'primary',
          resource: googleEvent,
        });

        // Update local event with Google event ID
        await storage.updateCalendarEvent(localEvent.id, {
          googleEventId: response.data.id,
        });
      }

      return localEvent;
    } catch (error) {
      console.error('Error creating calendar event:', error);
      throw error;
    }
  }

  async updateEvent(eventId: number, updates: Partial<InsertCalendarEvent>): Promise<CalendarEvent> {
    const event = await storage.getCalendarEvent(eventId);
    if (!event) throw new Error('Event not found');

    // Update local event
    const updatedEvent = await storage.updateCalendarEvent(eventId, updates);

    // Update Google Calendar event if it exists
    if (this.calendar && event.googleEventId) {
      try {
        const googleEvent = {
          summary: updatedEvent.title,
          start: {
            dateTime: updatedEvent.startTime.toISOString(),
            timeZone: 'UTC',
          },
          end: {
            dateTime: updatedEvent.endTime.toISOString(),
            timeZone: 'UTC',
          },
          location: updatedEvent.location || '',
          description: updatedEvent.description || '',
          attendees: updatedEvent.attendees?.map(email => ({ email })) || [],
        };

        await this.calendar.events.update({
          calendarId: 'primary',
          eventId: event.googleEventId,
          resource: googleEvent,
        });
      } catch (error) {
        console.error('Error updating Google Calendar event:', error);
      }
    }

    return updatedEvent;
  }

  async deleteEvent(eventId: number): Promise<void> {
    const event = await storage.getCalendarEvent(eventId);
    if (!event) throw new Error('Event not found');

    // Delete from Google Calendar if it exists
    if (this.calendar && event.googleEventId) {
      try {
        await this.calendar.events.delete({
          calendarId: 'primary',
          eventId: event.googleEventId,
        });
      } catch (error) {
        console.error('Error deleting Google Calendar event:', error);
      }
    }

    // Delete from local database
    await storage.deleteCalendarEvent(eventId);
  }

  async getUpcomingEvents(maxResults = 10): Promise<CalendarEvent[]> {
    const events = await storage.getCalendarEvents();
    const now = new Date();
    
    return events
      .filter(event => event.startTime > now)
      .sort((a, b) => a.startTime.getTime() - b.startTime.getTime())
      .slice(0, maxResults);
  }

  async getRecentEvents(maxResults = 10): Promise<CalendarEvent[]> {
    return await storage.getRecentCalendarEvents(maxResults);
  }

  async syncWithGoogleCalendar(): Promise<void> {
    if (!this.calendar) return;

    try {
      // Get events from Google Calendar
      const response = await this.calendar.events.list({
        calendarId: 'primary',
        timeMin: new Date().toISOString(),
        maxResults: 100,
        singleEvents: true,
        orderBy: 'startTime',
      });

      const googleEvents = response.data.items || [];

      // Sync events that were created by our system
      for (const googleEvent of googleEvents) {
        const localEvent = await storage.getCalendarEvents().then(events => 
          events.find(e => e.googleEventId === googleEvent.id)
        );

        if (localEvent) {
          // Update local event if Google event was modified
          const googleStart = new Date(googleEvent.start?.dateTime || googleEvent.start?.date || '');
          const googleEnd = new Date(googleEvent.end?.dateTime || googleEvent.end?.date || '');

          await storage.updateCalendarEvent(localEvent.id, {
            title: googleEvent.summary || localEvent.title,
            startTime: googleStart,
            endTime: googleEnd,
            location: googleEvent.location || localEvent.location,
            description: googleEvent.description || localEvent.description,
          });
        }
      }
    } catch (error) {
      console.error('Error syncing with Google Calendar:', error);
    }
  }

  async getCalendarSettings() {
    const settings = await storage.getSystemSettings();
    return {
      autoCreateEvents: settings.find(s => s.key === 'auto_create_events')?.value === 'true',
      defaultDuration: parseInt(settings.find(s => s.key === 'default_duration')?.value || '60'),
      targetCalendar: settings.find(s => s.key === 'target_calendar')?.value || 'primary',
    };
  }

  async updateCalendarSettings(settings: {
    autoCreateEvents?: boolean;
    defaultDuration?: number;
    targetCalendar?: string;
  }) {
    if (settings.autoCreateEvents !== undefined) {
      await storage.updateSystemSetting('auto_create_events', settings.autoCreateEvents.toString());
    }
    if (settings.defaultDuration !== undefined) {
      await storage.updateSystemSetting('default_duration', settings.defaultDuration.toString());
    }
    if (settings.targetCalendar !== undefined) {
      await storage.updateSystemSetting('target_calendar', settings.targetCalendar);
    }
  }
}

export const calendarIntegration = new CalendarIntegrationService();
