import OpenAI from "openai";
import { storage } from "../storage";
import type { 
  UserProfile, 
  InsertUserProfile, 
  OnboardingStep, 
  InsertOnboardingStep,
  OnboardingInsight,
  InsertOnboardingInsight 
} from "@shared/schema";

const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY 
});

export class AIOnboardingService {
  
  async createPersonalizedOnboarding(profile: InsertUserProfile): Promise<UserProfile> {
    // Create user profile
    const userProfile = await storage.createUserProfile(profile);
    
    // Generate AI-powered onboarding steps based on user profile
    const personalizedSteps = await this.generatePersonalizedSteps(userProfile);
    
    // Create onboarding steps in database
    for (const step of personalizedSteps) {
      await storage.createOnboardingStep({
        userId: userProfile.id,
        stepType: step.stepType,
        status: 'pending',
        aiRecommendations: step.recommendations,
        userChoices: {}
      });
    }
    
    return userProfile;
  }

  private async generatePersonalizedSteps(profile: UserProfile): Promise<Array<{
    stepType: string;
    recommendations: any[];
  }>> {
    // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
    const prompt = `
    You are an expert email management consultant. Based on this user profile, create personalized onboarding recommendations:
    
    Role: ${profile.role}
    Email Volume: ${profile.emailVolume} 
    Priorities: ${JSON.stringify(profile.priorities)}
    Time Zone: ${profile.timeZone}
    Working Hours: ${JSON.stringify(profile.workingHours)}
    
    Generate specific, actionable recommendations for each onboarding step:
    1. Email Account Setup
    2. Classification Rules  
    3. AI Preferences
    4. Automation Settings
    
    Return recommendations as JSON with practical advice tailored to their role and needs.
    `;

    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
        max_tokens: 2000
      });

      const aiRecommendations = JSON.parse(response.choices[0].message.content || '{}');
      
      return [
        {
          stepType: 'email_accounts',
          recommendations: aiRecommendations.emailAccounts || []
        },
        {
          stepType: 'classification_rules', 
          recommendations: aiRecommendations.classificationRules || []
        },
        {
          stepType: 'ai_setup',
          recommendations: aiRecommendations.aiPreferences || []
        },
        {
          stepType: 'preferences',
          recommendations: aiRecommendations.automationSettings || []
        }
      ];
    } catch (error) {
      console.error('Error generating personalized steps:', error);
      return this.getDefaultSteps();
    }
  }

  private getDefaultSteps(): Array<{ stepType: string; recommendations: any[] }> {
    return [
      {
        stepType: 'email_accounts',
        recommendations: [
          { type: 'suggestion', text: 'Start with your primary work email account' },
          { type: 'tip', text: 'Gmail integration provides the smoothest setup experience' }
        ]
      },
      {
        stepType: 'classification_rules',
        recommendations: [
          { type: 'suggestion', text: 'Create rules for high-priority senders first' },
          { type: 'tip', text: 'Use specific keywords to avoid false matches' }
        ]
      },
      {
        stepType: 'ai_setup',
        recommendations: [
          { type: 'suggestion', text: 'Enable moderate AI assistance for balanced automation' },
          { type: 'tip', text: 'Review AI drafts initially to improve accuracy' }
        ]
      },
      {
        stepType: 'preferences',
        recommendations: [
          { type: 'suggestion', text: 'Set up working hours to avoid after-hours processing' },
          { type: 'tip', text: 'Enable draft approval for important emails' }
        ]
      }
    ];
  }

  async analyzeEmailPatterns(emailSamples: Array<{
    subject: string;
    sender: string;
    body: string;
  }>): Promise<OnboardingInsight[]> {
    if (emailSamples.length === 0) return [];

    const prompt = `
    Analyze these email samples and provide insights for setting up classification rules:
    
    ${emailSamples.map((email, i) => `
    Email ${i + 1}:
    From: ${email.sender}
    Subject: ${email.subject}
    Body: ${email.body.substring(0, 500)}
    `).join('\n')}
    
    Provide JSON response with:
    - priority_senders: Important email addresses to prioritize
    - common_keywords: Recurring terms for classification rules
    - suggested_rules: Specific rule recommendations
    - automation_opportunities: Areas where AI can help most
    
    Focus on practical, actionable insights.
    `;

    try {
      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      const response = await openai.chat.completions.create({
        model: "gpt-4o", 
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
        max_tokens: 1500
      });

      const analysis = JSON.parse(response.choices[0].message.content || '{}');
      
      return [
        {
          userId: 1, // Will be set by caller
          analysisType: 'email_patterns',
          insights: analysis,
          confidence: 85,
          applied: false
        }
      ];
    } catch (error) {
      console.error('Error analyzing email patterns:', error);
      return [];
    }
  }

  async generateSmartRuleSuggestions(
    profile: UserProfile, 
    emailAnalysis: OnboardingInsight[]
  ): Promise<Array<{
    name: string;
    priority: string;
    keywords: string[];
    senderPatterns: string[];
    actions: any;
    explanation: string;
  }>> {
    const analysisData = emailAnalysis.find(a => a.analysisType === 'email_patterns');
    
    const prompt = `
    Based on this user profile and email analysis, suggest 3-5 smart classification rules:
    
    User Role: ${profile.role}
    Email Volume: ${profile.emailVolume}
    Priorities: ${JSON.stringify(profile.priorities)}
    
    Email Analysis: ${JSON.stringify(analysisData?.insights || {})}
    
    Create practical classification rules with:
    - name: Descriptive rule name
    - priority: high/medium/low
    - keywords: Array of relevant keywords
    - senderPatterns: Array of email patterns
    - actions: { createDraft: boolean, createCalendar: boolean, flag: boolean }
    - explanation: Why this rule helps the user
    
    Return as JSON array of rule objects.
    `;

    try {
      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [{ role: "user", content: prompt }],
        response_format: { type: "json_object" },
        max_tokens: 1500
      });

      const suggestions = JSON.parse(response.choices[0].message.content || '{}');
      return suggestions.rules || [];
    } catch (error) {
      console.error('Error generating rule suggestions:', error);
      return this.getDefaultRuleSuggestions(profile.role || 'other');
    }
  }

  private getDefaultRuleSuggestions(role: string): Array<any> {
    const roleBasedRules: Record<string, Array<any>> = {
      executive: [
        {
          name: "C-Level Communications",
          priority: "high",
          keywords: ["urgent", "board", "executive", "strategy"],
          senderPatterns: ["*@company.com"],
          actions: { createDraft: true, flag: true },
          explanation: "Prioritizes executive-level communications"
        }
      ],
      manager: [
        {
          name: "Team Updates",
          priority: "medium", 
          keywords: ["team", "project", "deadline", "status"],
          senderPatterns: ["*@company.com"],
          actions: { createDraft: true, createCalendar: false },
          explanation: "Handles team communication efficiently"
        }
      ],
      sales: [
        {
          name: "Hot Leads",
          priority: "high",
          keywords: ["interested", "purchase", "quote", "pricing"],
          senderPatterns: [],
          actions: { createDraft: true, flag: true },
          explanation: "Fast response to potential customers"
        }
      ]
    };

    return roleBasedRules[role] || roleBasedRules.manager;
  }

  async getOnboardingProgress(userId: number): Promise<{
    totalSteps: number;
    completedSteps: number;
    currentStep: OnboardingStep | null;
    progress: number;
    nextRecommendations: any[];
  }> {
    const steps = await storage.getOnboardingSteps(userId);
    const totalSteps = steps.length;
    const completedSteps = steps.filter(s => s.status === 'completed').length;
    const currentStep = steps.find(s => s.status === 'in_progress') || 
                       steps.find(s => s.status === 'pending') || null;
    
    const progress = totalSteps > 0 ? Math.round((completedSteps / totalSteps) * 100) : 0;
    
    const nextRecommendations = currentStep?.aiRecommendations || [];

    return {
      totalSteps,
      completedSteps, 
      currentStep,
      progress,
      nextRecommendations
    };
  }

  async completeOnboardingStep(
    userId: number, 
    stepType: string, 
    userChoices: any
  ): Promise<OnboardingStep> {
    const steps = await storage.getOnboardingSteps(userId);
    const step = steps.find(s => s.stepType === stepType);
    
    if (!step) {
      throw new Error(`Onboarding step ${stepType} not found`);
    }

    return await storage.updateOnboardingStep(step.id, {
      status: 'completed',
      userChoices,
      completedAt: new Date()
    });
  }
}

export const aiOnboardingService = new AIOnboardingService();