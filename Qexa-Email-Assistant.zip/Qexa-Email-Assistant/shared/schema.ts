import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const emailAccounts = pgTable("email_accounts", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  provider: text("provider").notNull(), // 'gmail', 'outlook', 'imap'
  accessToken: text("access_token"),
  refreshToken: text("refresh_token"),
  imapConfig: json("imap_config"), // For IMAP accounts
  isActive: boolean("is_active").default(true),
  lastSyncAt: timestamp("last_sync_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const classificationRules = pgTable("classification_rules", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  priority: text("priority").notNull(), // 'high', 'medium', 'low'
  keywords: json("keywords").$type<string[]>().default([]),
  senderPatterns: json("sender_patterns").$type<string[]>().default([]),
  actions: json("actions").$type<{
    flag?: boolean;
    createDraft?: boolean;
    createCalendar?: boolean;
    moveFolder?: string;
  }>().default({}),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const emails = pgTable("emails", {
  id: text("id").primaryKey(), // Email ID from provider
  accountId: integer("account_id").references(() => emailAccounts.id).notNull(),
  messageId: text("message_id").notNull(),
  subject: text("subject").notNull(),
  sender: text("sender").notNull(),
  body: text("body"),
  receivedAt: timestamp("received_at").notNull(),
  category: text("category"), // Classification result
  priority: text("priority"), // 'high', 'medium', 'low'
  urgencyScore: integer("urgency_score"), // 0-100 AI-calculated urgency
  executivePriority: boolean("executive_priority").default(false), // VIP/executive flag
  sentiment: text("sentiment"), // 'positive', 'negative', 'neutral'
  actionRequired: boolean("action_required").default(false),
  deadline: timestamp("deadline"), // Extracted deadline if any
  estimatedResponseTime: integer("estimated_response_time"), // Minutes to respond
  ruleId: integer("rule_id").references(() => classificationRules.id),
  processed: boolean("processed").default(false),
  processedAt: timestamp("processed_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const drafts = pgTable("drafts", {
  id: serial("id").primaryKey(),
  emailId: text("email_id").references(() => emails.id).notNull(),
  subject: text("subject").notNull(),
  content: text("content").notNull(),
  aiProvider: text("ai_provider").notNull(), // 'openai', 'claude', 'gemini'
  status: text("status").default("pending"), // 'pending', 'approved', 'rejected', 'edited'
  confidence: integer("confidence"), // 0-100
  tone: text("tone").default("professional"), // 'professional', 'casual', 'formal', 'urgent'
  responseType: text("response_type"), // 'acknowledgment', 'detailed_response', 'request_info', 'decline'
  contextUsed: json("context_used").$type<{
    previousEmails?: boolean;
    relationshipHistory?: boolean;
    urgencyLevel?: string;
    detectedIntent?: string;
  }>().default({}),
  alternatives: json("alternatives").$type<Array<{
    tone: string;
    content: string;
    confidence: number;
  }>>().default([]),
  createdAt: timestamp("created_at").defaultNow(),
  reviewedAt: timestamp("reviewed_at"),
});

export const calendarEvents = pgTable("calendar_events", {
  id: serial("id").primaryKey(),
  emailId: text("email_id").references(() => emails.id).notNull(),
  googleEventId: text("google_event_id").unique(),
  title: text("title").notNull(),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time").notNull(),
  location: text("location"),
  description: text("description"),
  attendees: json("attendees").$type<string[]>().default([]),
  createdAt: timestamp("created_at").defaultNow(),
});

export const aiProviders = pgTable("ai_providers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(), // 'openai', 'claude', 'gemini'
  apiKey: text("api_key"),
  isActive: boolean("is_active").default(true),
  priority: integer("priority").default(0), // Lower number = higher priority
  usageToday: integer("usage_today").default(0),
  successRate: integer("success_rate").default(100), // 0-100
  lastUsedAt: timestamp("last_used_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const systemSettings = pgTable("system_settings", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  value: text("value"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const userProfiles = pgTable("user_profiles", {
  id: serial("id").primaryKey(),
  name: text("name"),
  email: text("email").unique(),
  role: text("role"), // 'executive', 'manager', 'developer', 'sales', 'support', 'other'
  emailVolume: text("email_volume"), // 'low', 'medium', 'high'
  priorities: json("priorities").$type<string[]>().default([]), // ['productivity', 'automation', 'analytics', 'collaboration']
  timeZone: text("time_zone"),
  workingHours: json("working_hours").$type<{start: string, end: string}>(),
  preferences: json("preferences").$type<{
    aiAssistance: 'minimal' | 'moderate' | 'aggressive';
    notificationFrequency: 'real-time' | 'hourly' | 'daily';
    autoActions: boolean;
    draftApprovalRequired: boolean;
  }>(),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const onboardingSteps = pgTable("onboarding_steps", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => userProfiles.id).notNull(),
  stepType: text("step_type").notNull(), // 'profile', 'email_accounts', 'classification_rules', 'ai_setup', 'preferences'
  status: text("status").default("pending"), // 'pending', 'in_progress', 'completed', 'skipped'
  aiRecommendations: json("ai_recommendations").$type<any[]>().default([]),
  userChoices: json("user_choices").$type<any>().default({}),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const onboardingInsights = pgTable("onboarding_insights", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => userProfiles.id).notNull(),
  analysisType: text("analysis_type").notNull(), // 'email_patterns', 'sender_analysis', 'priority_suggestions'
  insights: json("insights").$type<any>().default({}),
  confidence: integer("confidence"), // 0-100
  applied: boolean("applied").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

export const vipContacts = pgTable("vip_contacts", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  name: text("name"),
  company: text("company"),
  title: text("title"),
  relationship: text("relationship"), // 'client', 'partner', 'executive', 'board_member'
  priorityLevel: integer("priority_level").default(1), // 1-5 scale
  communicationStyle: text("communication_style"), // 'formal', 'casual', 'direct'
  preferredResponseTime: integer("preferred_response_time"), // Hours
  lastInteraction: timestamp("last_interaction"),
  interactionCount: integer("interaction_count").default(0),
  notes: text("notes"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

export const emailThreads = pgTable("email_threads", {
  id: serial("id").primaryKey(),
  threadId: text("thread_id").notNull().unique(), // Provider thread ID
  subject: text("subject").notNull(),
  participants: json("participants").$type<string[]>().default([]),
  messageCount: integer("message_count").default(1),
  lastActivity: timestamp("last_activity").notNull(),
  isImportant: boolean("is_important").default(false),
  avgResponseTime: integer("avg_response_time"), // Minutes
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertEmailAccountSchema = createInsertSchema(emailAccounts).omit({
  id: true,
  createdAt: true,
  lastSyncAt: true,
});

export const insertClassificationRuleSchema = createInsertSchema(classificationRules).omit({
  id: true,
  createdAt: true,
});

export const insertEmailSchema = createInsertSchema(emails).omit({
  createdAt: true,
  processedAt: true,
});

export const insertDraftSchema = createInsertSchema(drafts).omit({
  id: true,
  createdAt: true,
  reviewedAt: true,
});

export const insertCalendarEventSchema = createInsertSchema(calendarEvents).omit({
  id: true,
  createdAt: true,
});

export const insertAiProviderSchema = createInsertSchema(aiProviders).omit({
  id: true,
  createdAt: true,
  lastUsedAt: true,
});

export const insertSystemSettingSchema = createInsertSchema(systemSettings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertUserProfileSchema = createInsertSchema(userProfiles).omit({
  id: true,
  createdAt: true,
  completedAt: true,
});

export const insertOnboardingStepSchema = createInsertSchema(onboardingSteps).omit({
  id: true,
  createdAt: true,
  completedAt: true,
});

export const insertOnboardingInsightSchema = createInsertSchema(onboardingInsights).omit({
  id: true,
  createdAt: true,
});

export const insertVipContactSchema = createInsertSchema(vipContacts).omit({
  id: true,
  createdAt: true,
  lastInteraction: true,
  interactionCount: true,
});

export const insertEmailThreadSchema = createInsertSchema(emailThreads).omit({
  id: true,
  createdAt: true,
});

// Types
export type EmailAccount = typeof emailAccounts.$inferSelect;
export type InsertEmailAccount = z.infer<typeof insertEmailAccountSchema>;

export type ClassificationRule = typeof classificationRules.$inferSelect;
export type InsertClassificationRule = z.infer<typeof insertClassificationRuleSchema>;

export type Email = typeof emails.$inferSelect;
export type InsertEmail = z.infer<typeof insertEmailSchema>;

export type Draft = typeof drafts.$inferSelect;
export type InsertDraft = z.infer<typeof insertDraftSchema>;

export type CalendarEvent = typeof calendarEvents.$inferSelect;
export type InsertCalendarEvent = z.infer<typeof insertCalendarEventSchema>;

export type AiProvider = typeof aiProviders.$inferSelect;
export type InsertAiProvider = z.infer<typeof insertAiProviderSchema>;

export type SystemSetting = typeof systemSettings.$inferSelect;
export type InsertSystemSetting = z.infer<typeof insertSystemSettingSchema>;

export type UserProfile = typeof userProfiles.$inferSelect;
export type InsertUserProfile = z.infer<typeof insertUserProfileSchema>;

export type OnboardingStep = typeof onboardingSteps.$inferSelect;
export type InsertOnboardingStep = z.infer<typeof insertOnboardingStepSchema>;

export type OnboardingInsight = typeof onboardingInsights.$inferSelect;
export type InsertOnboardingInsight = z.infer<typeof insertOnboardingInsightSchema>;

export type VipContact = typeof vipContacts.$inferSelect;
export type InsertVipContact = z.infer<typeof insertVipContactSchema>;

export type EmailThread = typeof emailThreads.$inferSelect;
export type InsertEmailThread = z.infer<typeof insertEmailThreadSchema>;
