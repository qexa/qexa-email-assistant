import os
import base64
import email
import logging
import re
import json
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from datetime import datetime
import nltk
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
import asyncio
import aiohttp
import sqlite3
from typing import Dict, List, Optional
import configparser

# Download required NLTK data
try:
    nltk.data.find('tokenizers/punkt')
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('punkt')
    nltk.download('stopwords')

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    filename='email_system.log'
)
logger = logging.getLogger(__name__)

class EmailManagementSystem:
    def __init__(self, config_path: str = 'config.ini'):
        """Initialize the email management system with configuration."""
        self.config = self._load_config(config_path)
        self.gmail_service = None
        self.db_conn = self._init_database()
        self.stop_words = set(stopwords.words('english'))
        self.rules = self._load_rules()
        self._setup_credentials()

    def _load_config(self, config_path: str) -> configparser.ConfigParser:
        """Load configuration from file."""
        config = configparser.ConfigParser()
        config.read(config_path)
        return config

    def _init_database(self) -> sqlite3.Connection:
        """Initialize SQLite database for storing email metadata and actions."""
        conn = sqlite3.connect('email_management.db')
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS emails (
                id TEXT PRIMARY KEY,
                sender TEXT,
                subject TEXT,
                category TEXT,
                priority TEXT,
                processed_at TIMESTAMP,
                action_taken TEXT
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS drafts (
                email_id TEXT,
                draft_content TEXT,
                created_at TIMESTAMP,
                FOREIGN KEY (email_id) REFERENCES emails(id)
            )
        ''')
        conn.commit()
        return conn

    def _load_rules(self) -> Dict:
        """Load classification rules from configuration."""
        return {
            'high_priority': {
                'keywords': ['order confirmation', 'invoice', 'urgent', 'meeting', 'legal'],
                'senders': ['@amazon.com', '@paypal.com', '@*.gov'],
                'actions': ['flag', 'create_draft', 'move_to_folder:high_priority']
            },
            'medium_priority': {
                'keywords': ['newsletter', 'update', 'report'],
                'senders': ['@*.edu', '@linkedin.com'],
                'actions': ['move_to_folder:medium_priority']
            },
            'low_priority': {
                'keywords': ['promotion', 'sale', 'discount'],
                'senders': ['@*.marketing', '@promotions.*'],
                'actions': ['move_to_folder:promotions']
            }
        }

    def _setup_credentials(self):
        """Set up OAuth2 credentials for Gmail API."""
        SCOPES = ['https://www.googleapis.com/auth/gmail.modify']
        creds = None
        if os.path.exists('token.json'):
            creds = Credentials.from_authorized_user_file('token.json', SCOPES)
        if not creds or not creds.valid:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
            with open('token.json', 'w') as token:
                token.write(creds.to_json())
        self.gmail_service = build('gmail', 'v1', credentials=creds)

    async def fetch_emails(self, max_results: int = 10) -> List[Dict]:
        """Fetch new emails from Gmail API."""
        try:
            results = self.gmail_service.users().messages().list(
                userId='me', maxResults=max_results).execute()
            messages = results.get('messages', [])
            email_data = []

            for message in messages:
                msg = self.gmail_service.users().messages().get(
                    userId='me', id=message['id']).execute()
                email_data.append(self._parse_email(msg))
            return email_data
        except HttpError as error:
            logger.error(f"Error fetching emails: {error}")
            return []

    def _parse_email(self, message: Dict) -> Dict:
        """Parse email content and headers."""
        headers = {h['name'].lower(): h['value'] for h in message['payload']['headers']}
        subject = headers.get('subject', '')
        sender = headers.get('from', '')
        
        # Get email body
        body = ''
        if 'parts' in message['payload']:
            for part in message['payload']['parts']:
                if part['mimeType'] == 'text/plain':
                    body = base64.urlsafe_b64decode(part['body']['data']).decode('utf-8')
                    break
        else:
            body = base64.urlsafe_b64decode(message['payload']['body']['data']).decode('utf-8')

        return {
            'id': message['id'],
            'sender': sender,
            'subject': subject,
            'body': body,
            'received_at': datetime.fromtimestamp(int(message['internalDate'])/1000)
        }

    def classify_email(self, email: Dict) -> tuple[str, str]:
        """Classify email based on rules and content analysis."""
        subject = email['subject'].lower()
        sender = email['sender'].lower()
        body = email['body'].lower()
        
        # Tokenize and clean content
        tokens = [t for t in word_tokenize(body) if t not in self.stop_words]
        
        for category, rules in self.rules.items():
            # Check sender patterns
            for sender_pattern in rules['senders']:
                if re.search(sender_pattern.replace('*', '.*'), sender):
                    return category, 'high' if category == 'high_priority' else 'medium' if category == 'medium_priority' else 'low'
            
            # Check keyword matches
            for keyword in rules['keywords']:
                if keyword in subject or keyword in body:
                    return category, 'high' if category == 'high_priority' else 'medium' if category == 'medium_priority' else 'low'
        
        return 'unclassified', 'low'

    async def generate_draft_response(self, email: Dict) -> str:
        """Generate AI-based draft response using a mock AI API call."""
        async with aiohttp.ClientSession() as session:
            # Mock AI API call (replace with actual Claude/OpenAI API in production)
            prompt = f"""
            Generate a professional response to this email:
            Subject: {email['subject']}
            From: {email['sender']}
            Content: {email['body'][:500]}
            
            Create a concise, professional response that acknowledges the email and proposes next steps.
            """
            
            # Simulated AI response
            response = f"""
            Dear {email['sender'].split('<')[0].strip()},
            
            Thank you for your email regarding {email['subject']}. I have reviewed your message and will follow up with more details by [insert timeframe]. Please let me know if you need any immediate clarification.
            
            Best regards,
            [Your Name]
            """
            return response

    async def process_email(self, email: Dict):
        """Process a single email through classification and actions."""
        try:
            category, priority = self.classify_email(email)
            
            # Store email metadata
            cursor = self.db_conn.cursor()
            cursor.execute(
                'INSERT OR REPLACE INTO emails (id, sender, subject, category, priority, processed_at, action_taken) VALUES (?, ?, ?, ?, ?, ?, ?)',
                (email['id'], email['sender'], email['subject'], category, priority, datetime.now(), 'processed')
            )
            
            # Execute actions based on category
            actions = self.rules.get(category, {}).get('actions', [])
            for action in actions:
                if action == 'flag':
                    self.gmail_service.users().messages().modify(
                        userId='me', 
                        id=email['id'],
                        body={'addLabelIds': ['IMPORTANT']}
                    ).execute()
                
                elif action.startswith('move_to_folder:'):
                    folder = action.split(':')[1]
                    # Implement folder movement (simplified)
                    self.gmail_service.users().messages().modify(
                        userId='me',
                        id=email['id'],
                        body={'addLabelIds': [folder.upper()]}
                    ).execute()
                
                elif action == 'create_draft':
                    draft_content = await self.generate_draft_response(email)
                    draft = self.gmail_service.users().drafts().create(
                        userId='me',
                        body={
                            'message': {
                                'raw': base64.urlsafe_b64encode(
                                    f"Subject: Re: {email['subject']}\n\n{draft_content}".encode()
                                ).decode()
                            }
                        }
                    ).execute()
                    
                    # Store draft metadata
                    cursor.execute(
                        'INSERT INTO drafts (email_id, draft_content, created_at) VALUES (?, ?, ?)',
                        (email['id'], draft_content, datetime.now())
                    )
            
            self.db_conn.commit()
            
        except Exception as e:
            logger.error(f"Error processing email {email['id']}: {str(e)}")
            self.db_conn.rollback()

    async def run(self):
        """Main processing loop."""
        while True:
            try:
                emails = await self.fetch_emails()
                tasks = [self.process_email(email) for email in emails]
                await asyncio.gather(*tasks)
                await asyncio.sleep(300)  # Poll every 5 minutes
            except Exception as e:
                logger.error(f"Main loop error: {str(e)}")
                await asyncio.sleep(60)  # Wait before retrying

    def get_analytics(self) -> Dict:
        """Generate basic analytics report."""
        cursor = self.db_conn.cursor()
        cursor.execute('''
            SELECT category, priority, COUNT(*) as count 
            FROM emails 
            GROUP BY category, priority
        ''')
        return {
            'processed_emails': [
                {'category': row[0], 'priority': row[1], 'count': row[2]}
                for row in cursor.fetchall()
            ],
            'last_updated': datetime.now().isoformat()
        }

if __name__ == '__main__':
    if platform.system() == "Emscripten":
        email_system = EmailManagementSystem()
        asyncio.ensure_future(email_system.run())
    else:
        email_system = EmailManagementSystem()
        asyncio.run(email_system.run())