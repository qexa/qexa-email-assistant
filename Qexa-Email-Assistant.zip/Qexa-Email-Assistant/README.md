# Qexa Email Assistant

A comprehensive AI-powered email management system designed to transform professional inbox interactions with intelligent email processing, advanced productivity tools, and seamless multi-account support.

![Qexa Email Assistant](./attached_assets/qexa_logo-nobackground-1000%20(2)_1752849845536.png)

## 🚀 Features

### Core Functionality
- **Multi-Account Email Management**: Support for Gmail, Outlook, and IMAP providers with OAuth2 authentication
- **AI-Powered Classification**: Intelligent email categorization using OpenAI GPT-4o, Anthropic Claude, and Google Gemini
- **Unified AI Email Assistant**: All-in-one interface for composing, replying, and managing email drafts
- **Smart Email Prioritization**: Executive-level email triage with VIP contact management
- **Advanced Analytics**: Real-time processing statistics and productivity insights

### AI-Powered Features
- **Smart Search**: Natural language email search with sentiment analysis
- **AI Email Composer**: Full-featured composition with tone analysis and templates
- **Draft Review System**: AI-generated responses with improvement suggestions
- **Calendar Integration**: Automatic event creation from meeting requests
- **Productivity Insights**: Comprehensive analytics tracking time saved and AI performance

### User Experience
- **Mobile-First Design**: Fully responsive interface optimized for iPhone 16 and Android devices
- **Personalized Onboarding**: AI-guided setup with role-based recommendations
- **Interactive User Guide**: Comprehensive documentation with visual demonstrations
- **Clean Navigation**: Streamlined interface with unified AI email functionality

## 🛠 Technology Stack

### Frontend
- **React.js** with TypeScript for type safety
- **Vite** for fast development and optimized builds
- **Tailwind CSS** with shadcn/ui component library
- **Wouter** for lightweight client-side routing
- **TanStack Query** for server state management
- **Radix UI** primitives with custom styling

### Backend
- **Node.js** with Express.js server
- **TypeScript** for full-stack type safety
- **Drizzle ORM** with PostgreSQL database
- **OAuth2** for secure email provider integration
- **RESTful API** design with JSON responses

### AI Integration
- **OpenAI GPT-4o** for email analysis and draft generation
- **Anthropic Claude Sonnet 4** for content understanding
- **Google Gemini** 2.5 Flash/Pro models for classification

### Database & Infrastructure
- **Neon Database** serverless PostgreSQL instance
- **Connection Pooling** through @neondatabase/serverless
- **Drizzle migrations** for schema management

## 🚦 Getting Started

### Prerequisites
- Node.js 18+ installed
- PostgreSQL database (or Neon Database URL)
- API keys for AI providers (OpenAI required)

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/qexa-email-assistant.git
   cd qexa-email-assistant
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   Create a `.env` file in the root directory:
   ```env
   DATABASE_URL=your_postgresql_connection_string
   OPENAI_API_KEY=your_openai_api_key
   ANTHROPIC_API_KEY=your_anthropic_api_key  # Optional
   GOOGLE_AI_API_KEY=your_google_ai_api_key  # Optional
   ```

4. **Initialize the database**
   ```bash
   npm run db:push
   ```

5. **Start the development server**
   ```bash
   npm run dev
   ```

The application will be available at `http://localhost:5000`

## 📱 Usage

### Email Account Setup
1. Navigate to "Email Accounts" in the sidebar
2. Click "Add Email Account"
3. Choose your provider (Gmail, Outlook, or IMAP)
4. Follow the OAuth2 authentication flow
5. Configure monitoring settings

### AI Email Assistant
1. Access the "AI Email Assistant" from the main navigation
2. Choose your mode:
   - **Compose**: Create new emails with AI assistance
   - **Reply**: Generate contextual responses to existing emails
   - **Review**: Manage and improve draft emails
3. Customize AI preferences (tone, length, signature)
4. Generate, review, and approve AI-created content

### Smart Classification
1. Go to "Classification Rules" to set up email categorization
2. Create custom rules based on keywords, senders, or content
3. Let AI automatically classify incoming emails
4. Monitor classification accuracy in Analytics

## 🔧 Configuration

### AI Providers
The system supports multiple AI providers. Configure them in the Settings page:
- **OpenAI**: Primary provider for email generation and analysis
- **Anthropic**: Alternative for content understanding
- **Google Gemini**: Additional classification capabilities

### Email Providers
Supported email providers with their authentication methods:
- **Gmail**: OAuth2 with Google APIs
- **Outlook**: Microsoft Graph API integration
- **IMAP**: Generic IMAP protocol support

## 📊 Database Schema

Key database tables:
- `email_accounts`: Multi-provider email credentials
- `classification_rules`: User-defined categorization rules
- `emails`: Processed email data with metadata
- `drafts`: AI-generated draft responses
- `calendar_events`: Auto-created calendar events
- `user_profiles`: Personalized onboarding data

## 🎯 Architecture

The application follows a modular architecture with clear separation between:
- **Frontend UI**: React components with responsive design
- **Backend API**: Express.js RESTful endpoints
- **Database Layer**: Drizzle ORM with PostgreSQL
- **External Services**: AI providers and email APIs

## 🚀 Deployment

### Development
```bash
npm run dev
```

### Production Build
```bash
npm run build
npm start
```

### Environment Variables for Production
Ensure these are set in your production environment:
- `DATABASE_URL`: PostgreSQL connection string
- `OPENAI_API_KEY`: Required for AI functionality
- `NODE_ENV=production`

## 📄 API Documentation

### Core Endpoints
- `GET /api/email-accounts`: List configured email accounts
- `POST /api/email-accounts`: Add new email account
- `GET /api/drafts`: Retrieve email drafts
- `POST /api/drafts/generate-response`: Generate AI response
- `GET /api/analytics`: Get productivity metrics

### AI Endpoints
- `POST /api/email-composer/generate`: Create new email with AI
- `POST /api/drafts/{id}/improve`: Enhance existing draft
- `POST /api/search/smart`: Perform AI-powered email search

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🔒 Security

- OAuth2 authentication for email providers
- Encrypted API key storage
- Secure database connections
- Rate limiting on AI API calls

## 🆘 Support

For support, email support@qexa.io or create an issue in this repository.

## 🎉 Acknowledgments

- Built with modern web technologies
- AI powered by OpenAI, Anthropic, and Google
- UI components from shadcn/ui and Radix UI
- Icons from Lucide React

---

**Qexa Email Assistant** - Transforming email management with AI-powered intelligence.