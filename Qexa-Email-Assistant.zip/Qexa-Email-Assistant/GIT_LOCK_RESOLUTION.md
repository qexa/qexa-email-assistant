# Git Lock Resolution for GitHub Sync

## 🔓 Remove Git Locks Manually

The system is blocking Git operations due to lock files. Here's how to fix it:

### Step 1: Remove Lock Files via Shell

Open the **Shell** tab in Replit and run these commands:

```bash
# Navigate to project root
cd /home/runner/workspace

# Remove all Git lock files
rm -f .git/index.lock
rm -f .git/config.lock
rm -f .git/refs/heads/main.lock
rm -f .git/HEAD.lock

# Check Git status
git status
```

### Step 2: Reset Git if Needed

If still having issues, reset Git completely:

```bash
# Backup current state
cp -r . ../qexa-backup

# Remove Git folder
rm -rf .git

# Reinitialize Git
git init
git add .
git commit -m "Initial commit: Qexa Email Assistant - AI-powered email management system"
```

### Step 3: Connect to GitHub

```bash
# Add your GitHub repository as remote
git remote add origin https://github.com/yourusername/qexa-email-assistant.git

# Push to GitHub
git push -u origin main
```

### Step 4: Enable Automatic Sync

In Replit:
1. Go to **Version Control** tab
2. Connect your GitHub account
3. Link this Repl to your GitHub repository
4. Enable "Auto-commit" in settings

## 🚀 Alternative: Fresh Start Method

If the above doesn't work, create a fresh Git repository:

### Method A: Download and Re-upload

1. **Download Project**:
   - Click the three dots (**⋮**) menu in Replit
   - Select "Download as zip"
   - Extract the zip file

2. **Create New GitHub Repository**:
   - Go to https://github.com/new
   - Name: `qexa-email-assistant`
   - Initialize with README: **No**

3. **Upload via GitHub CLI** (if you have it):
   ```bash
   gh repo clone yourusername/qexa-email-assistant
   cd qexa-email-assistant
   # Copy all files from extracted zip (except .git, node_modules)
   git add .
   git commit -m "Initial commit: Qexa Email Assistant"
   git push
   ```

### Method B: GitHub Desktop

1. Download GitHub Desktop
2. Clone your empty repository
3. Copy project files to the cloned folder
4. Commit and push through GitHub Desktop

## 🛠 Replit Version Control Setup

Once Git locks are resolved:

1. **Open Version Control Panel** in Replit
2. **Connect GitHub Account**:
   - Click "Connect to GitHub"
   - Authorize Replit access

3. **Link Repository**:
   - Select your `qexa-email-assistant` repository
   - Choose "Link existing repository"

4. **Configure Auto-sync**:
   - Enable "Auto-commit on file changes"
   - Set commit message template
   - Configure branch protection if needed

## ✅ Verification

After setup, test the sync:

```bash
# Make a small change
echo "# Test sync" >> test.md

# Check Git status
git status

# Add and commit
git add test.md
git commit -m "Test: Verify GitHub sync"

# Push to GitHub
git push
```

## 🔧 Troubleshooting

**If you get permission errors:**
```bash
# Set Git user (replace with your info)
git config user.name "Your Name"
git config user.email "your.email@example.com"
```

**If branch doesn't exist:**
```bash
# Create and switch to main branch
git branch -M main
```

**If remote already exists:**
```bash
# Remove and re-add remote
git remote remove origin
git remote add origin https://github.com/yourusername/qexa-email-assistant.git
```

Your Qexa Email Assistant will then automatically sync with GitHub! 🎉